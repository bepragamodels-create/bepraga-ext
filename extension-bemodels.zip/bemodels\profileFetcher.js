// ============================================================
//  BeModels — profileFetcher.js  (content script, ISOLATED world)
//  Detecta la TIMEZONE real del perfil de Stripchat de la modelo
//  logueada. Esto es importante porque Stripchat agrega los
//  totales del dia segun la TZ del perfil (configurable en
//  /my/settings), no segun la TZ que tenga BeModels en su CFG.
//
//  Si las dos no coinciden, el corte de medianoche es distinto y
//  los tokens "del dia" no cuadran con lo que muestra Stripchat.
//
//  Estrategia (en orden, devuelve la primera que funcione):
//    1) window.__NEXT_DATA__ → props.pageProps.user.timezone /
//       initialState.user.timezone / similares
//    2) fetch /api/front/users/me (campos: timezone, timeZone,
//       userTimezone, profileTimezone, tz)
//    3) fetch /api/front/users/<id> (con userId si lo tenemos)
//    4) null → el caller decide fallback (CFG.tz)
//
//  Devuelve un IANA TZ string ('America/Bogota', 'UTC', etc.) o
//  null. Si Stripchat devuelve un offset numerico ('+05:00') o
//  un nombre no-IANA, se intenta normalizar; si no, null.
// ============================================================
(function () {
  'use strict';
  const TAG = '[BeModels.profile]';

  // Campos donde Stripchat (u otras plataformas similares) suele
  // exponer la TZ. Probamos todos en orden hasta encontrar uno.
  const TZ_KEYS = [
    'timezone', 'timeZone', 'tz',
    'userTimezone', 'userTimeZone',
    'profileTimezone', 'profileTimeZone',
    'ianaTimezone', 'ianaTimeZone'
  ];

  function pickTzFromObject(obj) {
    if (!obj || typeof obj !== 'object') return null;
    for (const k of TZ_KEYS) {
      const v = obj[k];
      if (typeof v === 'string' && v.length >= 3 && v.length < 64) return v;
    }
    return null;
  }

  // Validacion: que la TZ sea entendida por Intl. Si no, descartar.
  function isValidIanaTz(tz) {
    try {
      new Intl.DateTimeFormat('en-US', { timeZone: tz }).format(new Date());
      return true;
    } catch (_) { return false; }
  }

  // Caza la TZ en __NEXT_DATA__ del SSR. Stripchat lo expone en
  // varias paginas (settings/profile, earnings, etc.). Devuelve la
  // primera TZ que aparezca en algun nodo "user"/"profile"/"me".
  function fromNextData() {
    try {
      const el = document.getElementById('__NEXT_DATA__');
      if (!el || !el.textContent) return null;
      const j = JSON.parse(el.textContent);
      // Busqueda recursiva acotada para no quemar CPU en SSR enormes.
      const seen = new WeakSet();
      const queue = [j];
      let depth = 0;
      while (queue.length && depth < 5000) {
        depth++;
        const cur = queue.shift();
        if (!cur || typeof cur !== 'object' || seen.has(cur)) continue;
        seen.add(cur);
        const got = pickTzFromObject(cur);
        if (got && isValidIanaTz(got)) return got;
        for (const k of Object.keys(cur)) {
          const v = cur[k];
          if (v && typeof v === 'object') queue.push(v);
        }
      }
    } catch (e) { console.debug(TAG, '__NEXT_DATA__ scan fail', e && e.message); }
    return null;
  }

  async function fromEndpoint(url) {
    try {
      const r = await fetch(url, {
        credentials: 'include',
        headers: { accept: 'application/json' }
      });
      if (!r.ok) {
        console.debug(TAG, url, '!ok', r.status);
        return null;
      }
      const j = await r.json();
      // El endpoint puede devolver { user: {...} } o el user plano.
      const cand = j && (j.user || j);
      const tz = pickTzFromObject(cand);
      if (tz && isValidIanaTz(tz)) return tz;
      // Algunos endpoints devuelven la TZ como subcampo de profile.
      if (cand && cand.profile) {
        const tz2 = pickTzFromObject(cand.profile);
        if (tz2 && isValidIanaTz(tz2)) return tz2;
      }
      console.debug(TAG, url, 'sin TZ reconocible. keys =',
        cand ? Object.keys(cand).slice(0, 40) : null);
      return null;
    } catch (e) {
      console.debug(TAG, url, 'ERR', e && e.message);
      return null;
    }
  }

  async function detectProfileTz(userId) {
    // 1) SSR — barato, sin red.
    const next = fromNextData();
    if (next) {
      console.debug(TAG, 'TZ via __NEXT_DATA__:', next);
      return { tz: next, source: 'next' };
    }
    // 2) /me — funciona si la sesion esta activa.
    const me = await fromEndpoint('/api/front/users/me');
    if (me) {
      console.debug(TAG, 'TZ via /users/me:', me);
      return { tz: me, source: 'me' };
    }
    // 3) /users/<id> — fallback con el userId que ya descubrimos.
    if (userId) {
      const byId = await fromEndpoint('/api/front/users/' + encodeURIComponent(userId));
      if (byId) {
        console.debug(TAG, 'TZ via /users/<id>:', byId);
        return { tz: byId, source: 'byId' };
      }
    }
    console.debug(TAG, 'TZ no detectada — el caller usara fallback');
    return null;
  }

  window.BMProfile = { detectProfileTz, isValidIanaTz };
  console.debug(TAG, 'modulo cargado');
})();
