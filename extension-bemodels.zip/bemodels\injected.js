// ============================================================
//  BeModels — injected.js  (MAIN world)
//  Corre en el MISMO contexto JS que la pagina para:
//   1) Detectar la cuenta de modelo LOGUEADA (auto, multi-fuente:
//      __NEXT_DATA__ + fetch/XHR + /cam isOwnShow). Metodo probado
//      portado de BeCapture: no depende solo del slug de la URL ni
//      de un solo header.
//   2) Saber si la sala abierta es la PROPIA (cam.isOwnShow) →
//      solo en ese caso se cuentan tips/goal (no los de otra sala).
//   3) Leer el goal de Stripchat (cam.goal) y los tips en vivo del
//      WebSocket Centrifugo.
//  NO descarga nada, NO toca el DOM. Solo postMessage al content
//  script (que dibuja la barra/HUD y guarda en chrome.storage).
//
//  Convencion de versionado: subir BM_BUILD aqui + version en
//  manifest.json + entrada en CHANGELOG.md en CADA cambio.
// ============================================================
(function () {
  'use strict';
  const BM_BUILD = '2026-06-05g · v0.1.85 resumen de cierre enriquecido: + COP (pesos netos), + 🏆 Puesto/StripPoints, + ⭐ StripScore, + plataforma en el encabezado. Requiere bridge 0.17.1';
  console.log('%c[BeModels] BUILD ' + BM_BUILD,
    'background:#5409A9;color:#fff;padding:2px 8px;border-radius:4px;font-weight:bold');

  const TAG = 'BEMODELS';
  let SELF_MODEL  = null;   // username (lowercase) de la cuenta logueada
  let SELF_USERID = null;
  let SELF_NAME   = null;   // nombre para mostrar (saludo)
  let _selfHash   = null;
  let _ownShow    = false;  // la sala abierta es la propia (isOwnShow)
  let _forced     = false;  // activada manualmente por la modelo
  let _camTimer   = null;
  const _diag = { selfModel: null, selfSrc: null, ownShow: false,
                  camHttp: null, camIsOwn: null, nextData: null,
                  ownPage: false, streamStart: null, build: BM_BUILD };

  function post(kind, payload) {
    try {
      window.postMessage(Object.assign({ source: TAG, kind, ts: Date.now() }, payload || {}), '*');
    } catch (_) {}
  }

  function emitDiag(patch) {
    try {
      if (patch) Object.assign(_diag, patch);
      _diag.selfModel = SELF_MODEL;
      _diag.ownShow   = _ownShow;
      post('DIAG', { diag: Object.assign({}, _diag) });
    } catch (_) {}
  }

  // ── Deteccion por la PROPIA pagina de transmision (DOM/texto) ──────────────
  // Portado/condensado de BeCapture: en la sala propia hay marcadores fuertes
  // de primera persona ("estas EN DIRECTO", "estoy en un Show", controles de
  // broadcaster, "Volver a Mis modelos"). Sirve aunque /cam no devuelva
  // isOwnShow (p.ej. durante un show privado o contexto de estudio).
  let _ownPageCache = { v: false, t: 0 };
  function isOwnBroadcastPage() {
    const now = Date.now();
    if (_ownPageCache.v && now - _ownPageCache.t < 10000) return true;
    let own = false;
    try {
      const body = (document.body && document.body.textContent) || '';
      if (document.querySelector('a[href*="start-broadcasting"]') ||
          document.querySelector('[class*="broadcastButton" i]') ||
          document.querySelector('[class*="startBroadcast" i]')) own = true;
      if (!own && /est[aá]s\s+EN\s+DIRECTO|you\s+are\s+(now\s+)?LIVE|usando\s+software\s+OBS|external\s+streaming\s+software|para\s+detener\s+la\s+transmisi[oó]n|volver\s+a\s+la\s+transmisi[oó]n\s+por\s+navegador|en\s+este\s+momento\s+estoy\s+en\s+un\s+show|estoy\s+en\s+un\s+show\s+(privado|grupal|p[uú]blico)|volver\s+a\s+["“]?mis\s+modelos/i.test(body)) own = true;
    } catch (_) {}
    if (own) _ownPageCache = { v: true, t: now };
    return own;
  }
  function slugModel() {
    const m = location.pathname.replace(/^\/+/, '').split(/[/?#]/)[0];
    if (!m || /^(es|en|account|earnings|api|cdn|tags|categories|search)$/i.test(m)) return null;
    return m;
  }
  function tryOwnPageSelf(src) {
    try {
      if (SELF_MODEL) return;
      if (!isOwnBroadcastPage()) return;
      const slug = slugModel();
      if (!slug) return;
      applySelf({ username: slug, isModel: true, isLoggedIn: true },
                src || 'dom-broadcast');
      setOwnShow(true);
      emitDiag({ selfSrc: src || 'dom-broadcast' });
    } catch (_) {}
  }

  // ── Identidad de la modelo LOGUEADA (auto, sin confirmar) ───────────────────
  // Portado de BeCapture: la sala de la URL puede ser de OTRA modelo. Lo unico
  // que SIEMPRE habla de "esta" modelo es la cuenta autenticada (el objeto
  // `user` que viene junto a cualquier payload: __NEXT_DATA__, /cam, /users).
  function looksLikeAuthSelf(u) {
    if (!u || typeof u !== 'object') return false;
    const uname = u.username || u.modelUsername || u.name;
    if (!uname || typeof uname !== 'string') return false;
    const isModelAcct =
      u.isModel === true || u.isStudioModel === true ||
      u.isBroadcaster === true || u.role === 'model' ||
      (u.model && typeof u.model === 'object');
    const isAuth =
      'email' in u || 'tokenBalance' in u || 'tokens' in u ||
      'isModel' in u || 'role' in u || u.isLoggedIn === true ||
      u.isAuthenticated === true;
    return !!(isModelAcct && isAuth);
  }

  function prettyName(u, uname) {
    const n = (u && (u.name || u.displayName || u.firstName)) || '';
    if (n && typeof n === 'string' && n.trim()) return n.trim();
    // Capitaliza el username como fallback ("KellyOlsenbe" → "KellyOlsenbe")
    return String(uname || '').replace(/^\w/, c => c.toUpperCase());
  }

  function applySelf(u, src) {
    try {
      if (!looksLikeAuthSelf(u)) return;
      const rawName = u.username || u.modelUsername || u.name;
      const uname = String(rawName).toLowerCase().trim();
      const uid   = Number(u.id || u.userId || u.modelId) || null;
      if (!uname) return;
      const hash = uname + '|' + (uid || '');
      if (hash === _selfHash) return;
      _selfHash   = hash;
      SELF_MODEL  = uname;
      SELF_USERID = uid;
      SELF_NAME   = prettyName(u, rawName);
      _diag.selfSrc = src || 'auto';
      post('SELF', { model: SELF_MODEL, userId: SELF_USERID, name: SELF_NAME,
                     src: src || 'auto' });
      emitDiag();
      console.log('%c[BeModels] Modelo logueada: ' + SELF_MODEL + ' (' + SELF_NAME + ')',
        'color:#5409A9;font-weight:bold', '· src=' + (src || 'auto'));
    } catch (_) {}
  }

  // Escanea un payload buscando el user autenticado en las claves tipicas.
  function scanSelf(obj, src) {
    if (!obj || typeof obj !== 'object') return;
    if (looksLikeAuthSelf(obj)) { applySelf(obj, src); return; }
    for (const k of ['user', 'viewer', 'currentUser', 'authUser', 'me',
                     'authenticatedUser', 'sessionUser', 'initialUser']) {
      if (obj[k] && typeof obj[k] === 'object') applySelf(obj[k], src + ':' + k);
    }
  }

  // ── Inicio de transmision (si Stripchat lo expone en el payload) ───────────
  // No hay un campo confirmado; escaneamos claves tipo *startedAt / *Since /
  // stream|broadcast*start con una fecha plausible (pasada, < 36 h). Si no
  // aparece, el inicio de turno se fija manual desde el popup.
  function tsFrom(v) {
    if (v == null) return null;
    let t = null;
    if (typeof v === 'number') { t = v < 1e12 ? v * 1000 : v; }
    else if (typeof v === 'string') { const p = Date.parse(v); if (!isNaN(p)) t = p; }
    if (t == null) return null;
    const now = Date.now();
    if (t > now - 36 * 3600e3 && t <= now + 5 * 60e3) return t;
    return null;
  }
  function extractStreamStart(cam) {
    try {
      if (!cam || typeof cam !== 'object') return null;
      // CONFIRMADO en trafico real (dato del usuario 2026-05-18): el inicio
      // de transmision esta en /cam → user.user.statusChangedAt (ISO UTC).
      // Ojo: tambien cambia al alternar publico↔privado a mitad de show;
      // por eso content.js fija el PRIMER valor visto y cuenta desde ahi.
      const uu = cam.user && cam.user.user;
      const t1 = tsFrom(uu && uu.statusChangedAt);
      if (t1 != null) return t1;
      const t2 = tsFrom(cam.statusChangedAt);
      if (t2 != null) return t2;
      // Respaldo: escaneo generico de claves *start*/*since*.
      let best = null;
      const scan = obj => {
        if (!obj || typeof obj !== 'object') return;
        for (const k of Object.keys(obj)) {
          if (!/start|since/i.test(k)) continue;
          if (!/stream|broadcast|show|live|online|cam|session/i.test(k) &&
              !/^started?at$|^starttime$/i.test(k)) continue;
          const t = tsFrom(obj[k]);
          if (t != null && (best == null || t < best)) best = t;
        }
      };
      scan(cam);
      scan(cam.broadcast); scan(cam.stream); scan(cam.show); scan(uu);
      return best;
    } catch (_) { return null; }
  }
  function emitStreamStart(cam, src) {
    // Solo emitir cuando la modelo esta EN VIVO. statusChangedAt cambia
    // con CUALQUIER transicion de estado (incluye "se fue offline"),
    // asi que si la leemos con isLive=false estamos capturando el
    // momento que se desconecto, no cuando empezo el show.
    const uu = cam && cam.user && cam.user.user;
    if (!uu || uu.isLive !== true) return;
    const t = extractStreamStart(cam);
    if (t == null) return;
    _diag.streamStart = new Date(t).toISOString();
    post('STREAM', { model: SELF_MODEL, startedAt: t, src: src || 'cam' });
  }

  // /cam → { cam, user }. cam.isOwnShow === true ⇒ la sala abierta es la de
  // la cuenta logueada; cam.user.user trae su perfil. En la sala de OTRA
  // modelo isOwnShow es false → no contamos ahi.
  function detectSelfFromCam(j, src) {
    try {
      const cam = j && j.cam;
      const uu  = j && j.user && j.user.user;
      if (cam && cam.isOwnShow === true && uu && (uu.username || uu.modelUsername)) {
        applySelf(uu, src || 'cam-own');
        setOwnShow(true);
        emitCam(cam);
        emitStreamStart(cam, src || 'cam');
      } else if (cam && cam.isOwnShow === false) {
        setOwnShow(false);
      }
      // BACKFILL: en sesion de estudio (impersonacion) isOwnShow puede ser
      // false aunque sea la modelo NUESTRA. Si cam.user.user.username
      // coincide con SELF_MODEL (detectada por DOM/NEXT_DATA), completar
      // SELF_USERID desde cam.user.user.id y emitir statusChangedAt → asi
      // pollEarnings (necesita userId) y EN VIVO (statusChangedAt) funcionan
      // aun sin isOwnShow.
      if (cam && uu && SELF_MODEL) {
        const camUser = String(uu.username || uu.modelUsername || '')
          .toLowerCase().trim();
        if (camUser && camUser === SELF_MODEL) {
          const uid = Number(uu.id || uu.userId || uu.modelId) || null;
          if (uid && SELF_USERID !== uid) {
            SELF_USERID = uid;
            _diag.selfSrc = (_diag.selfSrc ? _diag.selfSrc + '+' : '') + 'camUid';
            post('SELF', { model: SELF_MODEL, userId: SELF_USERID,
                           name: SELF_NAME || camUser, src: 'cam-backfill' });
            emitDiag();
            console.log('%c[BeModels] userId completado via /cam: ' + uid,
              'color:#5409A9;font-weight:bold');
          }
          // statusChangedAt confirmado 2026-05-20 en uu.statusChangedAt
          // (ISO UTC). cam.statusChangedAt = undefined en sesion estudio.
          emitStreamStart(cam, src || 'cam-backfill');
        }
      }
    } catch (_) {}
  }

  function setOwnShow(v) {
    if (_ownShow === v) return;
    _ownShow = v;
    post('OWNSHOW', { model: SELF_MODEL, own: v });
  }

  // cam.goal = { description, goal, spent, left, isEnabled }
  function emitCam(cam) {
    try {
      if (!cam || cam.isOwnShow !== true) return;
      const g = cam.goal || null;
      post('CAM', {
        model:   SELF_MODEL,
        online:  cam.isLive === true || cam.isOnline === true || cam.streamName != null,
        status:  cam.status || null,
        viewers: (cam.viewersCount != null ? cam.viewersCount
                 : (cam.membersCount != null ? cam.membersCount : null)),
        goal: g ? {
          nombre:    g.description || null,
          meta:      Number(g.goal) || null,
          recaudado: Number(g.spent) || 0,
          restante:  (g.left != null ? Number(g.left)
                     : (Number(g.goal) || 0) - (Number(g.spent) || 0)),
          activo:    g.isEnabled !== false
        } : null
      });
    } catch (_) {}
  }

  // ── __NEXT_DATA__ (Next.js): trae la cuenta logueada y cam.isOwnShow ────────
  function scanNextData(src) {
    try {
      const nd = window.__NEXT_DATA__;
      const p  = (nd && nd.props && nd.props.pageProps) || null;
      _diag.nextData = !nd ? 'no-nextdata'
        : !p ? 'sin-pageProps'
        : (p.cam && typeof p.cam.isOwnShow === 'boolean')
          ? ('cam.isOwnShow=' + p.cam.isOwnShow) : 'pageProps-sin-cam';
      if (!p) { emitDiag(); return; }
      scanSelf(p, src || 'nextdata');
      if (p.initialReduxState) scanSelf(p.initialReduxState, (src || 'nextdata') + ':redux');
      if (p.cam && typeof p.cam === 'object') {
        if (p.cam.isOwnShow === true) {
          const uu = (p.user && p.user.user) || p.user;
          if (uu) applySelf(uu, 'nextdata:cam');
          setOwnShow(true);
          emitCam(p.cam);
          emitStreamStart(p.cam, 'nextdata');
        } else if (p.cam.isOwnShow === false) {
          setOwnShow(false);
        }
      }
    } catch (_) {}
  }

  // ── Fetch ACTIVO de /cam (con cookies + accept json, como BeCapture) ────────
  async function fetchCam() {
    try {
      const m = location.pathname.replace(/^\/+/, '').split(/[/?#]/)[0];
      if (!m || /^(es|en|account|earnings|api|cdn|tags|categories|search)$/i.test(m)) return;
      const r = await fetch('/api/front/v2/models/username/' + encodeURIComponent(m) + '/cam',
        { credentials: 'include', headers: { accept: 'application/json' } });
      _diag.camHttp = r.status;
      if (!r.ok) { emitDiag(); return; }
      const j = await r.json();
      _diag.camIsOwn = (j && j.cam && typeof j.cam.isOwnShow === 'boolean')
        ? j.cam.isOwnShow : 'sin-campo';
      detectSelfFromCam(j, 'cam:fetch');
      if (j && j.user) scanSelf(j, 'cam:fetch');
      emitDiag();
    } catch (e) {
      _diag.camHttp = 'neterr'; emitDiag();
    }
  }

  function startCamPoll() {
    if (_camTimer) return;
    scanNextData('boot');
    fetchCam();
    _camTimer = setInterval(() => { scanNextData('poll'); fetchCam(); }, 25000);
  }

  // (v0.1.35: removido el ranking aprendido del trafico de Top Models.
  // Era legacy y duplicaba a la franja RANK que tambien fue removida en 0.1.37.)

  // ── Interceptor de fetch ───────────────────────────────────────────────────
  const _origFetch = window.fetch;
  window.fetch = function (...args) {
    const p = _origFetch.apply(this, args);
    try {
      const url = (args[0] && args[0].url) || args[0] || '';
      if (typeof url === 'string' &&
          /\/models\/username\/[^/]+\/cam(\?|$)|\/users\/(me|\d+)(\?|$|\/)/.test(url)) {
        p.then(res => {
          res.clone().json().then(j => {
            detectSelfFromCam(j, 'fetch');
            scanSelf(j, 'fetch:api');
          }).catch(() => {});
        }).catch(() => {});
      }
    } catch (_) {}
    return p;
  };

  // ── Interceptor de XMLHttpRequest (Stripchat usa XHR para /cam) ─────────────
  try {
    const OX = XMLHttpRequest.prototype.open;
    const SX = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function (m, url) {
      this.__bmUrl = url; return OX.apply(this, arguments);
    };
    XMLHttpRequest.prototype.send = function () {
      try {
        const url = this.__bmUrl || '';
        const isCam = /\/models\/username\/[^/]+\/cam(\?|$)|\/users\/(me|\d+)(\?|$|\/)/.test(url);
        if (isCam) {
          this.addEventListener('load', () => {
            try {
              const t = this.responseType;
              if (t && t !== 'text' && t !== 'json') return;
              const j = JSON.parse(this.responseText);
              detectSelfFromCam(j, 'xhr'); scanSelf(j, 'xhr:api');
            } catch (_) {}
          });
        }
      } catch (_) {}
      return SX.apply(this, arguments);
    };
  } catch (_) {}

  // ── Interceptor de WebSocket (Centrifugo) ──────────────────────────────────
  // server→client: { push:{ channel, pub:{ data } } }. Solo emitimos tips/goal
  // si la sala abierta es la PROPIA (_ownShow) → no contamos otra sala.
  const NativeWS = window.WebSocket;
  const _wsDedup = new Map();

  function handleWs(raw) {
    if (typeof raw === 'string' && raw.length > 2) {
      const now = Date.now(), last = _wsDedup.get(raw);
      if (last && now - last < 2000) return;
      _wsDedup.set(raw, now);
      if (_wsDedup.size > 300) for (const [k, t] of _wsDedup) if (now - t > 4000) _wsDedup.delete(k);
    }
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }
    if (!msg || !msg.push) return;
    if (!_ownShow) return;            // solo la sala propia
    const channel = String(msg.push.channel || '');
    const data    = (msg.push.pub && msg.push.pub.data) || {};

    if (channel === 'tip' || channel === 'freeTip' || channel === 'goalContribution') {
      const tokens = Number(data.tokens || data.amount || data.tip || 0) || 0;
      if (tokens <= 0) return;
      post('TIP', {
        model:    SELF_MODEL,
        tokens,
        userId:   data.userId || data.user_id || (data.user && data.user.id) || null,
        username: data.username || data.userName ||
                  (data.user && (data.user.username || data.user.name)) || null,
        kind:     channel,
        anon:     data.isAnonymous === true || data.anonymous === true
      });
      return;
    }

    if (/goalChanged|goalUpdated|newGoal|goalReached|goalCompleted/i.test(channel)) {
      post('GOAL_EVT', {
        model:   SELF_MODEL,
        channel,
        nombre:    data.description || data.goal && data.goal.description || null,
        meta:      Number(data.goal && data.goal.goal || data.goal) || null,
        recaudado: Number(data.goal && data.goal.spent || data.spent || 0) || 0,
        completado:/reached|completed/i.test(channel)
      });
      return;
    }
  }

  function hookWs(ws) {
    try {
      ws.addEventListener('message', e => {
        try { handleWs(typeof e.data === 'string' ? e.data : ''); } catch (_) {}
      });
    } catch (_) {}
  }

  window.WebSocket = function (url, protocols) {
    const ws = protocols !== undefined ? new NativeWS(url, protocols) : new NativeWS(url);
    hookWs(ws);
    return ws;
  };
  try {
    Object.assign(window.WebSocket, NativeWS);
    window.WebSocket.prototype = NativeWS.prototype;
  } catch (_) {}

  // ── Activacion MANUAL desde el popup/panel (content → injected) ─────────────
  // Si el auto-detect falla, la modelo escribe su usuario y confiamos en ella:
  // fijamos self + ownShow para que la barra cuente sus tips ya.
  window.addEventListener('message', e => {
    const d = e && e.data;
    if (!d || d.source !== 'BEMODELS_CMD') return;
    if (d.kind === 'FORCE' && d.model) {
      _forced = true;
      applySelf({ username: String(d.model), isModel: true, isLoggedIn: true }, 'manual');
      setOwnShow(true);
      emitDiag({ selfSrc: 'manual' });
    } else if (d.kind === 'WHOAMI') {
      emitDiag();   // el popup pide el estado actual
    }
  });

  // ── Arranque + reintentos (NEXT_DATA/DOM pueden poblarse tarde) ─────────────
  function sweep(src) {
    scanNextData(src);
    tryOwnPageSelf(src === 'init' ? 'dom-broadcast' : 'dom-broadcast:' + src);
    fetchCam();
    emitDiag();
  }
  function boot() { sweep('init'); startCamPoll(); }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot, { once: true });
  } else { boot(); }
  setTimeout(() => sweep('warmup'), 1500);
  setTimeout(() => sweep('warmup2'), 4000);

  // Reintento cada 8s: hasta detectar y luego sigue emitiendo diagnostico
  // (cada ~30s) para que el popup muestre por que no detecto.
  let _tries = 0;
  setInterval(() => {
    _tries++;
    if (!SELF_MODEL) { sweep('retry'); }
    else if (_tries % 4 === 0) { emitDiag(); }
  }, 8000);

  // Re-bootstrap en navegacion SPA (Stripchat es Next.js)
  let _lastHref = location.href;
  setInterval(() => {
    if (location.href === _lastHref) return;
    _lastHref = location.href;
    _ownPageCache = { v: false, t: 0 };
    setTimeout(() => sweep('spa'), 600);
  }, 3000);

  post('BUILD', { build: BM_BUILD });
  emitDiag({ selfSrc: null });
})();
