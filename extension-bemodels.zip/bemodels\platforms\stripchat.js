// ============================================================
//  BeModels — platforms/stripchat.js  (content script, ISOLATED)
//
//  Adapter de Stripchat. Wrappea los módulos existentes
//  (BMEarn, BMProfile, etc.) cumpliendo la interfaz definida en
//  platforms/base.js. La detección de modelo (detectSelf) sigue
//  pasando por injected.js → postMessage SELF como antes — no la
//  movemos al adapter porque está acoplada a Centrifugo WS y al
//  flujo de inyección de Stripchat.
//
//  Conversión:
//    Stripchat paga 1 tk = $0.05 USD bruto.
//    La modelo recibe 55% → $0.0275 USD/tk neto.
//    1 USD = 20 tk (bruto). Helper de COP usa este factor.
//
//  Si en el futuro algún campo del adapter cambia (ej. share sube
//  a 60%), tocar ACÁ. content.js es agnóstico.
// ============================================================
(function () {
  'use strict';

  const adapter = {
    name: 'stripchat',
    hostMatches: function (host) {
      return /(^|\.)stripchat\.com$/.test(host);
    },

    // ── Identidad ──
    // En Stripchat la detección de modelo viene desde injected.js
    // (MAIN world) que postea SELF al content script. No hace falta
    // que el adapter haga nada extra — content.js sigue escuchando
    // window.message como antes.
    detectSelf: async function () { return null; },

    // ── Earnings: rango de fechas ──
    fetchEarningsRange: function (userId, fromIso, untilIso) {
      if (window.BMEarn && window.BMEarn.fetchEarningsRange) {
        return window.BMEarn.fetchEarningsRange(userId, fromIso, untilIso);
      }
      return Promise.resolve(null);
    },
    // Solo hoy (atajo, usado por earnTick).
    fetchEarningsToday: function (userId, tz) {
      if (window.BMEarn && window.BMEarn.fetchEarningsToday) {
        return window.BMEarn.fetchEarningsToday(userId, tz);
      }
      return Promise.resolve(null);
    },

    // ── TZ del perfil ──
    profileTz: function (userId) {
      if (window.BMProfile && window.BMProfile.detectProfileTz) {
        return window.BMProfile.detectProfileTz(userId);
      }
      return Promise.resolve(null);
    },

    // ── Conversión moneda ──
    // Stripchat: 1 tk = $0.05 USD bruto.
    tkToUsd: function (tk) { return (Number(tk) || 0) / 20; },
    modelShare: 0.55,           // share de la modelo (post comisión Stripchat)
    tokenLabel: 'tk',
    currencyLabel: 'USD',

    // ── Modelo de negocio ──
    isPerMinute: false,         // Stripchat es tip+goal (no per-minute)

    // ── Saldo del DOM ──
    // Stripchat muestra el balance en .tokens-amount (header).
    // El selector lo tiene content.js en readBalance(); acá solo
    // marcamos que esa función la maneja content.js (no duplicamos).
    readBalanceDOM: null,       // delegado a content.js readBalance()

    // ── WebSocket de tips ──
    // Centrifugo WS: lo maneja injected.js (MAIN world) y postea
    // TIP/GOAL al content script. Adapter no se mete.
    subscribeWS: null,

    // ── StripScore + métricas del broadcast-center ──
    // El StripScore NO está en el DOM de la sala (solo en el panel
    // del perfil). Stripchat lo expone autenticado en el endpoint
    // /api/front/models/<uid>/broadcast-center. Mismo que BeCapture
    // v1.8.7. Devuelve { stripScore, favoritedCount, tokensPerHour,
    // privateShowRating } | null.
    fetchBroadcastCenter: async function (uid) {
      if (!uid) return null;
      try {
        const ep = '/api/front/models/' + encodeURIComponent(uid) +
          '/broadcast-center?uniq=' + Math.random().toString(36).slice(2);
        const r = await fetch(ep, {
          credentials: 'include', headers: { accept: 'application/json' }
        });
        if (!r.ok) return null;
        const j = await r.json();
        const info = j && j.info;
        if (!info || typeof info !== 'object') return null;
        const num = n => (typeof n === 'number' && isFinite(n)) ? n : null;
        return {
          stripScore:        num(info.stripScore),
          favoritedCount:    num(info.favoritedCount),
          tokensPerHour:     num(info.tokensPerHour),
          privateShowRating: num(info.privateShowRating),
          ts: Date.now()
        };
      } catch (_) { return null; }
    },

    // ── Puesto del leaderboard via API directa (cliente) ──
    // Pagina /api/front/v5/models/top buscando el username de la modelo.
    // Es la MISMA fuente que el colector del server, pero llamada desde
    // el cliente (cookies de la modelo) → NO depende del bridge ni de
    // Cloudflare Access ni de que la modelo visite su /top. Funciona en
    // CUALQUIER página de Stripchat.
    //
    // gender/continent: default female/sa (estudio colombiano). Si la
    // modelo no aparece en ese scope (otro género/continente), devuelve
    // null y el caller cae al badge DOM o StripScore.
    //
    // PERÍODOS: el badge del perfil suele reflejar el ranking MENSUAL
    // regional ("Top 1000 mensual SA"), NO el 'current' (horario). Por
    // eso probamos varios períodos hasta encontrarla. Stripchat acepta
    // distintos valores de period según la versión; probamos los más
    // comunes en orden y devolvemos el primero que la liste.
    // Devuelve { position, stripPoints, total, period } | null.
    fetchMyRanking: async function (username, gender, continent, periods) {
      if (!username) return null;
      const g = gender || 'female';
      const cont = continent || 'sa';
      const me = String(username).toLowerCase().trim();
      const PERIODS = (periods && periods.length) ? periods
                    : ['current-month', 'month', 'current', 'current-week', 'week'];
      const PAGES = 10;   // top 1000 (10 x 100)
      for (const period of PERIODS) {
        let firstPageEmpty = true;
        for (let p = 0; p < PAGES; p++) {
          const offset = p * 100;
          try {
            const url = '/api/front/v5/models/top?gender=' + encodeURIComponent(g) +
              '&period=' + encodeURIComponent(period) +
              '&offset=' + offset + '&limit=100&continent=' + encodeURIComponent(cont);
            const r = await fetch(url, {
              credentials: 'include', headers: { accept: 'application/json' }
            });
            if (!r.ok) break;          // period inválido o error → siguiente period
            const j = await r.json();
            const items = Array.isArray(j && j.items) ? j.items : [];
            if (items.length) firstPageEmpty = false;
            if (!items.length) break;  // sin más resultados en este period
            for (const it of items) {
              const u = it && it.model && it.model.username;
              if (u && u.toLowerCase() === me) {
                return {
                  position:    it.position,
                  stripPoints: it.stripPoints,
                  total:       (j.total || 1000),
                  gender:      g, continent: cont, period
                };
              }
            }
            if (items.length < 100) break;
          } catch (_) { break; }
        }
        // Si la primera página de este period vino vacía, el period no
        // es válido para este scope → no insistir, probar el siguiente.
        if (firstPageEmpty) continue;
      }
      return null;
    },

    // ── Puesto del leaderboard desde el DOM ──
    // Badge del header del panel propio: "Puesto 1057 en el Top 1000".
    //   <span class="TopModelsAwardLabel__strong">Puesto 1057</span> en el Top 1000
    // Mismo selector que BeCapture v1.8.7. Es la ÚNICA fuente del puesto
    // EXACTO cuando la modelo está FUERA del top 1000 (el colector del
    // server solo captura hasta el 1000). Devuelve:
    //   { puesto, topSize, categoria, rawText } | null
    readRankingDOM: function () {
      try {
        const strongEl = document.querySelector('[class*="TopModelsAwardLabel__strong"]');
        if (!strongEl) return null;
        let full = strongEl.textContent || '';
        const textWrap = strongEl.closest('[class*="TopModelsAwardLabel__text"]')
                       || strongEl.parentElement;
        if (textWrap) full = (textWrap.textContent || '').replace(/\s+/g, ' ').trim();
        const mPuesto = full.match(/(\d[\d.,]*)/);
        const puesto = mPuesto ? parseInt(mPuesto[1].replace(/[.,]/g, ''), 10) : null;
        if (puesto == null) return null;
        const mTop = full.match(/top\s*(\d[\d.,]*)/i);
        const topSize = mTop ? parseInt(mTop[1].replace(/[.,]/g, ''), 10) : null;
        const categoria = topSize === 20   ? 'parejas'
                        : topSize === 1000 ? 'chicas'
                        : topSize === 100  ? 'chicos/trans'
                        : (topSize ? ('top' + topSize) : null);
        return { puesto, topSize, categoria, rawText: full };
      } catch (_) { return null; }
    }
  };

  if (!window.BMPlatforms) window.BMPlatforms = [];
  window.BMPlatforms.push(adapter);
  console.debug('[BeModels.platforms] stripchat registrado');
})();
