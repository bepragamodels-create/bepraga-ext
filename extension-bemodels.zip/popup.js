// BeModels — popup.js
// El popup del ícono es SOLO de diagnóstico y activación manual.
// Todos los ajustes (meta, turno, posición, bridge, TZ, etc.) viven
// en el panel IN-PAGE (botón ⚙ de la barra HUD) para no duplicar
// formularios — regla: "ajustes dentro de la página, no en el popup
// del ícono" (memoria del usuario).
'use strict';
const $ = id => document.getElementById(id);

// Lista CANÓNICA de modelos autorizadas en bemodels/roster.js
// (cargado por popup.html antes que este archivo).
const BM_AUTORIZADAS = window.BM_AUTORIZADAS_SET || new Set();
const isAuth = m => !!m && BM_AUTORIZADAS.has(String(m).toLowerCase().trim());

function hhmm(iso) {
  try {
    const dt = new Date(iso);
    if (isNaN(dt)) return null;
    return dt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  } catch (_) { return null; }
}

function fmtDiag(d) {
  if (!d) return 'Aún sin diagnóstico. Recarga la página de tu sala.';
  const tx = d.streamStart ? (hhmm(d.streamStart) || d.streamStart) : null;
  if (d.selfModel && !isAuth(d.selfModel))
    return '⛔ ' + d.selfModel + ' NO autorizada.\n' +
      'BeModels es de BE PRAGA — esta cuenta no está en la lista.';
  if (d.selfModel) return '✅ Detectada: ' + d.selfModel +
    ' (vía ' + (d.selfSrc || 'auto') + ')' +
    (d.ownShow ? ' · en tu sala' : '') +
    (tx ? '\n· inicio tx detectado: ' + tx
        : '\n· inicio tx: no expuesto (usa "Inicio de turno")');
  return '❌ No detectada todavía.\n' +
    '· /cam HTTP: ' + (d.camHttp != null ? d.camHttp : '—') +
    ' · isOwnShow: ' + (d.camIsOwn != null ? d.camIsOwn : '—') + '\n' +
    '· NEXT_DATA: ' + (d.nextData || '—') + '\n' +
    '· página propia (texto): ' + (d.ownPage ? 'sí' : 'no') + '\n' +
    'Escribe tu usuario arriba y pulsa Activar.';
}

// Render del bloque "HOY / Top": espejo simplificado de lo que ve la
// modelo en la HUD. Read-only, sin formularios.
function fmtToday(all) {
  let best = null;
  for (const k of Object.keys(all || {})) {
    if (/^bemodels_day:/.test(k)) {
      const x = all[k];
      if (x && (!best || x.date > best.date)) best = x;
    }
  }
  if (!best) return 'Sin tips contados aún hoy.';
  const top = Object.entries(best.byUser || {})
    .sort((a, b) => b[1] - a[1]).slice(0, 3)
    .map(x => x[0] + ' (' + x[1] + ')').join(', ');
  const ganado = (best.startBalance != null && best.balance != null)
    ? Math.max(0, best.balance - best.startBalance) : null;
  return (
    best.model + ' · ' + best.date + '\n' +
    (ganado != null
      ? 'GANADO HOY: ' + ganado + ' tk (saldo ' + best.balance +
        ', inicio ' + best.startBalance + ')\n'
      : 'HOY (WS): ' + best.tokens + ' tk · ' + (best.tipsCount || 0) + ' tips\n') +
    'Goals: ' + (best.goalsHit || 0) + '\nTop: ' + (top || '—')
  );
}

function load() {
  chrome.storage.local.get(null, all => {
    const c = (all && all.bemodels_cfg) || {};
    $('manualModel').value = c.manualModel || '';

    const d = all && all.bemodels_diag;
    $('state').textContent = fmtDiag(d);
    const bal = all && all.bemodels_bal;
    const balTxt = bal
      ? ('saldo leído: ' + (bal.v != null ? bal.v + ' tk' : 'no encontrado'))
      : 'saldo: —';
    $('diag').textContent = balTxt + (d && d.build ? ' · build ' + d.build : '');

    $('today').textContent = fmtToday(all);
  });
}

// Guardar SOLO el manualModel (único ajuste que sigue viviendo acá).
function saveManualModel(model) {
  chrome.storage.local.get(['bemodels_cfg'], o => {
    const cur = (o && o.bemodels_cfg) || {};
    cur.manualModel = String(model || '').trim();
    chrome.storage.local.set({ bemodels_cfg: cur }, () => {
      const btn = $('activar');
      const t = btn.textContent;
      btn.textContent = '✓';
      setTimeout(() => { btn.textContent = t; }, 1200);
    });
  });
}

// Abrir el panel de ajustes en la página activa → manda mensaje al
// content script (escucha BEMODELS_OPEN_PANEL) y cierra el popup
// para que la usuaria vuelva a ver la página con el panel abierto.
function openInPagePanel() {
  try {
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      const id = tabs && tabs[0] && tabs[0].id;
      if (id) {
        try { chrome.tabs.sendMessage(id, { type: 'BEMODELS_OPEN_PANEL' }); } catch (_) {}
      }
      try { window.close(); } catch (_) {}
    });
  } catch (_) {}
}

$('activar').addEventListener('click', () => {
  const m = ($('manualModel').value || '').trim();
  if (!m) { $('manualModel').focus(); return; }
  saveManualModel(m);
});
$('openPanel').addEventListener('click', openInPagePanel);

load();
setInterval(load, 4000);   // refresca el diagnóstico en vivo
