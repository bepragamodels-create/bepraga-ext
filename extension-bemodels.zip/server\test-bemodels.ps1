# ============================================================
#  BeModels — test-bemodels.ps1
#  Prueba BeModels SOLA (independiente de BeStudio / del watchdog)
#  en una PC del estudio. Lanza Chrome for Testing con un perfil
#  de PRUEBA aparte cargando UNICAMENTE esta extensión.
#
#  Por qué Chrome for Testing: Chrome normal 148+ bloquea
#  --load-extension. El estudio ya tiene CfT instalado.
#
#  Uso (desde cualquier carpeta):
#    powershell -ExecutionPolicy Bypass -File `
#      C:\BePraga\bepraga-studio\extension-bemodels\server\test-bemodels.ps1
#
#  Parámetros opcionales:
#    -ChromeExe  ruta al chrome.exe de Chrome for Testing
#    -ProfileDir carpeta del perfil de prueba (NO usar uno de modelo)
#    -Url        página a abrir (por defecto stripchat.com)
#
#  NO toca el launcher de BeStudio ni los perfiles de las modelas.
#  Para salir: cierra esa ventana de Chrome.
# ============================================================
param(
  [string]$ChromeExe  = "C:\BePraga\chrome-for-testing\chrome-win64\chrome.exe",
  [string]$ProfileDir = "C:\BePraga\ChromeProfiles\_bemodels_test",
  [string]$Url        = "https://stripchat.com/"
)

# Carpeta de la extensión = carpeta padre de este script (donde está manifest.json)
$ExtPath = Split-Path $PSScriptRoot -Parent
$manifest = Join-Path $ExtPath "manifest.json"

if (-not (Test-Path $manifest)) {
  Write-Host "[BeModels] No encuentro manifest.json en: $ExtPath" -ForegroundColor Red
  Write-Host "  Asegúrate de correr este script desde extension-bemodels\server\ del repo." -ForegroundColor Yellow
  exit 1
}

# Localizar Chrome for Testing
if (-not (Test-Path $ChromeExe)) {
  $alt = @(
    "C:\BePraga\chrome-for-testing\chrome-win64\chrome.exe",
    "C:\BePraga\chrome-for-testing\chrome.exe"
  ) | Where-Object { Test-Path $_ } | Select-Object -First 1
  if ($alt) { $ChromeExe = $alt }
}
if (-not (Test-Path $ChromeExe)) {
  Write-Host "[BeModels] No encuentro Chrome for Testing en: $ChromeExe" -ForegroundColor Red
  Write-Host "  Chrome normal 148+ bloquea --load-extension. Instala CfT con:" -ForegroundColor Yellow
  Write-Host "    extension-bestudio\server\get-chrome-for-testing.ps1" -ForegroundColor Yellow
  Write-Host "  o pasa la ruta:  -ChromeExe `"C:\ruta\chrome.exe`"" -ForegroundColor Yellow
  exit 1
}

New-Item -ItemType Directory -Force -Path $ProfileDir | Out-Null

$ver = (Get-Content $manifest -Raw | ConvertFrom-Json).version
Write-Host "[BeModels] Probando v$ver (SOLO BeModels, independiente)" -ForegroundColor Green
Write-Host "  Extensión : $ExtPath"
Write-Host "  Perfil    : $ProfileDir   (de prueba, NO es de ninguna modelo)"
Write-Host "  Chrome CfT: $ChromeExe"
Write-Host "  Abriendo  : $Url"
Write-Host ""
Write-Host "  Inicia sesión como la modelo en esa ventana y abre su sala." -ForegroundColor Cyan
Write-Host "  La barra/HUD morada debe aparecer. Para terminar, cierra Chrome." -ForegroundColor Cyan

$chromeArgs = @(
  "--user-data-dir=$ProfileDir",
  "--disable-extensions-except=$ExtPath",
  "--load-extension=$ExtPath",
  "--disable-features=DisableLoadExtensionCommandLineSwitch",
  "--no-first-run",
  "--no-default-browser-check",
  $Url
)

Start-Process -FilePath $ChromeExe -ArgumentList $chromeArgs | Out-Null
