// ============================================================
//  BeModels — telegramFetcher.js  (content script, ISOLATED world)
//  Consulta al bridge HTTP del server BeStudio (extension-bestudio/
//  server/bridge.ps1) para obtener el inicio REAL de transmision
//  de la modelo, leido del canal Telegram BE PRAGA ONLINE (🟢/📡).
//
//  Stripchat no expone una hora confiable de "broadcast started":
//  statusChangedAt cambia con cualquier transicion de modo. El
//  Telegram bot SI publica el momento exacto y el server lo persiste.
//  Este modulo solo trae el dato; effStart() en content.js le da
//  prioridad alta (debajo solo del override manual).
//
//  Endpoint del bridge (server-side):
//    GET <bridgeUrl>/api/start?model=<username>
//    → { "model":"<x>", "startedAt":"<ISO>", "source":"telegram" }
//    o { "startedAt": null } si la modelo no esta en el live set.
//
//  El bridge corre en el server del estudio (puerto 7878 default).
//  Para uso desde casa, montar Cloudflare Tunnel sobre el puerto y
//  usar la URL publica en el campo "Bridge Telegram" del popup.
//
//  Errores silenciosos (return null) — un fallo de red no debe
//  romper la UI; effStart() cae al siguiente fallback.
// ============================================================
(function () {
  'use strict';
  const TAG = '[BeModels.tg]';

  // Helper: construye headers con Bearer token opcional.
  function authHeaders(token) {
    const h = { accept: 'application/json' };
    if (token) h.Authorization = 'Bearer ' + String(token).trim();
    return h;
  }

  // Devuelve { startedAt:ms|null, isLive:bool, error:bool }
  //  - isLive=true  → la modelo esta en el set "live" del launcher
  //                   (Telegram acaba de mandar 🟢/📡 y NO ha llegado 🔴).
  //  - isLive=false → ya no esta en el set → el show CERRO.
  //  - error=true   → fallo de red o respuesta invalida → el caller
  //                   NO debe cerrar el show (puede ser un glitch).
  async function getStart(model, bridgeUrl, authToken) {
    const fail = { startedAt: null, isLive: false, error: true };
    if (!model || !bridgeUrl) return fail;
    const base = String(bridgeUrl).trim().replace(/\/+$/, '');
    if (!base || !/^https?:\/\//i.test(base)) return fail;
    const url = base + '/api/start?model=' + encodeURIComponent(String(model).toLowerCase().trim());
    try {
      const r = await fetch(url, {
        credentials: 'omit', cache: 'no-store',
        headers: authHeaders(authToken)
      });
      if (r.status === 401) {
        console.warn(TAG, '401 unauthorized — revisar bridgeAuthToken en popup');
        return fail;
      }
      if (!r.ok) { console.debug(TAG, 'http', r.status, model); return fail; }
      const j = await r.json();
      if (!j || !j.startedAt) {
        console.debug(TAG, 'sin startedAt (modelo OFFLINE en el set live)', model);
        return { startedAt: null, isLive: false, error: false };
      }
      const t = Date.parse(j.startedAt);
      if (isNaN(t)) { console.debug(TAG, 'fecha invalida', j.startedAt); return fail; }
      console.debug(TAG, 'startedAt', j.startedAt, '· source=' + (j.source || '?'), '· model=' + model);
      return { startedAt: t, isLive: true, error: false };
    } catch (e) {
      console.debug(TAG, 'err', e && e.message);
      return fail;
    }
  }

  // Endpoints REST nuevos (v0.3.0 del bridge): consultar datos del server.
  // postSummary también lleva el token si está configurado.
  async function fetchJson(path, bridgeUrl, authToken) {
    if (!bridgeUrl) return { ok: false, error: 'no_bridge_url' };
    const base = String(bridgeUrl).trim().replace(/\/+$/, '');
    if (!base || !/^https?:\/\//i.test(base)) return { ok: false, error: 'bad_url' };
    try {
      const r = await fetch(base + path, {
        credentials: 'omit', cache: 'no-store',
        headers: authHeaders(authToken)
      });
      if (r.status === 401) return { ok: false, error: 'unauthorized', http: 401 };
      const j = await r.json().catch(() => null);
      if (!r.ok) return { ok: false, error: 'http_' + r.status, http: r.status, body: j };
      return j || { ok: false, error: 'empty_response' };
    } catch (e) {
      return { ok: false, error: 'network', message: e && e.message };
    }
  }

  // Listar todas las modelos disponibles en el server.
  async function listModels(bridgeUrl, authToken) {
    return fetchJson('/api/models', bridgeUrl, authToken);
  }

  // Listar archivos JSON de UNA modelo.
  async function listFiles(model, bridgeUrl, authToken) {
    if (!model) return { ok: false, error: 'no_model' };
    return fetchJson('/api/files/' + encodeURIComponent(model.toLowerCase().trim()), bridgeUrl, authToken);
  }

  // Contenido de un JSON específico (modelo + fecha YYYY-MM-DD).
  async function getFile(model, fecha, bridgeUrl, authToken) {
    if (!model || !fecha) return { ok: false, error: 'missing_params' };
    return fetchJson('/api/file/' + encodeURIComponent(model.toLowerCase().trim()) + '/' + encodeURIComponent(fecha),
                     bridgeUrl, authToken);
  }

  // Atajo: último archivo del día actual.
  async function getToday(model, bridgeUrl, authToken) {
    if (!model) return { ok: false, error: 'no_model' };
    return fetchJson('/api/today/' + encodeURIComponent(model.toLowerCase().trim()), bridgeUrl, authToken);
  }

  window.BMTelegram = { getStart, listModels, listFiles, getFile, getToday };
  console.debug(TAG, 'modulo cargado (v0.2 con auth + endpoints REST)');
})();
