// ============================================================
//  BeModels — platforms/base.js  (content script, ISOLATED world)
//
//  Sistema de adaptadores por plataforma. BeModels arrancó solo
//  para Stripchat; ahora se está expandiendo a Chaturbate, Cam4,
//  Streamate y XLoveCam. Cada plataforma tiene una manera distinta
//  de detectar la modelo, obtener earnings, leer balance, etc.
//
//  Este archivo define la INTERFAZ común y un registry global
//  (window.BMPlatforms). Cada archivo en platforms/<nombre>.js se
//  auto-registra al cargar (push a window.BMPlatforms). content.js
//  consulta window.BMPlatform.getActive() para obtener el adapter
//  cuyo hostMatches(location.hostname) devuelva true.
//
//  ── Interfaz del adapter ───────────────────────────────────────
//  Cada adapter es un objeto plano con estos campos:
//
//    name        : string identificador ('stripchat', 'chaturbate', ...)
//    hostMatches : (host: string) => boolean
//                  Devuelve true si este adapter sirve para el host.
//
//    // Identidad de la modelo
//    detectSelf  : async () => { username, userId, isOwnShow } | null
//                  Detecta la cuenta logueada y si está viendo su
//                  propia sala. Si la plataforma usa postMessage
//                  (Stripchat), puede devolver null y el adapter
//                  registrarse al sistema de mensajes aparte.
//
//    // Earnings (rango de fechas)
//    fetchEarningsRange : async (userId, fromIso, untilIso) =>
//                          { tokens, usd, tx[], ... } | null
//                  Suma de tokens ganados en el rango + lista de tx
//                  individuales (ts, tokens, user) para agrupar por
//                  día / sesión.
//
//    // Conversión de moneda
//    tkToUsd     : (tk: number) => number   (USD bruto, antes del share)
//    modelShare  : number 0..1  (% que recibe la modelo después de
//                                comisión de la plataforma)
//
//    // Etiquetas para el UI
//    tokenLabel    : string  ('tk', 'gold', 'crédito', ...)
//    currencyLabel : string  ('USD', 'EUR', ...)
//
//    // Opcional — saldo del header de la plataforma
//    readBalanceDOM : () => number | null
//
//    // Opcional — TZ del perfil
//    profileTz : async () => string | null   (IANA: 'America/Bogota')
//
//    // Opcional — WebSocket de tips en vivo
//    subscribeWS : (onTip, onGoal) => unsubscribeFn | null
//
//  Plataformas per-minuto (Streamate, XLoveCam): en vez de tk
//  individuales, devuelven el agregado del día y el adapter expone
//  isPerMinute=true. content.js oculta métricas inaplicables (RITMO
//  en tk/min) y muestra "$/h en privado" en su lugar.
// ============================================================
(function () {
  'use strict';

  // Registry global. Cada adapter hace window.BMPlatforms.push(adapter)
  // al cargar (ver platforms/stripchat.js como ejemplo).
  if (!window.BMPlatforms) window.BMPlatforms = [];

  // Devuelve el adapter cuyo hostMatches() acepta el hostname actual.
  // Si ninguno coincide, devuelve null y content.js queda en modo
  // pasivo (no muestra HUD, log de debug).
  function getActive() {
    const host = (location && location.hostname) || '';
    for (const a of window.BMPlatforms) {
      try {
        if (a && typeof a.hostMatches === 'function' && a.hostMatches(host)) {
          return a;
        }
      } catch (_) { /* adapter mal escrito → ignorar */ }
    }
    return null;
  }

  // Para debug: lista todos los adapters registrados (independiente
  // del hostname). Útil desde DevTools console.
  function listRegistered() {
    return window.BMPlatforms.map(a => a && a.name).filter(Boolean);
  }

  window.BMPlatform = { getActive, listRegistered };
  console.debug('[BeModels.platforms] base cargado · registry creado');
})();
