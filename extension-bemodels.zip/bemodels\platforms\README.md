# BeModels Platform Adapters

BeModels originalmente fue **solo Stripchat**. Para soportar Chaturbate,
Cam4, Streamate, XLoveCam y futuras plataformas sin duplicar código,
usamos un sistema de **adapters por plataforma**.

## Estructura

```
platforms/
  base.js           ← registry global window.BMPlatforms[] + getActive()
  stripchat.js      ← adapter Stripchat (wrappea BMEarn/BMProfile existentes)
  chaturbate.js     ← pendiente (Paso 2)
  cam4.js           ← pendiente
  streamate.js      ← pendiente (per-minute)
  xlovecam.js       ← pendiente (per-minute, EUR)
```

## Interfaz que debe cumplir un adapter

Cada adapter es un objeto plano. Mínimo viable (MVP "GANADO + EN VIVO"):

```js
{
  name: 'chaturbate',                       // identificador
  hostMatches: (host) => /chaturbate\.com$/.test(host),

  // Si la plataforma usa postMessage para identidad (injected MAIN world),
  // detectSelf devuelve null y se maneja por fuera. Sino, devuelve aquí
  // el objeto { username, userId, isOwnShow }.
  detectSelf: async () => null,

  // Earnings por rango de fechas. Devuelve { tokens, usd, tx: [...] }.
  // Si la plataforma NO expone un API público, devolver null y BeModels
  // cae a heurísticas (DOM scraping, WS).
  fetchEarningsRange: async (userId, fromIso, untilIso) => null,

  // Conversión moneda. Cada plataforma tiene su tasa.
  tkToUsd: (tk) => (Number(tk) || 0) * 0.05,   // ejemplo Chaturbate (gross)
  modelShare: 0.50,                            // % que recibe la modelo
  tokenLabel: 'tk',                            // 'tk' | 'gold' | 'crédito'
  currencyLabel: 'USD',

  // Modelo de negocio: tip+goal o per-minute.
  isPerMinute: false,

  // Opcionales — pueden ser null:
  readBalanceDOM: () => number | null,
  profileTz: async () => string | null,
  subscribeWS: (onTip, onGoal) => unsubFn | null
}
```

Al final del archivo del adapter, **auto-registrarse**:

```js
if (!window.BMPlatforms) window.BMPlatforms = [];
window.BMPlatforms.push(adapter);
```

## Pasos para agregar una plataforma nueva

1. **Crear `platforms/<nombre>.js`** con el adapter (copiar `stripchat.js`
   como template).
2. **Agregar al `manifest.json`**:
   - `content_scripts[].matches`: agregar `https://*.<plataforma>.com/*`.
   - `content_scripts[].js`: agregar `bemodels/platforms/<nombre>.js`
     después de `bemodels/platforms/base.js` y antes de `content.js`.
   - `host_permissions`: agregar `https://*.<plataforma>.com/*`.
3. **Investigar el API de la plataforma**:
   - Endpoint de earnings (red DevTools en pestaña de la modelo).
   - Selector DOM del balance.
   - Cómo se detecta el username logueado (cookies, NEXT_DATA, etc.).
4. **Implementar `fetchEarningsRange`** primero. Es lo que necesita el
   MVP (GANADO + EN VIVO).
5. **Probar**: instalar la extensión, abrir la plataforma, F12 →
   `window.BMPlatform.listRegistered()` debe incluir tu plataforma.
   `window.BMPlatform.getActive().name` debe devolver tu plataforma.
6. **Documentar peculiaridades** en este README (tasa actual, edge
   cases, etc.).

## Convención de tasas (snapshot 2026-05)

| Plataforma  | $/unidad bruto | Share modelo | Unidad   |
|-------------|---------------:|-------------:|----------|
| Stripchat   | $0.05         | 55%          | tk       |
| Chaturbate  | $0.05         | 50%          | tk       |
| Cam4        | $0.10         | 50%          | tk       |
| Streamate   | $0.50/min     | 35%          | gold     |
| XLoveCam    | €0.13         | 40%          | crédito  |

Tasas pueden cambiar. Si la plataforma actualiza su esquema, editar el
campo `modelShare` y `tkToUsd` del adapter correspondiente. content.js
no necesita tocarse.

## Plataformas per-minute (Streamate, XLoveCam)

Estas plataformas no tienen tips/goals tradicionales. La modelo cobra
por minuto cuando un usuario entra en privado. Métricas del HUD se
adaptan:

- En vez de "tk/h" → "$/h en privado"
- En vez de "ETA meta" → "ratio privado vs free chat"
- Sin sugerencias basadas en goal % (no hay goal)

El campo `isPerMinute: true` del adapter le indica a content.js que
muestre métricas alternativas. Actualmente content.js asume tip+goal;
cuando implementemos Streamate/XLoveCam haremos branch del render.

## Debug

```js
// En DevTools console de la página:
window.BMPlatform.listRegistered()
// → ['stripchat', 'chaturbate', ...]

window.BMPlatform.getActive()
// → adapter object o null si no matchea
```
