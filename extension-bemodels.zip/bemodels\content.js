// ============================================================
//  BeModels — content.js  (ISOLATED world)
//  - Escucha los postMessage de injected.js (SELF / CAM / TIP /
//    GOAL_EVT) SOLO cuando la sala es la PROPIA de la modelo.
//  - Acumula el dia en chrome.storage.local (por modelo+fecha).
//  - Dibuja la barra HUD inferior con: total del dia, promedio
//    tk/hora, progreso meta diaria + proyeccion, progreso/ETA del
//    goal de Stripchat, alerta de ballenas y sugerencias.
//  Dibuja la barra SOLO si hay modelo propia detectada → en la
//  sala de otra modelo / navegacion normal NO aparece.
// ============================================================
(function () {
  'use strict';

  // Log de bienvenida con versión visible para diagnóstico rápido.
  // Sirve para confirmar qué versión está corriendo en la PC de la
  // modelo (chrome.runtime no se ve desde page-context console, así
  // que esta es la forma más simple de verificar).
  try {
    const _v = chrome.runtime.getManifest().version;
    console.log('%c[BeModels] v' + _v + ' cargado en ' + location.hostname,
      'background:#5409A9;color:#fff;padding:2px 8px;border-radius:4px;font-weight:bold');
  } catch (_) {}

  // Detección de plataforma activa (Stripchat / Chaturbate / Cam4 /
  // Streamate / XLoveCam). Cada adapter vive en platforms/<nombre>.js
  // y se auto-registra. content.js todavía asume tip+goal Stripchat
  // en su mayor parte; ir migrando gradualmente al adapter. Si el
  // hostname no matchea ningún adapter, BeModels queda inactivo.
  const PLATFORM = (window.BMPlatform && window.BMPlatform.getActive) ?
    window.BMPlatform.getActive() : null;
  if (PLATFORM) {
    console.debug('[BeModels] plataforma activa:', PLATFORM.name,
      '· share=' + PLATFORM.modelShare,
      '· perMinute=' + !!PLATFORM.isPerMinute);
  } else {
    console.debug('[BeModels] sin plataforma registrada para',
      location.hostname, '· registrados =',
      window.BMPlatform ? window.BMPlatform.listRegistered() : 'BMPlatform no cargo');
  }

  const DEFAULT_CFG = {
    dailyGoalTk:   2000,   // meta de tokens del dia
    whaleSingleTk: 200,    // 1 tip >= esto → alerta ballena (gateada por whaleAlertsEnabled)
    whaleCumTk:    500,    // total acumulado de 1 usuario >= esto → ballena (idem)
    whaleAlertsEnabled: false, // OFF por defecto: la usuaria pidio ocultar las
                               // alertas/balance-scan hasta que la herramienta de
                               // gestion de ballenas este implementada.
    barEnabled:    true,
    demo:          false,  // modo prueba: HUD + tips sinteticos sin transmitir
    manualModel:   '',     // activacion manual si el auto-detect falla
    turnStart:     '',     // inicio de turno manual "HH:MM" (hora local tz)
    shiftGoalH:    6,      // duracion objetivo del turno (horas) para la barra
    whaleBalanceTk: 1000,  // avisar si un usuario en sala tiene >= esto de balance
    alertHidden:   true,   // avisar tambien de los que OCULTAN su balance
    // posicion de la barra HUD por default: TOP. Pedido de la usuaria
    // (2026-06-02): "quiero que por defecto aparezca arriba". Modelos
    // existentes con storage previo mantienen su última config (no
    // se les pisa). Modelos NUEVAS arrancan con 'top'.
    barPos:        'top',    // posicion de la barra: floating|bottom|top|left|right
    // Modo flotante: el HUD aparece como botón draggeable con el
    // logo + tiempo + tokens. Click sobre el brand expande/colapsa
    // los segmentos. floatX/floatY se persisten al soltar el drag.
    floatX:        null,    // px desde la izquierda (null = derecha 14)
    floatY:        null,    // px desde arriba       (null = top 80)
    floatExpanded: false,   // si arranca expandido o colapsado
    // URL del bridge BeStudio. HARDCODED al Cloudflare Tunnel (HTTPS)
    // en vez de la IP LAN porque:
    // 1. Stripchat es HTTPS → fetch a http://192.168.x daría mixed-content.
    // 2. El bridge en el server escucha SOLO en 127.0.0.1 (config
    //    recomendada por memoria del proyecto: "BridgeBind = '127.0.0.1'
    //    SIEMPRE; 0.0.0.0/+ requiere URL ACL"), no es alcanzable
    //    desde la LAN directamente → ERR_CONNECTION_REFUSED.
    // El tunnel forwardea al loopback del server; mi Test-IsTrustedLAN
    // del bridge.ps1 (v0.7.1+) acepta loopback sin Bearer → BeModels
    // funciona sin que la usuaria deba configurar token alguno.
    // Override editable en el panel para casos especiales.
    bridgeUrl:     'https://bestudio.bepraga.com',
    bridgeAuthToken: '',     // Bearer token si el bridge tiene auth. Vacio = sin auth.
                             // Necesario solo si /api/start o /api/summary tienen
                             // Bearer estricto (default actual: loopback sin Bearer).
    summaryToTelegram: true, // al cierre del show, POST resumen al canal Telegram
                             // (via bridge → BE PRAGA Studio). Requiere bridgeUrl.
    // Botón "🌐 Traductor" en SUGERENCIAS — desactivado por default
    // hasta que BeTranslate implemente el listener BEMODELS_CMD/
    // TOGGLE_TRANSLATE. Cuando esté listo, cambiar a true (o agregar
    // toggle al panel). 2026-06-02: la usuaria lo apagó porque no se
    // usa hoy.
    translatorButtonEnabled: false,
    // Customizacion de color del fondo de la barra HUD. Vacio o null =
    // gradiente morado BE PRAGA (default). Cualquier color CSS valido
    // (#hex, rgb(), nombre) reemplaza el fondo con un gradiente
    // generado a partir de ese color. El borde superior y el acento del
    // brand se mantienen en morado para no perder identidad de estudio.
    hudBgColor:    '',
    // Moneda mostrada en los montos del HUD. Toggle USD ↔ COP haciendo
    // click en el monto del HUD. Fórmula COP = USD_bruto × share × tasa
    // (calculadora oficial: https://bepraga.com/calculadora-webcam/).
    currency:      'USD',
    copShareFactor: 0.55,  // % que recibe la modelo (Stripchat se queda 45%)
    copRate:       3449,   // tasa COP/USD (editable en panel/Avanzado)
    // Scope del leaderboard de Stripchat para buscar el puesto de la
    // modelo via API directa (fallback del segmento TOP). El estudio
    // es colombiano → female/sa por default. Editable si hay parejas
    // (couples) o modelos de otro continente.
    rankGender:    'female',  // female | couples | trans | male
    rankContinent: 'sa',      // sa | na | eu | as | ...
    tz:            'America/Bogota'
  };

  const _intelSeen  = {};   // username → balance ya alertado (dedupe)
  const _hiddenSeen = {};   // username → ya avisado que oculta balance

  let _apiStreamStart = null;   // inicio de transmision detectado del payload
  // Sesion de transmision actual: persistida POR MODELO (no por dia) para
  // sobrevivir el cruce de medianoche si la sesion es continua. Si hay un
  // gap > SESSION_GAP_MS entre dos STREAM con isLive=true, se inicia una
  // nueva sesion (startedAt nuevo). Guardado en bemodels_session:<MODEL>.
  let _session = null;          // { startedAt:ms, lastLiveAt:ms }
  const SESSION_GAP_MS = 5 * 60 * 1000;
  // Inicio de transmision via bridge HTTP del server BeStudio (lectura
  // del canal Telegram BE PRAGA ONLINE 🟢/📡). Fuente AUTORITATIVA.
  let _tgStart = null;          // ms epoch del primer 🟢/📡 de la sesion
  let _tgNextAt = 0;            // proximo poll permitido
  let _tgOffStreak = 0;         // polls consecutivos con isLive=false
  let _tgClosedAt  = null;      // ms en que detectamos el cierre (🔴)
  let _frozenStart = null;      // effStart() congelado al momento del cierre
  // Diagnostico del ultimo poll al bridge — para mostrar en el panel.
  let _tgLastPollAt   = null;   // ms del ultimo intento de poll
  let _tgLastPollRes  = null;   // 'live' | 'offline' | 'error'
  // Tras N polls consecutivos de "no esta live" tratamos el show como
  // CERRADO. Bajado de 2 a 1 (2026-06-05, pedido de la operadora: el
  // cierre tardaba ~2 min). Con 1 poll offline LIMPIO (no error) el
  // cierre se detecta en el siguiente poll (~60s) en vez de ~120s. El
  // launcher es estable (TTL 8h, dedup) asi que el riesgo de falso
  // cierre por un offline transitorio es bajo; si reabre, el dedup
  // del bridge evita un segundo resumen.
  const TG_OFF_THRESHOLD = 1;
  // Ultimo GANADO bueno conocido (> 0). Se usa como respaldo del
  // resumen de cierre si analytics() da 0 por un estado raro de _earn
  // al momento del cierre (bug del resumen "0 tk" reportado 2026-06-05).
  let _lastGoodTot = 0;

  function sendForce(model) {
    if (!model) return;
    try { window.postMessage({ source: 'BEMODELS_CMD', kind: 'FORCE',
      model: String(model).trim() }, '*'); } catch (_) {}
  }

  const DEMO_MODEL = '(demo)';

  // ── Candado: modelos autorizadas. La lista CANÓNICA vive en
  //    bemodels/roster.js (window.BM_AUTORIZADAS_SET) y es cargada
  //    como content script ANTES que este archivo (ver manifest).
  //    BeStudio sigue teniendo su propia copia paralela en
  //    begoals/background.js MODELOS_AUTORIZADAS_BG — sincronizar
  //    a mano cuando entra/sale una modelo. Fuera de la lista: no se
  //    muestra la barra ni se cuenta nada. ────────────────────────
  const BM_AUTORIZADAS = (typeof window !== 'undefined' && window.BM_AUTORIZADAS_SET)
    ? window.BM_AUTORIZADAS_SET
    : new Set();  // fallback defensivo; debería estar SIEMPRE seteado
  function isAuthorized(m) {
    return !!m && BM_AUTORIZADAS.has(String(m).toLowerCase().trim());
  }
  // Activa = hay modelo y es demo o está autorizada.
  function authedActive() {
    return MODEL && (MODEL === DEMO_MODEL || isAuthorized(MODEL));
  }

  let CFG = Object.assign({}, DEFAULT_CFG);
  let MODEL = null;
  let MODEL_NAME = null;     // nombre para mostrar en el saludo
  let _ownShow = false;      // la sala abierta es la propia (de injected)
  let _realModel = null;     // username detectado en sala propia (manda sobre demo)
  let _demoT = null;         // timer del feeder de demo
  let DAY = null;            // objeto del dia actual (en memoria, espejo de storage)
  let _dayKey = null;
  let _saveT = null;
  let _recent = [];          // tips recientes [{tk,ts}] para ritmo tk/min
  let _lastGoal = null;      // ultimo cam.goal de Stripchat
  let _whaleSeen = {};       // user → max acumulado ya alertado
  let _bar = null;



  // Ganado del dia desde el endpoint OFICIAL de Stripchat
  // (earningsFetcher.js → window.BMEarn). Fuente autoritativa:
  // sobreescribe el calculo delta-de-saldo (ya no se "adultera"
  // por arranque tardio).
  let SELF_USER_ID = null;   // userId numerico de la cuenta logueada
  let _earn        = null;   // { tokens, usd, count, from, until, ts }
  let _earnNextAt  = 0;

  // Histórico cargado desde chrome.storage (bemodels_day:<modelo>:<fecha>)
  // para la COMPARATIVA y la vista 7 días del panel. Se carga al SELF
  // event y se refresca cada 30 min. Estructura:
  //   { byDate: { 'YYYY-MM-DD': dayObj }, last7: [], week7Avg, yesterday }
  let _historic       = null;

  // Ranking Top 1000 de Stripchat (v5/top leaderboard) — desde el
  // bridge GET /api/stripchat-ranking/latest. Lo refrescamos cada
  // 15 min porque el colector del server corre cada hora; chequear
  // más seguido no aporta. Solo aplica en Stripchat.
  // Estructura: { collectedAt, models: [{ username, position,
  // stripPoints, country, ... }] }
  let _ranking       = null;     // snapshot completo (objeto JSON)
  let _rankingMine   = null;     // entry del modelo actual (o null si fuera del top)
  let _rankingNextAt = 0;

  // Award del DOM (badge "Puesto N en el Top X" de la página). El badge
  // SOLO aparece en ciertas páginas (top/leaderboard, creator portal) —
  // NO en la sala de transmisión donde BeModels vive el 90% del tiempo.
  // Por eso lo PERSISTIMOS: cuando la modelo navega a una página que lo
  // muestra, lo capturamos y guardamos en chrome.storage por modelo. En
  // la transmisión usamos el último conocido (mostrando hace cuánto).
  // { puesto, topSize, categoria, ts } | null
  let _awardDOM = null;

  // StripScore + métricas del broadcast-center (Stripchat). Viene del
  // endpoint /api/front/models/<uid>/broadcast-center. Refresca cada
  // 5 min. { stripScore, favoritedCount, tokensPerHour, privateShowRating, ts }
  let _bcenter       = null;
  let _bcenterNextAt = 0;
  let _historicNextAt = 0;

  // TZ del perfil de Stripchat (auto-detectada via BMProfile).
  // Stripchat agrega "el dia" segun esta TZ, NO segun CFG.tz. Si las
  // dos no coinciden, los totales no cuadran. _detectedTz gana sobre
  // CFG.tz cuando esta disponible; CFG.tz queda como override manual
  // (panel) y como fallback si la deteccion no funciona.
  let _detectedTz       = null;  // IANA string, p.ej. 'America/Bogota'
  let _detectedTzSrc    = null;  // 'next' | 'me' | 'byId'
  let _tzDetectTried    = false;
  function effectiveTz() { return _detectedTz || CFG.tz || 'America/Bogota'; }

  // ── Fechas (zona horaria configurable) ─────────────────────────────────────
  function localDateStr(ts) {
    try {
      return new Intl.DateTimeFormat('en-CA', {
        timeZone: effectiveTz(), year: 'numeric', month: '2-digit', day: '2-digit'
      }).format(new Date(ts || Date.now()));
    } catch (_) {
      return new Date(ts || Date.now()).toISOString().slice(0, 10);
    }
  }
  function localHour(ts) {
    try {
      return Number(new Intl.DateTimeFormat('en-GB', {
        timeZone: effectiveTz(), hour: '2-digit', hour12: false
      }).format(new Date(ts || Date.now())));
    } catch (_) { return new Date(ts || Date.now()).getHours(); }
  }
  function localMinute(ts) {
    try {
      return Number(new Intl.DateTimeFormat('en-GB', {
        timeZone: effectiveTz(), minute: '2-digit'
      }).format(new Date(ts || Date.now())));
    } catch (_) { return new Date(ts || Date.now()).getMinutes(); }
  }
  // Epoch (ms) de "hoy a las HH:MM" en la zona horaria configurada.
  function todayAt(hhmm) {
    const m = /^(\d{1,2}):(\d{2})$/.exec(String(hhmm || '').trim());
    if (!m) return null;
    const target = (+m[1]) * 60 + (+m[2]);
    const now = Date.now();
    const cur = localHour(now) * 60 + localMinute(now);
    let diff = cur - target;            // minutos desde el inicio del turno
    if (diff < 0) diff += 24 * 60;      // turno empezo "ayer" cruzando medianoche
    if (diff > 18 * 60) return null;    // demasiado lejos → ignorar
    return now - diff * 60000;
  }
  // Inicio efectivo de transmision (orden de prioridad):
  //  1. Turno manual (CFG.turnStart "HH:MM" hoy en CFG.tz) — gana siempre.
  //  2. Bridge Telegram (_tgStart) — fuente AUTORITATIVA del 🟢/📡 que
  //     el server captura del canal BE PRAGA ONLINE. Si esta disponible
  //     siempre gana sobre las heuristicas locales.
  //  3. Sesion en curso (_session.startedAt) — sobrevive cruce de medianoche.
  //  4. DAY.streamStart — legacy, por compat con dias antiguos.
  //  5. _apiStreamStart en memoria.
  //  6. DAY.firstTs (fallback: cuando llego BeModels hoy).
  function effStart() {
    // Si el show CERRO (🔴 detectado), todo queda congelado en el ts
    // del show que acabo de terminar para que GANADO/RITMO/EN VIVO
    // reflejen la sesion completa cerrada y no caigan en 0 ni se
    // confundan con un show futuro hasta que llegue un 🟢 nuevo.
    if (_tgClosedAt && _frozenStart) return _frozenStart;
    const man = todayAt(CFG.turnStart);
    if (man != null) return man;
    if (_tgStart) return _tgStart;
    if (_session && _session.startedAt) return _session.startedAt;
    if (DAY && DAY.streamStart) return DAY.streamStart;
    if (_apiStreamStart) return _apiStreamStart;
    return DAY ? DAY.firstTs : Date.now();
  }
  // Etiqueta de la fuente activa (para la barra: " · TG" si viene de
  // Telegram, "" si viene de las heuristicas locales).
  function effStartSource() {
    if (_tgClosedAt && _frozenStart) return 'frozen';
    if (todayAt(CFG.turnStart) != null) return 'manual';
    if (_tgStart) return 'tg';
    if (_session && _session.startedAt) return 'sesion';
    if (DAY && DAY.streamStart) return 'streamStart';
    if (_apiStreamStart) return 'apiStreamStart';
    return 'firstTs';
  }

  // ── Storage ────────────────────────────────────────────────────────────────
  function dayKeyFor(model, ts) { return 'bemodels_day:' + model + ':' + localDateStr(ts); }

  function loadCfg() {
    return new Promise(res => {
      try {
        chrome.storage.local.get(['bemodels_cfg'], o => {
          CFG = Object.assign({}, DEFAULT_CFG, (o && o.bemodels_cfg) || {});
          // Rehidratacion: si una install vieja guardo bridgeUrl="" (antes
          // del v0.1.48 el default era vacio), el "" gana sobre el default
          // porque Object.assign lo cuenta como valor. Lo reseteamos.
          if (!CFG.bridgeUrl || !CFG.bridgeUrl.trim()) {
            CFG.bridgeUrl = DEFAULT_CFG.bridgeUrl;
          }
          // Migracion v0.1.48 -> v0.1.54: el default LAN no funcionaba
          // (bridge en 127.0.0.1 + mixed-content). Reemplazamos por la
          // URL del Cloudflare Tunnel cualquier valor que sea el LAN
          // viejo. Si la usuaria puso una URL custom DISTINTA, la
          // respetamos.
          const BROKEN_LAN = /^https?:\/\/192\.168\.88\.120:7878\/?$/i;
          if (BROKEN_LAN.test(CFG.bridgeUrl.trim())) {
            console.warn('[BeModels] migro bridgeUrl LAN (no funciona desde HTTPS) ->',
              DEFAULT_CFG.bridgeUrl);
            CFG.bridgeUrl = DEFAULT_CFG.bridgeUrl;
            // Persistir la migracion para que no se repita el warn
            // en cada loadCfg.
            try {
              chrome.storage.local.get(['bemodels_cfg'], o2 => {
                const cur = (o2 && o2.bemodels_cfg) || {};
                cur.bridgeUrl = DEFAULT_CFG.bridgeUrl;
                chrome.storage.local.set({ bemodels_cfg: cur });
              });
            } catch (_) {}
          }
          res();
        });
      } catch (_) { res(); }
    });
  }

  function freshDay(model, ts) {
    return {
      model, date: localDateStr(ts), tokens: 0,
      byUser: {}, hours: {}, firstTs: ts, lastTs: ts,
      goalsHit: 0, tipsCount: 0,
      startBalance: null,   // saldo (tk) la 1a vez que se lee hoy
      balance:      null,   // saldo (tk) actual leido del header
      streamStart:  null    // inicio de transmision (ms) detectado del payload
    };
  }

  // ── Lectura del SALDO del header de Stripchat ("1225 tk") ──────────────────
  // Es el valor de ingresos que ya muestra la pagina. Mucho mas fiable que
  // interceptar el WS: ganado hoy = saldo actual - saldo al iniciar el dia.
  let _balEl = null;
  function balNum(t) {
    t = (t || '').replace(/ /g, ' ').trim();
    if (!/^\d[\d.,\s]{0,12}\s*tk$/i.test(t)) return null;
    const d = t.replace(/[^\d]/g, '');
    return d ? Number(d) : null;
  }
  function digits(s) {
    const d = String(s == null ? '' : s).replace(/[^\d]/g, '');
    return d ? Number(d) : null;
  }
  function readBalance() {
    try {
      // 1) Elemento exacto por clase. Confirmado en trafico real:
      //    <span class="TokensAmount__amount#sq tokens-amount">1225</span>
      //    (texto = solo digitos; el "tk" es un hermano aparte).
      if (_balEl && document.contains(_balEl)) {
        const n = digits(_balEl.textContent);
        if (n != null) return n;
        _balEl = null;
      }
      const el = document.querySelector(
        '[class*="TokensAmount__amount"], [class~="tokens-amount"], [class*="tokens-amount"]');
      if (el) {
        const n = digits(el.textContent);
        if (n != null && n >= 0) { _balEl = el; return n; }
      }
      // 2) Respaldo: texto "N tk" en la barra superior (el mas a la derecha)
      let best = null;
      const nodes = document.querySelectorAll('a,button,span,div');
      for (const node of nodes) {
        const t = (node.textContent || '').trim();
        if (!t || t.length > 14) continue;
        const n = balNum(t);
        if (n == null || n <= 0) continue;
        const r = node.getBoundingClientRect();
        if (r.top < 0 || r.top > 170 || r.width === 0) continue;
        if (!best || r.left > best.left) best = { el: node, n, left: r.left };
      }
      if (best) { _balEl = best.el; return best.n; }
      return null;
    } catch (_) { return null; }
  }

  function ensureDay(ts) {
    const k = dayKeyFor(MODEL, ts);
    if (k === _dayKey && DAY) return Promise.resolve();
    _dayKey = k;
    return new Promise(res => {
      try {
        chrome.storage.local.get([k], o => {
          DAY = (o && o[k]) || freshDay(MODEL, ts);
          res();
        });
      } catch (_) { DAY = freshDay(MODEL, ts); res(); }
    });
  }

  function saveDaySoon() {
    if (_saveT) return;
    _saveT = setTimeout(() => {
      _saveT = null;
      if (!DAY || !_dayKey) return;
      try { chrome.storage.local.set({ [_dayKey]: DAY }); } catch (_) {}
    }, 1500);
  }

  // ── Ingesta de tips ────────────────────────────────────────────────────────
  function addTip(t) {
    if (!authedActive()) return;
    const ts = t.ts || Date.now();
    ensureDay(ts).then(() => {
      DAY.tokens    += t.tokens;
      DAY.tipsCount += 1;
      DAY.lastTs     = ts;
      const h = localHour(ts);
      DAY.hours[h] = (DAY.hours[h] || 0) + t.tokens;
      const u = t.anon ? '(anonimo)' : (t.username || t.userId || '(desconocido)');
      DAY.byUser[u] = (DAY.byUser[u] || 0) + t.tokens;

      _recent.push({ tk: t.tokens, ts });
      const cut = Date.now() - 20 * 60 * 1000;
      while (_recent.length && _recent[0].ts < cut) _recent.shift();

      checkWhale(u, t.tokens, DAY.byUser[u]);
      saveDaySoon();
      render();
    });
  }

  function checkWhale(user, single, cum) {
    // Gate por CFG.whaleAlertsEnabled — la usuaria pidio ocultar las
    // alertas en HUD/notificacion hasta que tengamos una herramienta
    // real de gestion de ballenas. Los datos del dia (DAY.byUser) se
    // siguen acumulando por si la herramienta llega; solo no avisamos.
    if (CFG.whaleAlertsEnabled !== true) return;
    if (user === '(anonimo)' || user === '(desconocido)') return;
    let why = null;
    if (single >= CFG.whaleSingleTk) why = 'tip de ' + single + ' tk';
    else if (cum >= CFG.whaleCumTk && cum - single < CFG.whaleCumTk) why = 'acumulado ' + cum + ' tk hoy';
    else if (cum >= CFG.whaleCumTk && (_whaleSeen[user] || 0) < Math.floor(cum / CFG.whaleCumTk))
      why = 'acumulado ' + cum + ' tk hoy';
    if (!why) return;
    _whaleSeen[user] = Math.floor(cum / Math.max(1, CFG.whaleCumTk));
    flashAlert('🐳 BALLENA: ' + user + ' — ' + why, 'whale');
    try {
      chrome.runtime.sendMessage({ type: 'BEMODELS_NOTIFY',
        title: '🐳 Usuario ballena', msg: user + ' — ' + why + ' (' + MODEL + ')' });
    } catch (_) {}
  }

  // ── Analitica ──────────────────────────────────────────────────────────────
  // RITMO de los ultimos 20 min, PERO recortado al inicio del turno
  // (effStart): si la modelo "abre" un turno hace 5 min, no queremos
  // contar tips de los 15 min anteriores en la ventana — el promedio
  // tiene que ser real DESDE que se abrio el turno.
  function ratePerMin() {
    if (_recent.length < 1) return 0;
    const winStart = Math.max(effStart(), Date.now() - 20 * 60 * 1000);
    const rec = _recent.filter(t => t.ts >= winStart);
    if (!rec.length) return 0;
    // span = tiempo real desde inicio de la ventana efectiva (no del
    // primer tip de la ventana). Asi si entre turno-open y ahora paso
    // mucho rato sin tips, el ritmo refleja el silencio.
    const span = Math.max(60000, Date.now() - winStart);
    const tk = rec.reduce((a, b) => a + b.tk, 0);
    return tk / (span / 60000);
  }

  // (v0.1.35: removido segmento TOP 1000/24 y todo su tooling. Era
  // legacy y duplicaba a Pos. General / Pos. Genero del rankFetcher.
  // Si en el futuro hace falta, ver historico en git anterior a 0.1.35.)

  function pollBalance() {
    if (!authedActive()) return;
    const b = readBalance();
    try { chrome.storage.local.set({ bemodels_bal: { v: b, ts: Date.now() } }); } catch (_) {}
    if (b == null || !MODEL || MODEL === DEMO_MODEL) return;
    ensureDay(Date.now()).then(() => {
      if (DAY.startBalance == null) DAY.startBalance = b;
      if (b < DAY.startBalance)    DAY.startBalance = b;  // retiro/payout → rebase
      DAY.balance = b;
      saveDaySoon();
      render();
    });
  }

  // ── Whale en sala: balance del espectador desde su tarjeta de perfil ───────
  // Stripchat solo expone el balance de un viewer cuando se abre su tarjeta
  // (no en la conexion). Raspamos esa tarjeta (metodo probado de BeCapture).
  // Alerta si balance >= umbral; tambien marca a los que lo OCULTAN.
  function scanUserCards() {
    // Mismo gate que checkWhale: si las alertas de ballena estan
    // apagadas, no vale la pena raspar tarjetas (es trabajo en el DOM).
    if (CFG.whaleAlertsEnabled !== true) return;
    if (!MODEL || MODEL === DEMO_MODEL || !_ownShow) return;
    if (!isAuthorized(MODEL)) return;
    try {
      const RES = /^(messages|settings|notifications|search|login|register|studio|my|account|cam2cam|start-broadcasting)$/i;
      const cards = document.querySelectorAll('div,section,aside');
      for (const card of cards) {
        const txt = (card.textContent || '').replace(/\s+/g, ' ').trim();
        if (!txt || txt.length > 600) continue;
        const hidden = /balance de tokens.*oculto|token balance.*hidden/i.test(txt);
        const bm = txt.match(/([\d.,]+)\s*balance de tokens|token balance[:\s]*([\d.,]+)|balance[:\s]*([\d.,]+)\s*tokens?/i);
        if (!hidden && !bm) continue;
        let username = null;
        for (const aEl of card.querySelectorAll('a[href]')) {
          const mm = (aEl.getAttribute('href') || '')
            .match(/^\/?([A-Za-z0-9_]{2,30})(?:[/?#]|$)/);
          if (mm && !RES.test(mm[1])) { username = mm[1]; break; }
        }
        if (!username) {
          const uEl = card.querySelector(
            '[class*="username" i],[class*="userName" i],[class*="nick" i],h1,h2');
          const ut = uEl && (uEl.textContent || '').trim();
          if (ut && ut.length >= 2 && ut.length <= 30 &&
              !/balance|tokens?|enviar|amigo|follow/i.test(ut)) username = ut;
        }
        if (!username) continue;
        const key = username.toLowerCase();
        if (hidden && !bm) {
          if (CFG.alertHidden && !_hiddenSeen[key]) {
            _hiddenSeen[key] = 1;
            flashAlert('🔒 ' + username + ' OCULTA su balance (posible whale)', 'whale');
            try { chrome.runtime.sendMessage({ type: 'BEMODELS_NOTIFY',
              title: '🔒 Balance oculto',
              msg: username + ' oculta su balance — posible whale (' + MODEL + ')' }); } catch (_) {}
          }
          continue;
        }
        const raw = (bm[1] || bm[2] || bm[3] || '').replace(/[.,]/g, '');
        const bal = Number(raw);
        if (!Number.isFinite(bal)) continue;
        const thr = Number(CFG.whaleBalanceTk) || 0;
        if (thr > 0 && bal >= thr && _intelSeen[key] !== bal) {
          _intelSeen[key] = bal;
          flashAlert('🐳 ' + username + ' EN SALA — ' + bal +
            ' tk (~$' + usd(bal) + ')', 'whale');
          try { chrome.runtime.sendMessage({ type: 'BEMODELS_NOTIFY',
            title: '🐳 Whale en sala',
            msg: username + ' tiene ' + bal + ' tk de balance (~$' +
              usd(bal) + ') · ' + MODEL }); } catch (_) {}
        } else {
          _intelSeen[key] = bal;
        }
      }
    } catch (_) {}
  }

  function analytics() {
    const demo = MODEL === DEMO_MODEL;
    const bal = DAY ? DAY.balance : null;
    const earned = (!demo && DAY && DAY.startBalance != null && DAY.balance != null)
      ? Math.max(0, DAY.balance - DAY.startBalance) : null;
    // GANADO = lo acumulado desde el INICIO DEL SHOW (lo que la usuaria
    // quiere ver). Filtra las transacciones del API por ts >= effStart().
    // Si no hay tx[] (API no respondio aun), cae a las heuristicas
    // antiguas (delta de saldo / WS) que tambien apuntan al show actual.
    const dayApiTok = (!demo && _earn && _earn.tokens != null) ? _earn.tokens : null;
    let sessionTok = null;
    if (!demo && _earn && Array.isArray(_earn.tx) && _earn.tx.length) {
      const startMs = effStart();
      sessionTok = _earn.tx
        .filter(t => t.ts >= startMs)
        .reduce((a, t) => a + (t.tokens || 0), 0);
    }
    const tot = (sessionTok != null) ? sessionTok
              : (dayApiTok  != null) ? dayApiTok
              : (earned    != null)  ? earned
              : (DAY ? DAY.tokens : 0);
    const totSrc = (sessionTok != null) ? 'session'
                 : (dayApiTok  != null) ? 'api'
                 : (earned    != null)  ? 'saldo'
                 : 'ws';
    // Diferencia entre el total del dia y la sesion → tk ganados
    // ANTES del inicio del show. Util para entender por que el numero
    // BIG no coincide con el dashboard de Stripchat (que muestra el
    // total del dia completo 00:00-ahora).
    const dayTot   = (dayApiTok != null) ? dayApiTok : null;
    const preShow  = (sessionTok != null && dayTot != null)
                    ? Math.max(0, dayTot - sessionTok) : null;
    const txInWin  = (sessionTok != null && _earn && _earn.tx)
                    ? _earn.tx.filter(t => t.ts >= effStart()).length : null;
    const txTotal  = (_earn && _earn.tx) ? _earn.tx.length : null;
    const txCountApi = (_earn && _earn.count != null) ? _earn.count : null;
    const truncated = !!(_earn && _earn.truncated);
    const goalTk = CFG.dailyGoalTk || 0;
    const pct = goalTk > 0 ? Math.min(999, Math.round((tot / goalTk) * 100)) : 0;
    const falta = Math.max(0, goalTk - tot);
    // Tiempo de sesion = ahora - primer evento del dia. Antes se usaba
    // (lastTs - firstTs), que se CONGELA entre tips (lastTs solo cambia al
    // recibir un tip) → inflaba tk/h y daba un ETA irreal. now - firstTs es
    // el tiempo real transcurrido y mantiene ritmo/ETA correctos sin tips.
    // Tiempo en vivo = ahora - inicio efectivo (turno manual > API > 1er
    // evento). Antes era now - firstTs (cuando arrancó BeModels), que daba
    // un turno corto si la extensión cargó tarde.
    const liveStart = effStart();
    const activeMs = Math.max(60000, Date.now() - liveStart);
    const horas = activeMs / 3600000;
    const shiftH = Number(CFG.shiftGoalH) > 0 ? Number(CFG.shiftGoalH) : 6;
    const shiftPct = Math.min(100, Math.round((horas / shiftH) * 100));
    const tkHora = horas > 0 ? Math.round(tot / horas) : 0;
    const rpm = ratePerMin();
    // ETA para meta diaria con el ritmo de los ult. 20 min (si hay), si no el promedio
    const ritmoHora = rpm > 0 ? rpm * 60 : tkHora;
    const etaMetaH = (falta > 0 && ritmoHora > 0) ? falta / ritmoHora : 0;
    // Proyección al final del turno: si seguís a este ritmo durante
    // las horas que faltan del shift (shiftH - horas), terminás con
    // ~projEndTk. Usa ritmoHora (rpm si lo hay, sino promedio largo).
    // - projHoursLeft: horas restantes del turno (0 si ya terminó).
    // - projAddTk:     tokens adicionales esperados a ritmo actual.
    // - projEndTk:     total proyectado al final del turno.
    // - projEndPct:    % vs meta diaria al cierre del turno.
    const projHoursLeft = Math.max(0, shiftH - horas);
    const projAddTk = Math.round(ritmoHora * projHoursLeft);
    const projEndTk = Math.round(tot + projAddTk);
    const projEndPct = goalTk > 0
      ? Math.min(999, Math.round((projEndTk / goalTk) * 100)) : 0;

    // Goal de Stripchat
    let gPct = null, gFalta = null, gEtaMin = null, gNombre = null;
    if (_lastGoal && _lastGoal.meta > 0) {
      gNombre = _lastGoal.nombre;
      gPct = Math.min(100, Math.round((_lastGoal.recaudado / _lastGoal.meta) * 100));
      gFalta = Math.max(0, _lastGoal.meta - _lastGoal.recaudado);
      gEtaMin = (gFalta > 0 && rpm > 0) ? Math.round(gFalta / rpm) : (gFalta === 0 ? 0 : null);
    }

    // ── COMPARATIVA hoy vs ayer / 7d ────────────────────────────
    // v0.1.63: simplificado por pedido de la usuaria. La línea "ayer
    // mismo horario" saturaba; ahora muestra solo: total del día de
    // ayer + duración aproximada del show de ayer. El "prom 7d" se
    // queda como TOTAL del día también (no por horario).
    let cmpYesterday = null, cmpYesterdayDelta = null, cmpYesterdayDurH = null;
    let cmpWeek7 = null, cmpWeek7Delta = null;
    let cmpBest7Tot = null, cmpBest7Date = null;
    if (_historic) {
      if (_historic.yesterday) {
        cmpYesterday = _historic.yesterday.tokens || 0;
        if (cmpYesterday > 0) {
          cmpYesterdayDelta = Math.round(((tot - cmpYesterday) / cmpYesterday) * 100);
        }
        // Duración del show de ayer = span entre primer y último tip.
        if (_historic.yesterday.firstTs && _historic.yesterday.lastTs &&
            _historic.yesterday.lastTs > _historic.yesterday.firstTs) {
          cmpYesterdayDurH = (_historic.yesterday.lastTs - _historic.yesterday.firstTs) / 3600000;
        }
      }
      if (_historic.last7 && _historic.last7.length > 0) {
        // Promedio del TOTAL del día de cada uno de los últimos 7.
        const sum = _historic.last7.reduce((a, d) => a + (d.tokens || 0), 0);
        cmpWeek7 = Math.round(sum / _historic.last7.length);
        if (cmpWeek7 > 0) {
          cmpWeek7Delta = Math.round(((tot - cmpWeek7) / cmpWeek7) * 100);
        }
      }
      if (_historic.best7) {
        cmpBest7Tot  = _historic.best7.tokens || 0;
        cmpBest7Date = _historic.best7.date   || null;
      }
    }

    return { tot, totSrc, goalTk, pct, falta, tkHora, horas, rpm,
             ritmoHora, etaMetaH, gNombre, gPct, gFalta, gEtaMin, bal, earned,
             liveStart, shiftH, shiftPct,
             projHoursLeft, projAddTk, projEndTk, projEndPct,
             dayTot, preShow, txInWin, txTotal, txCountApi, truncated,
             offline: !!_tgClosedAt, closedAt: _tgClosedAt,
             cmpYesterday, cmpYesterdayDelta, cmpYesterdayDurH,
             cmpWeek7, cmpWeek7Delta,
             cmpBest7Tot, cmpBest7Date };
  }

  // Sugerencias cortas (v0.1.63): la usuaria pidió que cada línea
  // sea breve y accionable (antes eran párrafos). Mantenemos los mismos
  // disparadores pero los mensajes ya no superan ~40 caracteres.
  function suggestions(a) {
    const s = [];
    const horaLocal = localHour();
    if (a.goalTk > 0 && a.tot >= a.goalTk) {
      s.push('✅ Meta cumplida (' + a.pct + '%)');
    } else if (a.goalTk > 0) {
      if (a.etaMetaH > 0 && a.etaMetaH < 12) {
        s.push('Faltan ' + a.falta + ' tk · ETA ' + fmtH(a.etaMetaH));
      } else if (a.rpm === 0 && a.horas > 0.5) {
        s.push('Ritmo frío · activá goal corto');
      } else if (a.etaMetaH >= 12) {
        s.push('Ritmo bajo · ¿bajar la meta?');
      }
    }
    if (a.gPct != null && a.gFalta > 0) {
      if (a.gEtaMin != null && a.gEtaMin <= 10) s.push('🔥 Goal por cerrar (~' + a.gEtaMin + ' min)');
      else if (a.gPct >= 80) s.push('Goal al ' + a.gPct + '% · empujá');
      else if (a.gPct < 20 && a.horas > 1) s.push('Goal frío ' + a.gPct + '% · ¿muy alto?');
    }
    if (horaLocal >= 18 && horaLocal <= 23) s.push('Pico 18-23h · seguí');
    return s.slice(0, 3);
  }

  // ── Render de la barra HUD ─────────────────────────────────────────────────
  // Conversion tk → USD (1 USD = 20 tk para la modelo).
  // Conversión moneda. tk → USD bruto (via PLATFORM.tkToUsd, que
  // tiene la tasa de la plataforma activa) o → COP neto aplicando
  // share de la PLATAFORMA + tasa COP (fórmula
  // bepraga.com/calculadora-webcam):
  //   COP = USD_bruto × PLATFORM.modelShare × CFG.copRate
  // El share se obtiene del adapter porque cada plataforma tiene el
  // suyo (Stripchat 55%, Chaturbate 50%, Cam4 50%, Streamate 35%,
  // XLove 40%). Si no hay PLATFORM (instalación vieja), fallback a
  // 1/20 (Stripchat) + CFG.copShareFactor (que es 0.55 default).
  function usd(tk) {
    const tkN = Number(tk) || 0;
    const usdGross = PLATFORM && PLATFORM.tkToUsd
      ? PLATFORM.tkToUsd(tkN) : (tkN / 20);
    if (CFG.currency === 'COP') {
      const share = (PLATFORM && Number.isFinite(PLATFORM.modelShare))
        ? PLATFORM.modelShare
        : (Number(CFG.copShareFactor) || 0.55);
      const rate = Number(CFG.copRate) || 3449;
      const cop = usdGross * share * rate;
      return Math.round(cop).toLocaleString('es-CO');
    }
    return usdGross.toFixed(2);
  }
  // Sufijo de moneda actual ("USD" / "COP") para mostrar al lado del
  // número. Helper aparte para que se pueda invocar sin tener tk.
  function curSym() {
    if (CFG.currency === 'COP') return 'COP';
    // Algunas plataformas pueden tener distinta currency (XLove = EUR).
    return (PLATFORM && PLATFORM.currencyLabel) || 'USD';
  }

  // ── Custom color de fondo del HUD ──────────────────────────────────
  // La modelo puede elegir un color en el panel (p.ej. rojo Stripchat
  // #C71636) para tintar la barra y que armonice con la pagina.
  // Aplicamos via setProperty('--bm-hud-bg-a' / '-b') sobre el root
  // del HUD; el CSS ya usa esas vars en .bm-wrap. El borde superior
  // y el brand se mantienen en lavanda (--bm-secundario) para no
  // perder identidad BE PRAGA.
  // Genera un gradiente de 2 tonos a partir del color: el "b" se
  // oscurece ~50% para que parezca pendiente como el morado default.
  function darkenHex(hex, factor) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || '').trim());
    if (!m) return null;
    const n = parseInt(m[1], 16);
    let r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
    r = Math.max(0, Math.round(r * factor));
    g = Math.max(0, Math.round(g * factor));
    b = Math.max(0, Math.round(b * factor));
    return '#' + ('000000' + ((r << 16) | (g << 8) | b).toString(16)).slice(-6);
  }
  function applyHudColor(el) {
    if (!el) return;
    const c = (CFG.hudBgColor || '').trim();
    if (!c) {
      // Reset: que herede los defaults del stylesheet.
      el.style.removeProperty('--bm-hud-bg-a');
      el.style.removeProperty('--bm-hud-bg-b');
      el.style.removeProperty('--bm-hud-border');
      return;
    }
    const dark = darkenHex(c, 0.45) || c;
    el.style.setProperty('--bm-hud-bg-a', c);
    el.style.setProperty('--bm-hud-bg-b', dark);
    // FIX "linea morada": cuando hay color custom, el borde
    // (--bm-secundario lavender por default) se ve fuera de paleta
    // como una línea entre el HUD y el resto de la página. Usamos
    // una versión MÁS oscura del color elegido para que el borde
    // sea visible (estructura) pero armonice.
    const darker = darkenHex(c, 0.30) || dark;
    el.style.setProperty('--bm-hud-border', darker);
  }

  function fmtH(h) {
    if (h <= 0) return '0 min';
    if (h < 1) return Math.round(h * 60) + ' min';
    const hh = Math.floor(h), mm = Math.round((h - hh) * 60);
    return hh + 'h' + (mm ? ' ' + mm + 'm' : '');
  }

  // Carga Poppins (mismo @font usado en el popup) inyectando un <link>
  // en el <head> del host. Idempotente; solo corre una vez por carga.
  // El stylesheet de la extension referencia 'Poppins' por nombre y cae
  // a system-ui si no esta disponible, asi que es un upgrade visual,
  // no critico.
  function ensurePoppins() {
    try {
      if (document.getElementById('bm-poppins')) return;
      const l = document.createElement('link');
      l.id = 'bm-poppins';
      l.rel = 'stylesheet';
      l.href = 'https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap';
      (document.head || document.documentElement).appendChild(l);
    } catch (_) {}
  }

  function ensureBar() {
    if (_bar) return _bar;
    ensurePoppins();
    const el = document.createElement('div');
    el.id = 'bemodels-hud';
    // El logo del conejito vive como icono de la extensión (toolbar)
    // PERO en modo flotante también aparece al lado del tiempo/tokens
    // — pedido textual: "puede quedar flotando solo el tiempo y lo
    // que lleva hecho al lado del logo". El CSS lo oculta cuando no
    // estamos en bm-pos-floating.
    let logoUrl = '';
    try { logoUrl = chrome.runtime.getURL('bemodels/logo-conejo.png'); } catch (_) {}
    el.innerHTML =
      '<div class="bm-wrap">' +
        '<div class="bm-brand">' +
          (logoUrl ? '<img class="bm-brand-logo" src="' + logoUrl + '" alt="">' : '') +
          '<span class="bm-brand-txt">Be<span>Models</span></span>' +
        '</div>' +
        '<div class="bm-seg" id="bm-dia"></div>' +
        '<div class="bm-seg" id="bm-meta"></div>' +
        '<div class="bm-seg" id="bm-live"></div>' +
        '<div class="bm-seg" id="bm-ritmo"></div>' +
        '<div class="bm-seg" id="bm-top"></div>' +
        '<div class="bm-seg bm-sug" id="bm-sug"></div>' +
        '<div class="bm-greet-box" id="bm-greet"></div>' +
        '<div class="bm-alert" id="bm-alert"></div>' +
        '<button class="bm-cfg" id="bm-cfg" title="Ajustes">⚙</button>' +
        '<button class="bm-min" id="bm-min" title="Ocultar/mostrar">_</button>' +
      '</div>';
    (document.body || document.documentElement).appendChild(el);
    el.querySelector('#bm-min').addEventListener('click', () => {
      el.classList.toggle('bm-collapsed');
    });
    el.querySelector('#bm-cfg').addEventListener('click', togglePanel);

    // ── Modo flotante: drag + click toggle ────────────────────────
    // Click corto en .bm-brand alterna expandido/colapsado.
    // Mousedown + movimiento > 4px → drag (persiste floatX/floatY).
    // Solo activo cuando barPos === 'floating'.
    const brand = el.querySelector('.bm-brand');
    if (brand) {
      let dragInfo = null;   // { startX, startY, origX, origY, moved }
      brand.addEventListener('mousedown', ev => {
        if (CFG.barPos !== 'floating') return;
        if (ev.button !== 0) return;
        const rect = el.getBoundingClientRect();
        dragInfo = {
          startX: ev.clientX, startY: ev.clientY,
          origX: rect.left, origY: rect.top,
          moved: false
        };
        ev.preventDefault();
      });
      window.addEventListener('mousemove', ev => {
        if (!dragInfo) return;
        const dx = ev.clientX - dragInfo.startX;
        const dy = ev.clientY - dragInfo.startY;
        if (!dragInfo.moved && (Math.abs(dx) + Math.abs(dy)) < 4) return;
        dragInfo.moved = true;
        // Clamp para que no salga de la viewport.
        const w = el.offsetWidth || 60, h = el.offsetHeight || 40;
        const nx = Math.max(0, Math.min(window.innerWidth - w, dragInfo.origX + dx));
        const ny = Math.max(0, Math.min(window.innerHeight - h, dragInfo.origY + dy));
        el.style.left = nx + 'px';
        el.style.right = 'auto';
        el.style.top = ny + 'px';
        el.style.bottom = 'auto';
      });
      window.addEventListener('mouseup', () => {
        if (!dragInfo) return;
        if (dragInfo.moved) {
          // Persistir posición.
          const rect = el.getBoundingClientRect();
          CFG.floatX = Math.round(rect.left);
          CFG.floatY = Math.round(rect.top);
          try {
            chrome.storage.local.get(['bemodels_cfg'], o => {
              const cur = (o && o.bemodels_cfg) || {};
              cur.floatX = CFG.floatX;
              cur.floatY = CFG.floatY;
              chrome.storage.local.set({ bemodels_cfg: cur });
            });
          } catch (_) {}
        } else {
          // Click sin drag → toggle expansión (solo en flotante).
          if (CFG.barPos === 'floating') {
            CFG.floatExpanded = !CFG.floatExpanded;
            try {
              chrome.storage.local.get(['bemodels_cfg'], o => {
                const cur = (o && o.bemodels_cfg) || {};
                cur.floatExpanded = CFG.floatExpanded;
                chrome.storage.local.set({ bemodels_cfg: cur });
              });
            } catch (_) {}
            render();
          }
        }
        dragInfo = null;
      });
    }
    // ESC colapsa el flotante.
    window.addEventListener('keydown', ev => {
      if (ev.key === 'Escape' && CFG.barPos === 'floating' && CFG.floatExpanded) {
        CFG.floatExpanded = false;
        try {
          chrome.storage.local.get(['bemodels_cfg'], o => {
            const cur = (o && o.bemodels_cfg) || {};
            cur.floatExpanded = false;
            chrome.storage.local.set({ bemodels_cfg: cur });
          });
        } catch (_) {}
        render();
      }
    });
    // Click en cualquier .bm-usd → toggle USD ↔ COP. Delegado al wrap
    // para que funcione cualquier .bm-usd presente en el momento del
    // click (los segmentos se re-renderizan con cada update).
    el.addEventListener('click', ev => {
      const t = ev.target;
      if (!t || !t.classList || !t.classList.contains('bm-usd')) return;
      CFG.currency = (CFG.currency === 'COP') ? 'USD' : 'COP';
      // Persistir en storage para que sobreviva al reload.
      try {
        chrome.storage.local.get(['bemodels_cfg'], o => {
          const cur = (o && o.bemodels_cfg) || {};
          cur.currency = CFG.currency;
          chrome.storage.local.set({ bemodels_cfg: cur });
        });
      } catch (_) {}
      render();
    });
    _bar = el;
    return el;
  }

  // Escucha mensajes del popup del icono: la usuaria abre el popup,
  // hace click en "⚙ Ajustes en la página" -> el popup nos manda este
  // mensaje y nosotros abrimos el panel in-page que tiene todos los
  // ajustes reales (regla: ajustes solo en la pagina, no en el popup).
  try {
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
      chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
        if (msg && msg.type === 'BEMODELS_OPEN_PANEL') {
          try {
            ensureBar();           // por si la barra aun no se monto
            const p = buildPanel();
            if (!p.classList.contains('bm-open')) {
              fillPanel();
              p.classList.add('bm-open');
            }
            sendResponse({ ok: true, opened: true });
          } catch (e) {
            sendResponse({ ok: false, error: String(e && e.message) });
          }
          return true;             // async response
        }
      });
    }
  } catch (_) {}

  // ── Panel de ajustes IN-PAGE (se abre con ⚙ desde la barra) ────────────────
  // Misma config que el popup del icono (clave chrome.storage 'bemodels_cfg'),
  // pero dentro de la pagina para que la modelo no tenga que abrir el icono.
  let _panel = null;

  function buildPanel() {
    if (_panel) return _panel;
    const p = document.createElement('div');
    p.id = 'bemodels-panel';
    p.innerHTML =
      '<div class="bmp-head">' +
        '<div class="bmp-title">Be<span>Models</span></div>' +
        '<button class="bmp-x" id="bmp-x" title="Cerrar">✕</button>' +
      '</div>' +
      '<div class="bmp-state" id="bmp-state">—</div>' +
      '<div class="bmp-scroll">' +
      '<div class="bmp-body">' +
        // ── Esenciales (siempre visibles) ─────────────────────
        '<label>Meta de tokens del día' +
          '<input type="number" id="bmp-goal" min="0" step="100"></label>' +
        '<label>Duración objetivo del turno (horas)' +
          '<input type="number" id="bmp-shift" min="1" max="24" step="1"></label>' +
        '<label>Posición de la barra' +
          '<select id="bmp-pos">' +
            '<option value="floating">🐰 Flotante (botón draggeable)</option>' +
            '<option value="bottom">Abajo</option>' +
            '<option value="top">Arriba</option>' +
            '<option value="left">Izquierda</option>' +
            '<option value="right">Derecha</option>' +
          '</select></label>' +
        // Color de fondo de la barra HUD. Presets + color picker libre.
        // El acento queda morado para mantener identidad BE PRAGA.
        '<label>Color del fondo de la barra' +
          '<div class="bmp-color-row">' +
            '<input type="color" id="bmp-hudbg" title="Elegí un color personalizado">' +
            '<select id="bmp-hudbg-preset">' +
              '<option value="">— preset —</option>' +
              '<option value="">Default (morado BE PRAGA)</option>' +
              '<option value="#C71636">Rojo Stripchat</option>' +
              '<option value="#1A1A2E">Azul oscuro</option>' +
              '<option value="#0F2A1E">Verde profundo</option>' +
              '<option value="#2E1A4E">Morado oscuro</option>' +
              '<option value="#1C1C1C">Casi negro</option>' +
            '</select>' +
            '<button type="button" id="bmp-hudbg-reset" class="bmp-mini">↺</button>' +
          '</div>' +
        '</label>' +
        '<label class="bmp-row"><input type="checkbox" id="bmp-summary">' +
          ' Enviar resumen al canal Telegram al cerrar el show</label>' +

        // ── Avanzado (colapsable, cerrado por default) ────────
        '<details class="bmp-adv">' +
          '<summary class="bmp-adv-sum">Avanzado</summary>' +
          '<div class="bmp-adv-body">' +
            '<label>Inicio de turno manual (HH:MM, solo si Telegram no detectó el inicio)' +
              '<input type="text" id="bmp-turn" placeholder="ej. 14:00"></label>' +
            '<label>Bridge BeStudio URL (preconfigurado · solo cambiar si el server se movió)' +
              '<input type="text" id="bmp-bridge" placeholder="https://bestudio.bepraga.com"></label>' +
            '<label>Zona horaria (IANA — vacío = autodetect del perfil Stripchat)' +
              '<input type="text" id="bmp-tz" placeholder="America/Bogota">' +
              '<small id="bmp-tz-info" style="display:block;opacity:.75;margin-top:4px"></small>' +
            '</label>' +
            // Tasa COP/USD para el toggle de moneda. Default 3449 según
            // bepraga.com/calculadora-webcam (fórmula COP = USD × 0.55 × tasa).
            '<label>Tasa COP/USD (para conversión a pesos)' +
              '<input type="number" id="bmp-coprate" min="0" step="1" placeholder="3449">' +
              '<small style="display:block;opacity:.65;margin-top:4px">' +
                'Calculadora: bepraga.com/calculadora-webcam · click en el monto del HUD alterna USD ↔ COP' +
              '</small>' +
            '</label>' +
            '<label class="bmp-row"><input type="checkbox" id="bmp-bar">' +
              ' Mostrar la barra HUD (desactivar la oculta entera)</label>' +
            '<label class="bmp-row"><input type="checkbox" id="bmp-demo">' +
              ' Modo demo (prueba sin transmitir)</label>' +
          '</div>' +
        '</details>' +

        // Inputs ocultos (whale alerts, no en UI pero savePanel los lee).
        '<input type="hidden" id="bmp-wsingle">' +
        '<input type="hidden" id="bmp-wcum">' +

        '<div class="bmp-today" id="bmp-today"></div>' +
        // Vista 7 días estilo C: mini-barras horizontales con destacado
        // del día actual + mejor día. La llena fillPanel() leyendo
        // _historic (ya cargado al SELF event + refresh 30 min).
        '<div class="bmp-week-title">Últimos 7 días</div>' +
        '<div class="bmp-week" id="bmp-week">—</div>' +
        '<div class="bmp-diag-title">Diagnóstico de sesión</div>' +
        '<div class="bmp-diag" id="bmp-diag">—</div>' +
      '</div>' +
      '</div>' + // /bmp-scroll
      // Sticky action bar — siempre visible aunque el body sea muy alto.
      '<div class="bmp-actions">' +
        '<button class="bmp-save" id="bmp-save">Guardar</button>' +
      '</div>' +
      '<div class="bmp-foot">BeModels · comparte analitica con BeStudio</div>';
    (document.body || document.documentElement).appendChild(p);
    p.querySelector('#bmp-x').addEventListener('click', closePanel);
    p.querySelector('#bmp-save').addEventListener('click', savePanel);
    // Color picker handlers: aplican el color en vivo (preview)
    // sin esperar al Guardar. El Save persiste lo que este en el
    // input al cierre del flow.
    const hudbg = p.querySelector('#bmp-hudbg');
    const hudbgPreset = p.querySelector('#bmp-hudbg-preset');
    const hudbgReset = p.querySelector('#bmp-hudbg-reset');
    if (hudbg) {
      hudbg.addEventListener('input', e => {
        // Live preview: aplica al HUD sin persistir todavia.
        CFG.hudBgColor = e.target.value;
        if (_bar) applyHudColor(_bar);
      });
    }
    if (hudbgPreset) {
      hudbgPreset.addEventListener('change', e => {
        const v = e.target.value || '';
        if (hudbg) hudbg.value = v || '#5409A9';
        CFG.hudBgColor = v;
        if (_bar) applyHudColor(_bar);
      });
    }
    if (hudbgReset) {
      hudbgReset.addEventListener('click', () => {
        CFG.hudBgColor = '';
        if (hudbg) hudbg.value = '#5409A9';
        if (hudbgPreset) hudbgPreset.value = '';
        if (_bar) applyHudColor(_bar);
      });
    }
    _panel = p;
    return p;
  }

  function fillPanel() {
    const p = buildPanel();
    p.querySelector('#bmp-goal').value    = CFG.dailyGoalTk;
    p.querySelector('#bmp-wsingle').value = CFG.whaleSingleTk;
    p.querySelector('#bmp-wcum').value    = CFG.whaleCumTk;
    p.querySelector('#bmp-turn').value    = CFG.turnStart || '';
    p.querySelector('#bmp-shift').value   = CFG.shiftGoalH || 6;
    p.querySelector('#bmp-bridge').value  = CFG.bridgeUrl || '';
    const cr = p.querySelector('#bmp-coprate');
    if (cr) cr.value = CFG.copRate || 3449;
    p.querySelector('#bmp-summary').checked = CFG.summaryToTelegram !== false;
    p.querySelector('#bmp-tz').value      = CFG.tz || 'America/Bogota';
    const tzInfo = p.querySelector('#bmp-tz-info');
    if (tzInfo) {
      if (_detectedTz) {
        const match = _detectedTz === (CFG.tz || 'America/Bogota');
        tzInfo.textContent = match
          ? '✓ TZ del perfil de Stripchat (' + _detectedTz + ') coincide.'
          : '⚠ Perfil de Stripchat usa ' + _detectedTz + ' (fuente: '
              + _detectedTzSrc + '). Se esta usando ESA para alinear con '
              + 'el dashboard. CFG.tz es solo override.';
      } else {
        tzInfo.textContent = 'TZ del perfil aun no detectada — se usa CFG.tz.';
      }
    }
    p.querySelector('#bmp-bar').checked   = CFG.barEnabled !== false;
    p.querySelector('#bmp-demo').checked  = CFG.demo === true;
    p.querySelector('#bmp-pos').value     = CFG.barPos || 'bottom';
    // Color picker: si hay un color custom, mostrarlo. Sino, default.
    const hudbgEl = p.querySelector('#bmp-hudbg');
    if (hudbgEl) hudbgEl.value = (CFG.hudBgColor && /^#[0-9a-f]{6}$/i.test(CFG.hudBgColor.trim()))
      ? CFG.hudBgColor.trim() : '#5409A9';
    const st = p.querySelector('#bmp-state');
    st.textContent = MODEL
      ? (MODEL === DEMO_MODEL ? 'Modo demo activo (datos de prueba).'
                              : 'Sala propia: ' + MODEL)
      : 'Sin sala propia detectada — abre tu sala y transmite.';
    const td = p.querySelector('#bmp-today');
    if (DAY && DAY.tokens != null) {
      const top = Object.entries(DAY.byUser || {})
        .sort((a, b) => b[1] - a[1]).slice(0, 3)
        .map(x => x[0] + ' (' + x[1] + ')').join(', ');
      td.textContent =
        'HOY: ' + DAY.tokens + ' tk · ' + (DAY.tipsCount || 0) + ' tips\n' +
        'Goals: ' + (DAY.goalsHit || 0) + '\n' +
        'Top: ' + (top || '—');
    } else {
      td.textContent = 'Sin tips aun hoy.';
    }
    // ── Diagnóstico de sesión (rama 'probar el inicio') ─────────
    // Verificar SIN esperar a producción de dónde sale el contador
    // del show: qué fuente está ganando effStart(), cuándo fue el
    // último poll al bridge Telegram y qué respondió. Útil cuando
    // BeModels arranca y la HUD muestra una hora extraña.
    const diag = p.querySelector('#bmp-diag');
    if (diag) diag.innerHTML = buildSessionDiag();
    // ── Vista 7 días (estilo C) ─────────────────────────────────
    const week = p.querySelector('#bmp-week');
    if (week) week.innerHTML = buildWeekView();
  }

  // Render del bloque "Últimos 7 días": mini-barras con el día actual
  // resaltado en morado y el mejor día con un ★. Usa _historic que
  // se carga desde la API REAL de Stripchat (ver loadHistoric).
  // Casos:
  //   - _historic === null → load en curso ("Cargando…").
  //   - Con datos (siempre 7 días, incluyendo huecos en 0) → render normal.
  // Si HOY + los 7 días previos son todos 0, igual se ve la fila HOY
  // como referencia (estilo coherente).
  function buildWeekView() {
    if (!_historic) {
      return '<div style="opacity:.6">Cargando histórico…</div>';
    }
    const today = localDateStr();
    // HOY = total del día desde el API si está (preferido — coincide
    // con el dashboard Stripchat), sino fallback al WS de DAY.tokens.
    const diaApi      = (_earn && _earn.tokens != null) ? _earn.tokens : null;
    const diaFallback = (DAY && DAY.tokens != null) ? DAY.tokens : 0;
    const diaTotal    = (diaApi != null) ? diaApi : diaFallback;
    // Armamos lista: 7 días previos + HOY al final.
    // _historic.dates está ordenado más reciente → más viejo;
    // revertimos para que en la vista vayan más viejo → reciente.
    const last7Dates = _historic.dates.slice(0, 7);
    const days = last7Dates.slice().reverse().map(d => ({
      date: d,
      tokens: (_historic.byDate[d] && _historic.byDate[d].tokens) || 0,
      isToday: false
    }));
    days.push({ date: today, tokens: diaTotal, isToday: true });
    const max = Math.max(1, ...days.map(d => d.tokens || 0));
    const best7Date = _historic.best7 ? _historic.best7.date : null;
    // Etiqueta corta del día (lun mar mie …).
    const dowAbbr = ['dom','lun','mar','mié','jue','vie','sáb'];
    const labelOf = isoDate => {
      try {
        const dt = new Date(isoDate + 'T12:00:00Z');
        return dowAbbr[dt.getUTCDay()];
      } catch (_) { return '???'; }
    };
    const avg = _historic.week7Avg || 0;
    const rows = days.map(d => {
      const pct = max > 0 ? Math.round((d.tokens / max) * 100) : 0;
      const cls = d.isToday ? ' bmp-w-today'
                 : (d.date === best7Date ? ' bmp-w-best' : '');
      const tag = d.isToday ? ' <small>HOY</small>'
                 : (d.date === best7Date ? ' <small>★ mejor</small>' : '');
      return '<div class="bmp-w-row' + cls + '">' +
        '<span class="bmp-w-label">' + labelOf(d.date) + '</span>' +
        '<span class="bmp-w-bar"><i style="width:' + pct + '%"></i></span>' +
        '<span class="bmp-w-tk">' + d.tokens + '</span>' +
        tag +
      '</div>';
    }).join('');
    return (
      '<div class="bmp-w-head">promedio 7d: <b>' + avg + ' tk</b></div>' +
      rows
    );
  }

  // Render del bloque de diagnóstico de sesión (texto HTML chico).
  function buildSessionDiag() {
    const src = effStartSource();
    const startMs = (MODEL && DAY) ? effStart() : null;
    const SOURCE_LABEL = {
      manual:         '✍ Inicio de turno manual',
      tg:             '📡 Telegram bridge (🟢 del canal)',
      sesion:         '⏱ Sesión persistida (WebSocket)',
      streamStart:    '⌚ DAY.streamStart (legacy)',
      apiStreamStart: '🛰 cam.statusChangedAt API',
      firstTs:        '🕓 Primer evento que vio BeModels hoy',
      frozen:         '🔴 Sesión congelada (show cerró)'
    };
    const fmtHH = ms => {
      try {
        return new Intl.DateTimeFormat('en-GB', {
          timeZone: effectiveTz(), hour: '2-digit', minute: '2-digit', hour12: false
        }).format(new Date(ms));
      } catch (_) { return '--:--'; }
    };
    const ago = ms => {
      if (!ms) return '—';
      const mins = Math.max(0, Math.round((Date.now() - ms) / 60000));
      if (mins < 1) return 'hace <1 min';
      if (mins < 60) return 'hace ' + mins + ' min';
      const h = Math.floor(mins / 60), m = mins % 60;
      return 'hace ' + h + 'h ' + (m ? m + 'm' : '');
    };
    const dur = startMs
      ? Math.max(0, ((_tgClosedAt || Date.now()) - startMs) / 3600000)
      : 0;
    const fmtDur = h => {
      if (h <= 0) return '—';
      const hh = Math.floor(h), mm = Math.round((h - hh) * 60);
      return hh + 'h' + (mm ? ' ' + mm + 'm' : '');
    };
    const bridgeLine = (() => {
      if (!CFG.bridgeUrl) return 'sin bridge configurado';
      if (!_tgLastPollAt) return 'esperando primer poll…';
      const tag = _tgLastPollRes === 'live'    ? '✓ LIVE'
                : _tgLastPollRes === 'offline' ? '○ offline'
                :                                '⚠ error';
      return tag + ' · ' + ago(_tgLastPollAt);
    })();
    const closedLine = _tgClosedAt
      ? '<br>show cerró: <b>' + fmtHH(_tgClosedAt) + '</b> (' + ago(_tgClosedAt) + ')'
      : '';
    const startTxt = startMs
      ? '<b>' + fmtHH(startMs) + '</b> · duración ' + fmtDur(dur)
      : '—';
    return (
      '<div style="font-size:11px;line-height:1.55">' +
        '<div><b>Inicio del show:</b> ' + startTxt + '</div>' +
        '<div><b>Fuente activa:</b> ' + (SOURCE_LABEL[src] || src) + '</div>' +
        '<div><b>Bridge Telegram:</b> ' + bridgeLine + '</div>' +
        closedLine +
      '</div>'
    );
  }

  function togglePanel() {
    const p = buildPanel();
    if (p.classList.contains('bm-open')) { closePanel(); return; }
    fillPanel();
    p.classList.add('bm-open');
  }
  function closePanel() { if (_panel) _panel.classList.remove('bm-open'); }

  function savePanel() {
    const p = _panel; if (!p) return;
    const patch = {
      dailyGoalTk:   Math.max(0, Number(p.querySelector('#bmp-goal').value) || 0),
      whaleSingleTk: Math.max(0, Number(p.querySelector('#bmp-wsingle').value) || 0),
      whaleCumTk:    Math.max(0, Number(p.querySelector('#bmp-wcum').value) || 0),
      turnStart:     (p.querySelector('#bmp-turn').value || '').trim(),
      shiftGoalH:    Math.max(1, Number(p.querySelector('#bmp-shift').value) || 6),
      bridgeUrl:     (p.querySelector('#bmp-bridge').value || '').trim(),
      copRate:       Math.max(1, Number((p.querySelector('#bmp-coprate') || {}).value) || 3449),
      summaryToTelegram: p.querySelector('#bmp-summary').checked,
      tz:            (p.querySelector('#bmp-tz').value || 'America/Bogota').trim(),
      barEnabled:    p.querySelector('#bmp-bar').checked,
      demo:          p.querySelector('#bmp-demo').checked,
      barPos:        p.querySelector('#bmp-pos').value || 'bottom',
      // Color custom del HUD: solo persistimos si la usuaria efectivamente
      // eligió algo (CFG.hudBgColor seteado por el preview). Para "reset"
      // el handler de reset ya seteo '' en CFG, asi que aca leemos eso.
      hudBgColor:    typeof CFG.hudBgColor === 'string' ? CFG.hudBgColor : ''
    };
    // MERGE con lo ya guardado (no pisar ajustes que solo estan en el popup:
    // manualModel, whaleBalanceTk, alertHidden…).
    chrome.storage.local.get(['bemodels_cfg'], o => {
      const cur = Object.assign({}, DEFAULT_CFG, (o && o.bemodels_cfg) || {});
      const cfg = Object.assign(cur, patch);
      CFG = cfg;
      try { chrome.storage.local.set({ bemodels_cfg: cfg }); } catch (_) {}
      applyDemoState();
      render();
      const b = p.querySelector('#bmp-save');
      b.textContent = 'Guardado ✓';
      setTimeout(() => { b.textContent = 'Guardar'; }, 1200);
    });
  }

  // Empuja el body al alto REAL de la barra cuando esta arriba; lo quita
  // en cualquier otra posicion / barra oculta. Llamado por render() via
  // requestAnimationFrame para medir tras el layout (offsetHeight fiable).
  function updateBodyPad() {
    try {
      if (!document.body) return;
      const wantPos = (['top', 'bottom', 'left', 'right'].indexOf(CFG.barPos) >= 0)
        ? CFG.barPos : 'bottom';
      const hidden = !_bar || _bar.style.display === 'none';
      if (wantPos !== 'top' || hidden) {
        document.body.style.removeProperty('padding-top');
        return;
      }
      const h = Math.ceil(_bar.getBoundingClientRect().height) || 46;
      document.body.style.setProperty('padding-top', h + 'px', 'important');
    } catch (_) {}
  }

  function render() {
    if (!CFG.barEnabled || !MODEL) {
      if (_bar) _bar.style.display = 'none';
      updateBodyPad();
      return;
    }
    const el = ensureBar();
    el.style.display = '';
    const pos = ['top', 'bottom', 'left', 'right', 'floating'].indexOf(CFG.barPos) >= 0
      ? CFG.barPos : 'bottom';
    el.classList.remove(
      'bm-pos-top', 'bm-pos-bottom', 'bm-pos-left', 'bm-pos-right', 'bm-pos-floating');
    el.classList.add('bm-pos-' + pos);
    // Modo flotante: aplica posición persistida + estado colapsado.
    if (pos === 'floating') {
      // Si nunca se dragueó, default = top:80px, right:14px (calculado
      // dinámicamente cuando midamos el ancho del HUD).
      const x = (CFG.floatX != null) ? Number(CFG.floatX) : null;
      const y = (CFG.floatY != null) ? Number(CFG.floatY) : 80;
      if (x != null) { el.style.left = x + 'px'; el.style.right = 'auto'; }
      else            { el.style.right = '14px'; el.style.left = 'auto'; }
      el.style.top = y + 'px';
      el.style.bottom = 'auto';
      // Estado expandido/colapsado.
      el.classList.toggle('bm-float-collapsed', !CFG.floatExpanded);
      // En flotante el brand muestra logo + tiempo + tokens compactos.
      // El render más abajo igual actualiza el texto base — sobreescribe
      // .bm-brand-txt al final de renderBars() con el formato compacto.
    } else {
      // Resetear inline styles del modo flotante por si se cambió de pos.
      el.style.top = el.style.bottom = el.style.left = el.style.right = '';
    }
    // Aplica color custom de fondo si la usuaria configuro uno en el panel.
    applyHudColor(el);
    // Empuja el body al ALTO REAL de la barra (rAF para medir tras layout).
    try { requestAnimationFrame(updateBodyPad); } catch (_) { updateBodyPad(); }
    const demo = MODEL === DEMO_MODEL;
    el.classList.toggle('bm-demo', demo);
    // Brand: en modo flotante COLAPSADO mostramos "Xh Ym · N tk" para
    // que se lea el progreso de un vistazo sin expandir. Cuando está
    // expandido o en posición fija, mostramos "BeModels" como antes.
    const brandTxt = el.querySelector('.bm-brand-txt');
    if (brandTxt) {
      const a = (typeof analytics === 'function') ? null : null; // see below
      // Calculamos analytics solo si vamos a mostrar el resumen.
      if (pos === 'floating' && !CFG.floatExpanded && !demo) {
        try {
          const an = analytics();
          brandTxt.innerHTML = '<b>' + fmtH(an.horas) + '</b> · ' + an.tot + ' tk';
        } catch (_) {
          brandTxt.innerHTML = 'Be<span>Models</span>';
        }
      } else {
        brandTxt.innerHTML = 'Be<span>Models</span>' + (demo ? ' · DEMO' : '');
      }
    }

    // Candado: modelo fuera de la lista autorizada → ni barra ni conteo.
    if (!demo && !isAuthorized(MODEL)) {
      el.classList.add('bm-greet');
      el.querySelector('#bm-greet').innerHTML =
        '<div class="bm-greet-hi">⛔ Sala no autorizada</div>' +
        '<div class="bm-greet-st">BeModels es de BE PRAGA — la cuenta <b>' +
          esc(MODEL) + '</b> no está autorizada.</div>';
      return;
    }

    const a = analytics();

    // Memorizar el último GANADO bueno (sesión o día) para respaldar el
    // resumen de cierre si analytics() diera 0 por estado raro al cerrar.
    const goodNow = Math.max((a.tot || 0), (a.dayTot || 0));
    if (goodNow > _lastGoodTot) _lastGoodTot = goodNow;

    // Saludo inicial: solo mientras NO haya ganado nada en TODO el día.
    // Antes solo miraba a.tot (sesión actual desde effStart), por eso se
    // quedaba pegado cuando la modelo ya había ganado a.dayTot tokens
    // antes de que registramos el inicio del show actual. Caso típico:
    // en Chaturbate la modelo lleva horas en vivo y BeModels recién
    // arranca cuando el Telegram bridge confirma el 🟢 → tot=0 pero
    // dayTot=586 → mostrar HUD normal, no saludo.
    const totalHoy = Math.max(
      (a.tot || 0),
      (a.dayTot || 0),
      (DAY && DAY.tokens) || 0
    );
    const greet = !demo && totalHoy <= 0;
    el.classList.toggle('bm-greet', greet);
    if (greet) { renderGreeting(el, a); return; }

    // Origen del numero (el BIG ya es la sesion del show actual):
    //  session → sumado de tx[] del API filtrado por ts >= inicio del show
    //            (preferido cuando hay bridge Telegram + API listos).
    //  api     → fallback al total del dia (00:00 local) si todavia no hay
    //            tx[] sumables o no se sabe el inicio del show.
    //  saldo / ws → fallback final por delta de wallet o conteo WS.
    let startHH = '';
    try {
      startHH = new Intl.DateTimeFormat('en-GB', { timeZone: effectiveTz(),
        hour: '2-digit', minute: '2-digit', hour12: false })
        .format(new Date(a.liveStart));
    } catch (_) {}
    const srcText = (a.totSrc === 'session') ? '✓ desde inicio del show'
                  : (a.totSrc === 'api')     ? '✓ total del dia (Stripchat)'
                  : (a.totSrc === 'saldo')   ? 'delta de saldo'
                  :                            'WS (aprox)';
    const startLine = (a.totSrc === 'session' && startHH)
      ? 'show inicio ' + startHH
      : '';
    const diaSmall = [startLine, srcText].filter(Boolean).join(' · ');
    // Linea extra: si la sesion < dia, mostrar lo que se gano ANTES del
    // show para que cuadre visualmente con el dashboard de Stripchat
    // (que siempre muestra el total del dia completo). Si hay truncado
    // de paginacion, avisar para que sepamos por que falta.
    let breakdown = '';
    if (a.totSrc === 'session' && a.dayTot != null && a.dayTot > a.tot) {
      breakdown = '+ ' + a.preShow + ' tk antes del show = ' + a.dayTot + ' tk hoy';
    }
    if (a.truncated) {
      breakdown += (breakdown ? ' · ' : '') + '⚠ paginacion truncada';
    }
    // Meta % en GANADO (volvió por pedido de la usuaria — antes vivía
    // en META DIA que ya fusionamos con COMPARATIVA). Inline pequeño
    // con color según pct. La barra horizontal completa la sigue
    // mostrando COMPARATIVA en la línea "meta del día".
    const metaCls = a.pct >= 100 ? 'bm-ok' : (a.pct >= 60 ? 'bm-mid' : 'bm-low');
    const metaPill = a.goalTk > 0
      ? ' <span class="bm-meta-pct ' + metaCls + '">· ' + a.pct + '%</span>'
      : '';
    el.querySelector('#bm-dia').innerHTML =
      '<b>GANADO</b><span class="bm-big">' + a.tot + ' tk' + metaPill + '</span>' +
      '<small class="bm-usd" title="Click para cambiar moneda">≈ $' +
        usd(a.tot) + ' ' + curSym() + '</small>' +
      '<small>' + diaSmall + '</small>' +
      (breakdown ? '<small>' + breakdown + '</small>' : '');
    // Línea de proyección (texto, ya no hay barra dual). Solo si
    // quedan horas del turno y hay ritmo.
    let projLine = '';
    if (a.projHoursLeft > 0 && a.ritmoHora > 0 && !a.offline) {
      const projCls = a.projEndPct >= 100 ? 'bm-ok'
                    : a.projEndPct >= 60  ? 'bm-mid' : 'bm-low';
      projLine =
        '<small>proyección turno: <b class="' + projCls + '">~' +
          a.projEndTk + ' tk (' + a.projEndPct + '%)</b> ' +
        '<span style="opacity:.7">+ ' + a.projAddTk + ' tk en ' +
          fmtH(a.projHoursLeft) + '</span></small>';
    }
    // COMPARATIVA: reemplaza META DIA. Le importa más al modelo saber
    // "voy mejor o peor que ayer/promedio al MISMO horario" que ver
    // la barra de meta (Stripchat ya muestra una barra similar abajo
    // para el goal interactivo). La meta % queda como info chica
    // inline, y la proyección al final del turno se mantiene porque
    // es accionable mid-show.
    //
    // COLOREADO COMPLETO DE LA LÍNEA (v0.1.62): la usuaria pidió que
    // toda la fila comparativa esté en verde (subiendo) o rojo
    // (bajando), no solo la flechita+%. La clase se aplica al <small>
    // entero; el CSS tiene overrides .bm-seg small.bm-low/.bm-mid/.bm-ok
    // que ganan al color base del .bm-seg small.
    const lineCls = d => {
      if (d == null) return '';
      return d >= 5 ? 'bm-ok' : (d <= -5 ? 'bm-low' : 'bm-mid');
    };
    const deltaTag = d => {
      if (d == null) return '';
      const arrow = d > 0 ? '↑' : (d < 0 ? '↓' : '·');
      const sign = d > 0 ? '+' : '';
      // Sin clase propia: hereda el color del <small> padre. El <b>
      // solo le da peso (negrita) al delta para que se lea aún más.
      return ' <b>' + arrow + ' ' + sign + d + '%</b>';
    };
    // Líneas de comparativa simplificadas (v0.1.63): solo total del
    // día y duración. Antes "ayer mismo horario" saturaba — la
    // modelo lee mejor "ayer transmitió Xh y se hizo Y tk".
    const yesterdayLine = a.cmpYesterday != null && a.cmpYesterday > 0
      ? '<small class="' + lineCls(a.cmpYesterdayDelta) + '">' +
          'ayer ' + (a.cmpYesterdayDurH ? fmtH(a.cmpYesterdayDurH) + ' · ' : '') +
          a.cmpYesterday + ' tk' +
          deltaTag(a.cmpYesterdayDelta) +
        '</small>'
      : '<small style="opacity:.55">sin datos de ayer</small>';
    const week7Line = a.cmpWeek7 != null && a.cmpWeek7 > 0
      ? '<small class="' + lineCls(a.cmpWeek7Delta) + '">' +
          'prom 7d: ' + a.cmpWeek7 + ' tk' +
          deltaTag(a.cmpWeek7Delta) +
        '</small>'
      : '';
    el.querySelector('#bm-meta').innerHTML =
      '<b>COMPARATIVA</b>' +
      '<span class="bm-big bm-cmp-big">' + fmtH(a.horas) + ' · ' + a.tot + ' tk</span>' +
      yesterdayLine +
      week7Line +
      projLine;
    // (Meta % ahora se muestra inline en GANADO. Aquí ya no se
    // duplica para no saturar la franja COMPARATIVA.)
    let hhmm = '--:--';
    try {
      hhmm = new Intl.DateTimeFormat('en-GB', { timeZone: effectiveTz(),
        hour: '2-digit', minute: '2-digit', hour12: false })
        .format(new Date(a.liveStart));
    } catch (_) {}
    // Sufijo si el inicio del show fue en otro dia (sesion continua).
    let daySfx = '';
    try {
      const sd = localDateStr(a.liveStart);
      const td = localDateStr();
      if (sd !== td) {
        const diff = Math.round(
          (new Date(td + 'T00:00:00Z').getTime() -
           new Date(sd + 'T00:00:00Z').getTime()) / 86400000);
        daySfx = diff === 1 ? ' (ayer)' : ' (hace ' + diff + 'd)';
      }
    } catch (_) {}
    const src = effStartSource();
    const srcTag = src === 'tg'     ? ' <span class="bm-src-tg">📡</span>' :
                   src === 'manual' ? ' <span class="bm-src-man">✍</span>' : '';
    // Estado OFFLINE: detectado por el bridge Telegram (🔴 procesado por
    // el launcher). Tiempo y barra del turno se CONGELAN al cierre, y
    // se aplica la clase .bm-offline para virar la franja a rojo. La
    // toggle del root se hace mas abajo (afecta a toda la barra).
    el.classList.toggle('bm-offline', !!a.offline);
    if (a.offline) {
      let closedHH = '--:--';
      try {
        closedHH = new Intl.DateTimeFormat('en-GB', { timeZone: effectiveTz(),
          hour: '2-digit', minute: '2-digit', hour12: false })
          .format(new Date(a.closedAt));
      } catch (_) {}
      const dur = (a.closedAt && a.liveStart)
        ? fmtH(Math.max(0, (a.closedAt - a.liveStart) / 3600000)) : '?';
      el.querySelector('#bm-live').innerHTML =
        '<b class="bm-off">🔴 OFFLINE</b><span class="bm-big bm-low">' + dur + '</span>' +
        '<small>show cerro ' + closedHH + ' · turno ' + a.shiftPct + '% de ' +
          a.shiftH + 'h</small>' +
        '<div class="bm-pbar"><i class="bm-low" style="width:' + a.shiftPct + '%"></i></div>';
    } else {
      el.querySelector('#bm-live').innerHTML =
        '<b>EN VIVO' + srcTag + '</b><span class="bm-big">' + fmtH(a.horas) + '</span>' +
        '<small>desde ' + hhmm + daySfx + ' · turno ' + a.shiftPct + '% de ' +
          a.shiftH + 'h</small>' +
        '<div class="bm-pbar"><i style="width:' + a.shiftPct + '%"></i></div>';
    }
    // (v0.1.37: removida franja RANK. Stripchat no expone un rank en vivo
    // util: topBestPlace=historico, listing=feed de recomendaciones, no
    // rankings. Si en el futuro se quiere, paginar por viewersCount o ir
    // por stripshours. Codigo removido; ver historial git pre-0.1.37.)
    el.querySelector('#bm-ritmo').innerHTML =
      '<b>RITMO</b><span class="bm-big">' + Math.round(a.ritmoHora) + ' tk/h</span>' +
      '<small class="bm-usd" title="Click para cambiar moneda">≈ $' +
        usd(a.ritmoHora) + ' ' + curSym() + '/h</small>' +
      '<small>' + (a.rpm > 0 ? a.rpm.toFixed(1) + ' tk/min (20m)' :
        a.tkHora + ' tk/h prom') + (a.etaMetaH > 0 ? ' · ETA ' + fmtH(a.etaMetaH) : '') + '</small>';
    // Segmento TOP — solo Stripchat tiene el ranking integrado hoy.
    // En otras plataformas escondemos el segmento (display:none).
    // DOS fuentes combinadas:
    //   1. Server (/api/stripchat-ranking/latest): puesto + StripPoints,
    //      pero SOLO top 1000.
    //   2. DOM (TopModelsAwardLabel): puesto EXACTO de cualquier rango
    //      (ej. 1057), pero sin StripPoints.
    // Prioridad: si está en el top 1000 del server, uso ese (más rico).
    // Si no, leo el DOM para el puesto exacto aunque esté fuera del 1000.
    const topEl = el.querySelector('#bm-top');
    if (topEl) {
      const isStripchat = !PLATFORM || PLATFORM.name === 'stripchat';
      if (!isStripchat) {
        topEl.style.display = 'none';
        topEl.innerHTML = '';
      } else {
        topEl.style.display = '';
        // Capturar el badge del DOM si la página actual lo expone
        // (top/leaderboard, creator portal). Persiste en _awardDOM
        // para mostrarlo después en la transmisión (que no tiene badge).
        captureAwardFromDOM();
        // Usar el award persistido (lo más reciente conocido).
        const dom = _awardDOM;
        const ago = (iso) => {
          if (!iso) return '';
          try {
            const mins = Math.round((Date.now() - (typeof iso === 'number' ? iso : Date.parse(iso))) / 60000);
            return mins < 60 ? ('hace ' + mins + ' min')
                             : mins < 1440 ? ('hace ' + Math.round(mins / 60) + ' h')
                             : ('hace ' + Math.round(mins / 1440) + ' d');
          } catch (_) { return ''; }
        };
        // Línea de StripScore (broadcast-center) para sumar a los
        // branches que muestran puesto. ★ verde/ámbar/rojo según valor.
        const ssLine = () => {
          if (!_bcenter || _bcenter.stripScore == null) return '';
          const ss = _bcenter.stripScore;
          const cls = ss >= 800 ? 'bm-ok' : ss >= 500 ? 'bm-mid' : 'bm-low';
          return '<small><span class="' + cls + '">★ StripScore ' + ss + '</span></small>';
        };
        if (_rankingMine) {
          // En el top 1000 del server: puesto + StripPoints (fuente rica).
          const pos = _rankingMine.position;
          const cls = pos <= 100  ? 'bm-ok'
                    : pos <= 500  ? 'bm-mid' : 'bm-low';
          const sp = Number(_rankingMine.stripPoints) || 0;
          topEl.innerHTML =
            '<b>TOP</b>' +
            '<span class="bm-big ' + cls + '">Puesto ' + pos + '</span>' +
            '<small>' + sp.toLocaleString('es-CO') + ' StripPoints</small>' +
            '<small style="opacity:.7">top 1000 · ' + ago(_ranking && _ranking.collectedAt) + '</small>' +
            ssLine();
        } else if (dom && dom.puesto != null) {
          // El badge (persistido) tiene el puesto EXACTO de la categoría
          // de la modelo — funciona aunque esté fuera del top 1000 global.
          const pos = dom.puesto;
          const topN = dom.topSize || 1000;
          const cls = pos <= topN * 0.1  ? 'bm-ok'
                    : pos <= topN * 0.5  ? 'bm-mid' : 'bm-low';
          const catTxt = dom.categoria ? (' · ' + dom.categoria) : '';
          const agoTxt = ago(dom.ts);
          topEl.innerHTML =
            '<b>TOP</b>' +
            '<span class="bm-big ' + cls + '">Puesto ' + pos.toLocaleString('es-CO') + '</span>' +
            '<small>en el Top ' + topN.toLocaleString('es-CO') + catTxt + '</small>' +
            '<small style="opacity:.7">' + (agoTxt || 'badge de tu sala') + '</small>' +
            ssLine();
        } else if (_bcenter && _bcenter.stripScore != null) {
          // Sin puesto (ni server ni badge) pero SÍ tenemos StripScore.
          // Mostramos el StripScore como métrica principal del segmento.
          const ss = _bcenter.stripScore;
          const cls = ss >= 800 ? 'bm-ok' : ss >= 500 ? 'bm-mid' : 'bm-low';
          topEl.innerHTML =
            '<b>TOP</b>' +
            '<span class="bm-big ' + cls + '">★ ' + ss + '</span>' +
            '<small>StripScore</small>' +
            (_bcenter.favoritedCount != null
              ? '<small style="opacity:.7">' + _bcenter.favoritedCount.toLocaleString('es-CO') + ' favoritos</small>'
              : '');
        } else if (_ranking == null && !dom && !_bcenter) {
          // Nada todavía: ni server ni DOM/storage ni broadcast-center.
          topEl.innerHTML =
            '<b>TOP</b>' +
            '<span class="bm-big" style="font-size:13px;opacity:.7">cargando…</span>';
        } else {
          // Server cargado, fuera del top 1000, sin award guardado.
          // Hint: la modelo nunca visitó una página con el badge.
          topEl.innerHTML =
            '<b>TOP</b>' +
            '<span class="bm-big bm-low" style="font-size:13px">Fuera top 1000</span>' +
            '<small style="opacity:.7">abrí tu ranking para</small>' +
            '<small style="opacity:.7">ver tu puesto exacto</small>' +
            ssLine();
        }
      }
    }
    const sug = suggestions(a);
    el.querySelector('#bm-sug').innerHTML =
      '<b>SUGERENCIAS</b>' + (sug.length
        ? sug.map(x => '<div class="bm-tip">' + esc(x) + '</div>').join('')
        : '<small>Sin sugerencias — vas bien.</small>') +
      // Botones de acción rápida: aprovechan el espacio vacío de
      // SUGERENCIAS para shortcuts a features que la modelo usa a
      // menudo. Por ahora son placeholders funcionales (Ideas con
      // listado hardcoded + clipboard; Traductor postMessage a
      // BeTranslate). El catálogo de ideas se puede mover a CFG
      // editable a futuro.
      '<div class="bm-sug-tools">' +
        '<button class="bm-sug-btn" id="bm-act-ideas" ' +
          'title="Ideas de metas por nicho">💡 Ideas</button>' +
        // Boton "🌐 Traductor" gateado por CFG.translatorButtonEnabled
        // (default false). Reactivar cuando BeTranslate implemente
        // el listener BEMODELS_CMD/TOGGLE_TRANSLATE.
        (CFG.translatorButtonEnabled === true
          ? '<button class="bm-sug-btn" id="bm-act-translate" ' +
              'title="Activar/desactivar BeTranslate">🌐 Traductor</button>'
          : '') +
      '</div>';
    // Re-attach handlers cada render (el HTML se reemplaza).
    const btnIdeas = el.querySelector('#bm-act-ideas');
    if (btnIdeas) btnIdeas.addEventListener('click', showIdeasPopover);
    const btnTrans = el.querySelector('#bm-act-translate');
    if (btnTrans) btnTrans.addEventListener('click', toggleTranslate);
  }

  // ── Catálogo de ideas de metas (server + favoritos personales) ──
  // Catálogo central: lo mantiene la operadora del estudio en
  // C:\BePraga\bestudio_goals.json (server) y BeModels lo descarga
  // via GET <bridge>/api/goal-ideas cada 30 min. Cache local en
  // chrome.storage.local (bemodels_goals_cache) para que funcione
  // offline también.
  // Favoritos personales: cada modelo agrega sus propios goals via
  // popover ("+ agregar"). Se guardan en bemodels_goal_favs:<modelo>
  // y se muestran arriba del catálogo central como sección "⭐".
  let _goalsCatalog = null;       // { version, nichos: [...] } del server
  let _goalsCatalogAt = 0;        // próximo refresh permitido (ms)
  let _goalsFavs = [];            // [{ tk, txt }] favoritos del modelo

  // Fallback hardcoded por si el bridge no responde y no hay caché.
  const GOAL_IDEAS_FALLBACK = [
    { nicho: 'Calientes / suave', items: [
      { tk: 50,  txt: 'Topless · 30s' },
      { tk: 100, txt: 'Spank ass x10' },
      { tk: 200, txt: 'Show boobs + spank' }
    ]},
    { nicho: 'Toys / lovense', items: [
      { tk: 99,  txt: 'Lush 10 sec wave' },
      { tk: 299, txt: 'Domi en clit · 30s' }
    ]}
  ];

  async function loadGoalsCatalog() {
    const base = (CFG.bridgeUrl || '').trim().replace(/\/+$/, '');
    if (!base) return;
    if (Date.now() < _goalsCatalogAt) return;
    _goalsCatalogAt = Date.now() + 30 * 60 * 1000;   // refresh cada 30 min
    try {
      const headers = { accept: 'application/json' };
      if (CFG.bridgeAuthToken) {
        headers['Authorization'] = 'Bearer ' + String(CFG.bridgeAuthToken).trim();
      }
      const r = await fetch(base + '/api/goal-ideas', {
        credentials: 'omit', cache: 'no-store', headers
      });
      if (!r.ok) { console.debug('[BeModels] goals http', r.status); return; }
      const j = await r.json();
      if (j && Array.isArray(j.nichos)) {
        _goalsCatalog = j;
        try { chrome.storage.local.set({ bemodels_goals_cache: j }); } catch (_) {}
        console.debug('[BeModels] goals catalog v=' + (j.version || '?'),
          'nichos=' + j.nichos.length);
      }
    } catch (e) {
      console.debug('[BeModels] goals err', e && e.message);
    }
  }
  // Cargar caché de storage al arrancar (para mostrar algo aunque el
  // bridge no responda todavía).
  try {
    chrome.storage.local.get(['bemodels_goals_cache'], o => {
      const c = o && o.bemodels_goals_cache;
      if (c && Array.isArray(c.nichos)) _goalsCatalog = c;
    });
  } catch (_) {}

  // ── Ranking Top 1000 (Stripchat) ───────────────────────────────
  // Fetcher del snapshot horario que el server colecta via
  // stripchat-top-collect.ps1. Solo aplica en Stripchat (Chaturbate
  // tiene su propio ranking, no integrado todavía). Cache en
  // chrome.storage para que se vea al instante incluso si el bridge
  // está caído cuando arranca BeModels.
  async function loadRanking() {
    if (!MODEL || MODEL === DEMO_MODEL) return;
    if (PLATFORM && PLATFORM.name !== 'stripchat') return;
    if (Date.now() < _rankingNextAt) return;
    _rankingNextAt = Date.now() + 15 * 60 * 1000;   // 15 min entre fetches
    const me = MODEL.toLowerCase();
    // ── 1) Intento via SERVER (rápido, 1 request al bridge) ──
    const base = (CFG.bridgeUrl || '').trim().replace(/\/+$/, '');
    if (base) {
      try {
        const headers = { accept: 'application/json' };
        if (CFG.bridgeAuthToken) {
          headers['Authorization'] = 'Bearer ' + String(CFG.bridgeAuthToken).trim();
        }
        const r = await fetch(base + '/api/stripchat-ranking/latest', {
          credentials: 'omit', cache: 'no-store', headers
        });
        if (r.ok) {
          const j = await r.json();
          if (j && Array.isArray(j.models)) {
            _ranking = j;
            _rankingMine = j.models.find(m =>
              (m.username || '').toLowerCase() === me) || null;
            try { chrome.storage.local.set({ bemodels_ranking_cache: j }); } catch (_) {}
            console.debug('[BeModels] ranking server OK · mi puesto=' +
              (_rankingMine ? _rankingMine.position : 'no en snapshot'));
          }
        } else {
          console.debug('[BeModels] ranking server http', r.status,
            '(probable: falta /api/stripchat-ranking/latest en CF Access bypass)');
        }
      } catch (e) {
        console.debug('[BeModels] ranking server err', e && e.message);
      }
    }
    // ── 2) Si el server no la tiene, buscar DIRECTO en la API de
    //    Stripchat (cookies de la modelo). Funciona aunque el server
    //    esté caído o el endpoint bloqueado por CF Access. ──
    if (!_rankingMine && PLATFORM && PLATFORM.fetchMyRanking) {
      try {
        const direct = await PLATFORM.fetchMyRanking(
          MODEL, CFG.rankGender || 'female', CFG.rankContinent || 'sa');
        if (direct && direct.position != null) {
          _rankingMine = {
            username:    MODEL,
            position:    direct.position,
            stripPoints: direct.stripPoints,
            _source:     'api-directa'
          };
          // Marcar que _ranking "existe" para que el render no muestre
          // "cargando" (aunque no tengamos el snapshot completo).
          if (!_ranking) _ranking = { count: direct.total || 1000, collectedAt: new Date().toISOString(), models: [] };
          // Guardar el período/scope que funcionó para mostrarlo + reusar.
          _rankingMine._period = direct.period;
          console.debug('[BeModels] ranking API-directa OK · puesto=' + direct.position +
            ' (' + direct.gender + '/' + direct.continent + '/' + direct.period + ')');
        } else {
          console.debug('[BeModels] ranking API-directa: no encontrada en ' +
            (CFG.rankGender || 'female') + '/' + (CFG.rankContinent || 'sa') +
            ' (probé varios períodos)');
        }
      } catch (e) {
        console.debug('[BeModels] ranking API-directa err', e && e.message);
      }
    }
    render();
  }
  // Cargar caché al arrancar.
  try {
    chrome.storage.local.get(['bemodels_ranking_cache'], o => {
      const c = o && o.bemodels_ranking_cache;
      if (c && Array.isArray(c.models)) {
        _ranking = c;
        if (MODEL) {
          const me = MODEL.toLowerCase();
          _rankingMine = c.models.find(m =>
            (m.username || '').toLowerCase() === me) || null;
        }
      }
    });
  } catch (_) {}
  function rankingTick() {
    if (!MODEL || MODEL === DEMO_MODEL) return;
    if (PLATFORM && PLATFORM.name !== 'stripchat') return;
    if (Date.now() < _rankingNextAt) return;
    loadRanking();
  }

  // ── StripScore / broadcast-center (Stripchat) ──────────────────
  async function loadBroadcastCenter() {
    if (!MODEL || MODEL === DEMO_MODEL || !SELF_USER_ID) return;
    if (PLATFORM && PLATFORM.name !== 'stripchat') return;
    if (!PLATFORM || !PLATFORM.fetchBroadcastCenter) return;
    if (Date.now() < _bcenterNextAt) return;
    _bcenterNextAt = Date.now() + 5 * 60 * 1000;   // 5 min
    try {
      const r = await PLATFORM.fetchBroadcastCenter(SELF_USER_ID);
      if (r && (r.stripScore != null || r.favoritedCount != null)) {
        _bcenter = r;
        console.debug('[BeModels] broadcast-center OK · StripScore=' + r.stripScore +
          ' · favs=' + r.favoritedCount);
        render();
      }
    } catch (e) { console.debug('[BeModels] bcenter err', e && e.message); }
  }
  function bcenterTick() {
    if (!MODEL || MODEL === DEMO_MODEL) return;
    if (PLATFORM && PLATFORM.name !== 'stripchat') return;
    if (Date.now() < _bcenterNextAt) return;
    loadBroadcastCenter();
  }

  // ── Award del DOM (badge "Puesto N en el Top X") ───────────────
  function awardKey() { return 'bemodels_award:' + (MODEL || ''); }
  function loadAwardStored() {
    if (!MODEL) return;
    try {
      chrome.storage.local.get([awardKey()], o => {
        const a = o && o[awardKey()];
        if (a && a.puesto != null) _awardDOM = a;
      });
    } catch (_) {}
  }
  // Lee el badge del DOM (si la página actual lo expone) y lo persiste.
  // Llamado en cada render. Si el DOM no tiene badge, no hace nada
  // (conserva el último guardado en _awardDOM).
  function captureAwardFromDOM() {
    if (!PLATFORM || PLATFORM.name !== 'stripchat' || !PLATFORM.readRankingDOM) return;
    let dom = null;
    try { dom = PLATFORM.readRankingDOM(); } catch (_) {}
    if (!dom || dom.puesto == null) return;
    const rec = {
      puesto: dom.puesto, topSize: dom.topSize,
      categoria: dom.categoria, ts: Date.now()
    };
    // Solo persistir si cambió el puesto o pasó >5 min (evita writes).
    const prev = _awardDOM;
    if (prev && prev.puesto === rec.puesto && prev.topSize === rec.topSize &&
        (Date.now() - (prev.ts || 0)) < 5 * 60 * 1000) {
      return;
    }
    _awardDOM = rec;
    try { chrome.storage.local.set({ [awardKey()]: rec }); } catch (_) {}
    console.debug('[BeModels] award DOM capturado:', rec.puesto, 'top', rec.topSize);
  }

  function favsKey() { return 'bemodels_goal_favs:' + (MODEL || ''); }
  function loadFavs() {
    if (!MODEL) return;
    try {
      chrome.storage.local.get([favsKey()], o => {
        const a = o && o[favsKey()];
        _goalsFavs = Array.isArray(a) ? a : [];
      });
    } catch (_) {}
  }
  function saveFavs() {
    if (!MODEL) return;
    try { chrome.storage.local.set({ [favsKey()]: _goalsFavs }); } catch (_) {}
  }

  // Popover flotante de ideas. Muestra:
  //   1. ⭐ Tus favoritos (persistidos por modelo, agregables inline).
  //   2. Catálogo del estudio (del server via /api/goal-ideas).
  // Click en un item → copia "Tk · texto" al clipboard.
  function showIdeasPopover() {
    const existing = document.getElementById('bm-ideas-pop');
    if (existing) { existing.remove(); return; }
    // Refrescar catálogo si está stale.
    loadGoalsCatalog();
    // Asegurar favoritos cargados.
    if (MODEL && _goalsFavs.length === 0) loadFavs();
    const pop = document.createElement('div');
    pop.id = 'bm-ideas-pop';
    pop.className = 'bm-ideas-pop';
    renderIdeasPopBody(pop);
    document.body.appendChild(pop);
    // ESC cierra.
    const escH = e => {
      if (e.key === 'Escape') { pop.remove(); document.removeEventListener('keydown', escH); }
    };
    document.addEventListener('keydown', escH);
  }

  function renderIdeasPopBody(pop) {
    const cat = (_goalsCatalog && Array.isArray(_goalsCatalog.nichos))
      ? _goalsCatalog.nichos : GOAL_IDEAS_FALLBACK;
    const ver = (_goalsCatalog && _goalsCatalog.version) || 'fallback';
    const itemHtml = (i, isFav) => {
      const txt = i.tk + ' tk · ' + i.txt;
      const hasVar = Array.isArray(i.variantes) && i.variantes.length > 0;
      const hasGif = i.gif && typeof i.gif === 'string';
      const gifAttr = hasGif ? ' data-gif="' + esc(i.gif) + '"' : '';
      const varBadge = hasVar
        ? '<span class="bm-ideas-vmark" title="' + i.variantes.length + ' variantes">▸ ' + i.variantes.length + '</span>'
        : '';
      const gifIcon = hasGif
        ? '<span class="bm-ideas-gifmark" title="hover para preview">🎬</span>'
        : '';
      // Render del item principal (con o sin variantes).
      let html =
        '<div class="bm-ideas-item' + (hasVar ? ' bm-ideas-has-var' : '') +
              (hasGif ? ' bm-ideas-has-gif' : '') +
              '" data-txt="' + esc(txt) + '"' + gifAttr + '>' +
          '<span class="bm-ideas-tk">' + i.tk + ' tk</span>' +
          '<span class="bm-ideas-txt">' + esc(i.txt) + '</span>' +
          gifIcon + varBadge +
          (isFav
            ? '<button class="bm-ideas-rm" data-fav-tk="' + i.tk +
                '" data-fav-txt="' + esc(i.txt) + '" title="Quitar">×</button>'
            : '<button class="bm-ideas-star" data-fav-tk="' + i.tk +
                '" data-fav-txt="' + esc(i.txt) + '" title="Agregar a favoritos">☆</button>') +
        '</div>';
      // Variantes anidadas (escondidas por default, se expanden con click).
      if (hasVar) {
        html += '<div class="bm-ideas-vlist">' +
          i.variantes.map(v => {
            const vtxt = v.tk + ' tk · ' + v.txt;
            const vGif = v.gif ? ' data-gif="' + esc(v.gif) + '"' : '';
            const vIcon = v.gif ? '<span class="bm-ideas-gifmark">🎬</span>' : '';
            return '<div class="bm-ideas-variant" data-txt="' + esc(vtxt) + '"' + vGif + '>' +
              '<span class="bm-ideas-tk">' + v.tk + ' tk</span>' +
              '<span class="bm-ideas-txt">' + esc(v.txt) + '</span>' +
              vIcon +
              '</div>';
          }).join('') +
          '</div>';
      }
      return html;
    };
    const favsHtml = _goalsFavs.length > 0
      ? (
        '<div class="bm-ideas-grp bm-ideas-grp-favs">' +
          '<div class="bm-ideas-grp-t">⭐ Tus favoritos</div>' +
          _goalsFavs.map(i => itemHtml(i, true)).join('') +
        '</div>'
      ) : '';
    const catHtml = cat.map(g => (
      '<div class="bm-ideas-grp">' +
        '<div class="bm-ideas-grp-t">' + esc(g.nicho) + '</div>' +
        (g.items || []).map(i => itemHtml(i, false)).join('') +
      '</div>'
    )).join('');
    pop.innerHTML =
      '<div class="bm-ideas-head">' +
        '<b>💡 Ideas de metas</b>' +
        '<span class="bm-ideas-hint">click para copiar · ☆ favoritos</span>' +
        '<button class="bm-ideas-x">✕</button>' +
      '</div>' +
      '<div class="bm-ideas-body">' +
        favsHtml +
        catHtml +
        // Form inline para agregar favorito.
        '<div class="bm-ideas-add">' +
          '<input type="number" id="bm-ideas-add-tk" placeholder="tk" min="1" step="1">' +
          '<input type="text"   id="bm-ideas-add-txt" placeholder="descripción del goal">' +
          '<button id="bm-ideas-add-btn">+ agregar a favoritos</button>' +
        '</div>' +
      '</div>' +
      '<div class="bm-ideas-foot">' +
        'Catálogo: <b>' + esc(ver) + '</b> · ' +
        'Copiá el texto y pegalo en el editor de goal.' +
        '<div class="bm-ideas-edit-tip">' +
          '<b>Para editar este catálogo</b> (solo operadora): editar en el server <code>C:\\BePraga\\bestudio_goals.json</code> con Notepad++ ' +
          '→ guardar UTF-8 → cambios se ven en ≤30 min. Formato y ejemplos en ' +
          '<code>bestudio_goals.example.json</code> del repo.' +
        '</div>' +
      '</div>';
    // Handlers
    pop.querySelector('.bm-ideas-x').addEventListener('click', () => pop.remove());
    pop.addEventListener('click', ev => {
      // Botón quitar (favorito).
      const rm = ev.target.closest('.bm-ideas-rm');
      if (rm) {
        ev.stopPropagation();
        const tk = Number(rm.getAttribute('data-fav-tk'));
        const txt = rm.getAttribute('data-fav-txt');
        _goalsFavs = _goalsFavs.filter(f => !(f.tk === tk && f.txt === txt));
        saveFavs();
        renderIdeasPopBody(pop);
        return;
      }
      // Botón estrella (agregar a fav).
      const st = ev.target.closest('.bm-ideas-star');
      if (st) {
        ev.stopPropagation();
        const tk = Number(st.getAttribute('data-fav-tk'));
        const txt = st.getAttribute('data-fav-txt');
        if (!_goalsFavs.some(f => f.tk === tk && f.txt === txt)) {
          _goalsFavs.push({ tk, txt });
          saveFavs();
          renderIdeasPopBody(pop);
        }
        return;
      }
      // Click en una variante → copia esa variante (no expande).
      const variant = ev.target.closest('.bm-ideas-variant');
      if (variant) {
        const txt = variant.getAttribute('data-txt');
        try {
          navigator.clipboard.writeText(txt).then(() => {
            variant.classList.add('bm-ideas-copied');
            setTimeout(() => variant.classList.remove('bm-ideas-copied'), 1200);
          });
        } catch (_) {}
        return;
      }
      // Click en item con variantes → toggle expansión (no copia).
      const item = ev.target.closest('.bm-ideas-item');
      if (!item) return;
      if (item.classList.contains('bm-ideas-has-var')) {
        item.classList.toggle('bm-ideas-expanded');
        return;
      }
      // Click en item sin variantes → copia.
      const txt = item.getAttribute('data-txt');
      try {
        navigator.clipboard.writeText(txt).then(() => {
          item.classList.add('bm-ideas-copied');
          setTimeout(() => item.classList.remove('bm-ideas-copied'), 1200);
        });
      } catch (_) {}
    });

    // Hover preview de GIF (event delegation). Cualquier elemento con
    // data-gif muestra un floating preview al cabo de 300ms de hover.
    // Auto-detecta el tipo de URL:
    //   - .gif/.webp/.png/.jpg → <img>
    //   - .mp4/.webm → <video autoplay loop muted>
    //   - cualquier otro → <iframe> (ej. redgifs.com/ifr/, gfycat embeds)
    let _gifTimer = null, _gifEl = null;
    const hideGifPreview = () => {
      if (_gifTimer) { clearTimeout(_gifTimer); _gifTimer = null; }
      if (_gifEl && _gifEl.parentNode) _gifEl.parentNode.removeChild(_gifEl);
      _gifEl = null;
    };
    const detectGifMediaType = url => {
      const u = String(url).toLowerCase().split('?')[0].split('#')[0];
      if (/\.(gif|webp|png|jpe?g)$/.test(u)) return 'img';
      if (/\.(mp4|webm|mov)$/.test(u))       return 'video';
      return 'iframe';
    };
    const buildGifInner = url => {
      const safe = esc(url);
      const t = detectGifMediaType(url);
      const onErr = ' onerror="this.parentNode.innerHTML=\'' +
        '<div class=bm-gif-fail>no se pudo cargar el preview · ' +
        'verificá que la URL sea directa al archivo o un embed valido' +
        '</div>\'"';
      if (t === 'video') {
        return '<video src="' + safe + '" autoplay loop muted playsinline' + onErr + '></video>';
      }
      if (t === 'iframe') {
        // sandbox: scripts permitidos (necesarios para player de redgifs),
        // pero NO top-navigation (no puede hacer location.href de la pagina).
        return '<iframe src="' + safe + '" frameborder="0" allowfullscreen' +
          ' allow="autoplay; encrypted-media"' +
          ' sandbox="allow-scripts allow-same-origin allow-presentation"></iframe>';
      }
      return '<img src="' + safe + '" alt="preview"' + onErr + '>';
    };
    pop.addEventListener('mouseover', ev => {
      const t = ev.target.closest('[data-gif]');
      if (!t) return;
      const url = t.getAttribute('data-gif');
      if (!url) return;
      // Debounce: si pasa rápido sobre varios items, no abrir 5 al toque.
      if (_gifTimer) clearTimeout(_gifTimer);
      _gifTimer = setTimeout(() => {
        hideGifPreview();
        _gifEl = document.createElement('div');
        _gifEl.className = 'bm-ideas-gif-pop bm-gif-' + detectGifMediaType(url);
        _gifEl.innerHTML = buildGifInner(url);
        document.body.appendChild(_gifEl);
        // Posicionar a la derecha del item, con clamp para no salir del viewport.
        // Si no entra a la derecha, lo ponemos a la IZQUIERDA del item.
        const rect = t.getBoundingClientRect();
        const W = 400, H = 400;
        let left = rect.right + 8;
        if (left + W + 12 > window.innerWidth) {
          left = Math.max(8, rect.left - W - 8);   // a la izquierda
        }
        const top = Math.min(window.innerHeight - H - 8,
                             Math.max(8, rect.top));
        _gifEl.style.left = left + 'px';
        _gifEl.style.top  = top  + 'px';
      }, 300);
    });
    pop.addEventListener('mouseout', ev => {
      const t = ev.target.closest('[data-gif]');
      if (!t) return;
      // Si se mueve hacia el preview en sí, no cerrar.
      const to = ev.relatedTarget;
      if (to && _gifEl && _gifEl.contains(to)) return;
      hideGifPreview();
    });
    // Cerrar preview cuando el popover se cierra/recrea.
    pop.addEventListener('bm-pop-close', hideGifPreview);
    // Form de agregar favorito.
    const addBtn = pop.querySelector('#bm-ideas-add-btn');
    if (addBtn) addBtn.addEventListener('click', () => {
      const tkEl = pop.querySelector('#bm-ideas-add-tk');
      const txtEl = pop.querySelector('#bm-ideas-add-txt');
      const tk = Math.max(1, Number(tkEl.value) || 0);
      const txt = (txtEl.value || '').trim();
      if (!tk || !txt) return;
      if (!_goalsFavs.some(f => f.tk === tk && f.txt === txt)) {
        _goalsFavs.push({ tk, txt });
        saveFavs();
        renderIdeasPopBody(pop);
      } else {
        tkEl.value = ''; txtEl.value = '';
      }
    });
  }

  // Toggle BeTranslate: emite postMessage que BeTranslate (si está
  // instalado) puede escuchar para activar/desactivar su barra de
  // traducción. Contrato:
  //   window.postMessage({ source: 'BEMODELS_CMD', kind: 'TOGGLE_TRANSLATE' })
  // BeTranslate respondería con:
  //   window.postMessage({ source: 'BETRANSLATE', kind: 'TOGGLE_ACK', on: bool })
  // Por ahora si no llega respuesta en 1.5s, mostramos un toast con
  // hint de instalación.
  function toggleTranslate() {
    let ackd = false;
    const ackH = ev => {
      const d = ev && ev.data;
      if (d && d.source === 'BETRANSLATE' && d.kind === 'TOGGLE_ACK') {
        ackd = true;
        window.removeEventListener('message', ackH);
        flashAlert('🌐 BeTranslate ' + (d.on ? 'ACTIVO' : 'desactivado'), 'goal');
      }
    };
    window.addEventListener('message', ackH);
    try {
      window.postMessage({ source: 'BEMODELS_CMD', kind: 'TOGGLE_TRANSLATE' }, '*');
    } catch (_) {}
    setTimeout(() => {
      if (!ackd) {
        window.removeEventListener('message', ackH);
        flashAlert('🌐 BeTranslate no respondió — ¿está instalado?', 'whale');
      }
    }, 1500);
  }

  function renderGreeting(el, a) {
    a = a || analytics();
    const name = MODEL_NAME || 'modelo';
    const cls = a.pct >= 100 ? 'bm-ok' : (a.pct >= 60 ? 'bm-mid' : 'bm-low');
    let hhmm = '--:--';
    try {
      hhmm = new Intl.DateTimeFormat('en-GB', { timeZone: effectiveTz(),
        hour: '2-digit', minute: '2-digit', hour12: false })
        .format(new Date(a.liveStart));
    } catch (_) {}
    const estado = _ownShow
      ? '🟢 Estás en tu sala · EN VIVO ' + fmtH(a.horas) + ' (desde ' + hhmm + ')'
      : 'Abre tu sala y transmite para empezar a contar.';
    el.querySelector('#bm-greet').innerHTML =
      '<div class="bm-greet-hi">👋 Hola ' + esc(name) +
        ', soy <b>BeModels</b>. Tu meta de hoy: <b>' + a.goalTk + ' tk</b>.</div>' +
      '<div class="bm-greet-bar">' +
        '<div class="bm-greet-num"><b>' + a.tot + '</b> / ' + a.goalTk +
          ' tk · faltan <b>' + a.falta + '</b> · ' + a.pct + '%' +
          ' · ≈ <b>$' + usd(a.tot) + '</b> ' + curSym() + '</div>' +
        '<div class="bm-pbar"><i class="' + cls + '" style="width:' +
          Math.min(100, a.pct) + '%"></i></div>' +
      '</div>' +
      '<div class="bm-greet-st">' + esc(estado) + '</div>';
  }

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  let _alertT = null;
  function flashAlert(txt, cls) {
    const el = ensureBar();
    const a = el.querySelector('#bm-alert');
    a.textContent = txt;
    a.className = 'bm-alert show ' + (cls || '');
    if (_alertT) clearTimeout(_alertT);
    _alertT = setTimeout(() => { a.className = 'bm-alert'; }, 15000);
  }

  // ── Modo demo (prueba sin transmitir) ──────────────────────────────────────
  // Inyecta un goal de Stripchat sintetico y tips aleatorios por la MISMA ruta
  // addTip() para poder ver/afinar META DIA, RITMO tk/min, ETA y GOAL SC sin
  // estar en vivo. Los datos del demo viven aislados bajo el modelo "(demo)"
  // (clave de storage propia) y NUNCA mezclan con un dia real. Un show real
  // siempre tiene prioridad: si se detecta sala propia, el demo se apaga.
  const DEMO_AMTS  = [5, 10, 15, 20, 25, 33, 50, 50, 75, 99, 100, 150, 200, 333, 500];
  const DEMO_USERS = ['lobo_77', 'andres_vip', 'carlosM', 'el_jefe', 'mariano', 'sant1ago'];

  function demoTick() {
    if (!CFG.demo || _realModel) return;
    const amt  = DEMO_AMTS[Math.floor(Math.random() * DEMO_AMTS.length)];
    const anon = Math.random() < 0.15;
    const user = DEMO_USERS[Math.floor(Math.random() * DEMO_USERS.length)];
    addTip({ tokens: amt, username: anon ? null : user, userId: null,
             anon, ts: Date.now(), kind: 'tip' });
    if (_lastGoal && _lastGoal.meta > 0) {
      _lastGoal.recaudado = Math.min(_lastGoal.meta, (_lastGoal.recaudado || 0) + amt);
      if (_lastGoal.recaudado >= _lastGoal.meta) {
        if (DAY) { DAY.goalsHit++; saveDaySoon(); }
        flashAlert('🎯 GOAL COMPLETADO (demo): ' + (_lastGoal.nombre || ''), 'goal');
        _lastGoal = { nombre: 'Demo · nueva meta', meta: _lastGoal.meta + 1000, recaudado: 0 };
      }
    }
    render();
  }

  function startDemo() {
    if (_demoT || _realModel) return;
    MODEL = DEMO_MODEL;
    _lastGoal = { nombre: 'Demo · meta de prueba', meta: 1500, recaudado: 0 };
    ensureDay(Date.now()).then(() => {
      render();
      _demoT = setInterval(demoTick, 4000);
    });
  }

  function stopDemo() {
    if (_demoT) { clearInterval(_demoT); _demoT = null; }
    if (MODEL === DEMO_MODEL && !_realModel) {
      MODEL = null; _lastGoal = null; DAY = null; _dayKey = null;
      _recent = []; _whaleSeen = {};
      if (_bar) _bar.style.display = 'none';
    }
  }

  function applyDemoState() {
    if (CFG.demo && !_realModel) startDemo();
    else stopDemo();
  }

  // ── Mensajes desde injected.js (MAIN world) ────────────────────────────────
  window.addEventListener('message', ev => {
    const d = ev.data;
    if (!d || d.source !== 'BEMODELS') return;
    if (d.kind === 'SELF') {
      _realModel = d.model;
      stopDemo();                 // un show real manda sobre el demo
      MODEL = d.model;
      MODEL_NAME = d.name || d.model;
      if (d.userId) SELF_USER_ID = d.userId;
      // Disparar deteccion de TZ del perfil de Stripchat lo antes
      // posible para que el primer earnTick ya use la TZ correcta y
      // los day-keys de storage no se calculen con TZ equivocada.
      ensureProfileTz();
      // Reintentar summary pendiente de un cierre anterior si el
      // bridge estaba caido al momento del cierre (TTL 24h).
      retryPendingSummary();
      // Cargar histórico para la COMPARATIVA + vista 7 días.
      loadHistoric().then(() => render()).catch(() => {});
      // Catálogo de ideas (server) + favoritos personales (storage).
      loadGoalsCatalog();
      loadFavs();
      // Top 1000 ranking (Stripchat-only) + award DOM + StripScore.
      loadRanking();
      loadAwardStored();
      loadBroadcastCenter();
      // Cargar la sesion persistida para esta modelo (si esta dentro de
      // SESSION_GAP_MS, el proximo STREAM la considerara continua).
      try {
        chrome.storage.local.get(['bemodels_session:' + MODEL], o => {
          const s = o && o['bemodels_session:' + MODEL];
          if (s && s.startedAt) {
            _session = { startedAt: s.startedAt,
                         lastLiveAt: s.lastLiveAt || 0 };
            render();
          }
        });
      } catch (_) {}
      ensureDay(Date.now()).then(() => {
        render();
        pollBalance();
        pollEarnings();
        pollTelegram();
      });
      return;
    }
    if (d.kind === 'OWNSHOW') {
      _ownShow = d.own === true;
      render();
      return;
    }
    if (d.kind === 'DIAG') {
      try { chrome.storage.local.set({ bemodels_diag:
        Object.assign({}, d.diag, { ts: Date.now() }) }); } catch (_) {}
      return;
    }
    if (d.kind === 'STREAM') {
      const t = Number(d.startedAt) || 0;
      if (t <= 0) return;
      const now = Date.now();
      // SESION (sobrevive cruce de medianoche). Si no hay sesion o el
      // ultimo "ping en vivo" fue hace mas de SESSION_GAP_MS, es una
      // sesion nueva → startedAt = statusChangedAt del payload. Si esta
      // continua, mantener el startedAt original y solo actualizar el
      // ultimo timestamp visto.
      if (!_session || (now - (_session.lastLiveAt || 0) > SESSION_GAP_MS)) {
        _session = { startedAt: t, lastLiveAt: now };
        console.debug('[BeModels] sesion NUEVA startedAt=',
          new Date(t).toISOString(), '(src=' + (d.src || '?') + ')');
      } else {
        _session.lastLiveAt = now;
        // Si llega un t mas temprano (raro), lo usamos como inicio real.
        if (t < _session.startedAt) {
          _session.startedAt = t;
          console.debug('[BeModels] sesion startedAt corregido a',
            new Date(t).toISOString());
        }
      }
      if (MODEL) {
        try { chrome.storage.local.set({
          ['bemodels_session:' + MODEL]: _session }); } catch (_) {}
      }
      // legacy: aun mantenemos _apiStreamStart y DAY.streamStart para
      // compatibilidad si effStart cae a estos en algun edge case.
      if (_apiStreamStart == null || t < _apiStreamStart) _apiStreamStart = t;
      if (DAY && (DAY.streamStart == null || t < DAY.streamStart)) {
        DAY.streamStart = t; saveDaySoon();
      }
      render();
      return;
    }
    if (!MODEL) return;            // solo operamos con modelo detectada
    if (d.kind === 'CAM') {
      if (d.goal && d.goal.meta) _lastGoal = d.goal;
      render();
    } else if (d.kind === 'TIP') {
      addTip(d);
    } else if (d.kind === 'GOAL_EVT') {
      if (d.meta) _lastGoal = { nombre: d.nombre, meta: d.meta, recaudado: d.recaudado };
      if (d.completado) { if (DAY) { DAY.goalsHit++; saveDaySoon(); }
        flashAlert('🎯 GOAL COMPLETADO: ' + (d.nombre || ''), 'goal'); }
      render();
    }
  });

  // Reaccionar a cambios de ajustes desde el popup
  try {
    chrome.storage.onChanged.addListener((ch, area) => {
      if (area === 'local' && ch.bemodels_cfg) {
        const prev = CFG.manualModel;
        const prevBridge = CFG.bridgeUrl;
        CFG = Object.assign({}, DEFAULT_CFG, ch.bemodels_cfg.newValue || {});
        if (CFG.manualModel && CFG.manualModel !== prev) sendForce(CFG.manualModel);
        if (CFG.bridgeUrl !== prevBridge) { _tgNextAt = 0; pollTelegram(); }
        applyDemoState();
        render();
      }
    });
  } catch (_) {}

  // Refresco periodico (ritmo/ETA cambian con el tiempo aunque no lleguen tips)
  setInterval(() => { if (MODEL) render(); }, 30000);
  setInterval(pollBalance, 5000);   // lee el saldo del header de Stripchat
  setInterval(scanUserCards, 4000); // whale en sala (tarjeta de perfil)
  setInterval(earnTick, 60_000);    // Ganado oficial (re-consulta cada 2 min)
  setInterval(tgTick, 60_000);      // Bridge Telegram (inicio real de tx)
  setInterval(historicTick, 5 * 60_000); // Historico 7 dias (refresco 30 min)
  setInterval(rankingTick,  3 * 60_000); // Ranking top 1000 (refresco 15 min, Stripchat only)
  setInterval(bcenterTick,  2 * 60_000); // StripScore broadcast-center (refresco 5 min, Stripchat only)

  // ── Self-detect para plataformas SIN injected.js (Chaturbate) ──
  // Stripchat usa injected.js (MAIN world) que postea SELF al
  // content script. Otras plataformas no tienen injected — usamos
  // el adapter.detectSelf() en su lugar. Reintenta cada 4s hasta
  // que el DOM tenga lo necesario (username en cookie, header, etc).
  async function platformSelfTick() {
    if (!PLATFORM || PLATFORM.name === 'stripchat') return;  // Stripchat usa flujo SELF clásico
    if (MODEL && _realModel) return;                         // ya detectada
    if (!PLATFORM.detectSelf) return;
    try {
      let r = null;
      try { r = await PLATFORM.detectSelf(); } catch (_) {}
      let username = (r && r.username) ? r.username : null;
      let source   = (r && r.source) ? r.source : null;
      let ownShow  = !!(r && r.isOwnShow);
      let userId   = (r && r.userId) || null;
      // Fallback al manualModel del popup si la deteccion automatica
      // no encontro al username. Util en plataformas donde el DOM es
      // raro / cambiante (ej. Chaturbate sin cookie username).
      if (!username && CFG.manualModel && CFG.manualModel.trim()) {
        username = String(CFG.manualModel).toLowerCase().trim();
        source = 'manual';
        ownShow = true;   // si la usuaria lo activo manual, asumo es su sala
        console.log('[BeModels] usando CFG.manualModel como fallback:', username);
      }
      if (!username) return;   // sin username, no podemos hacer nada
      _realModel = username;
      MODEL = username;
      MODEL_NAME = username;
      if (userId) SELF_USER_ID = userId;
      _ownShow = ownShow;
      console.log('[BeModels] platform self resolved →', username,
        '· ownShow=' + ownShow, '· source=' + source);
      ensureProfileTz();
      retryPendingSummary();
      loadHistoric().then(() => render()).catch(() => {});
      loadGoalsCatalog();
      loadFavs();
      loadRanking();           // no-op si no es Stripchat
      loadAwardStored();
      loadBroadcastCenter();   // no-op si no es Stripchat
      ensureDay(Date.now()).then(() => {
        render();
        pollEarnings();
        pollTelegram();
      });
    } catch (e) { console.debug('[BeModels] platform.detectSelf err', e && e.message); }
  }
  if (PLATFORM && PLATFORM.name !== 'stripchat') {
    setInterval(platformSelfTick, 4000);
    // Primer intento al toque (después de que el DOM cargue).
    setTimeout(platformSelfTick, 500);
  }

  // Ganado del dia desde el endpoint /api/front/users/<id>/transactions.
  // Cadencia: cada ~2 min (los datos cambian con cada transaccion; no
  // necesita ser segundo a segundo). Skip si document.hidden o si no
  // hay userId. Errores silenciosos.
  async function pollEarnings() {
    if (!MODEL || MODEL === DEMO_MODEL) return;
    if (!isAuthorized(MODEL)) return;
    // Stripchat necesita SELF_USER_ID (numeric id de la API). Otras
    // plataformas (Chaturbate) identifican por cookie de sesion y
    // no requieren userId. Por eso solo gateamos Stripchat aca.
    if (PLATFORM && PLATFORM.name === 'stripchat' && !SELF_USER_ID) return;
    try {
      await ensureProfileTz();
      // Despachar al fetcher de la plataforma activa. Backward compat:
      // si no hay PLATFORM (instalacion vieja), cae a BMEarn directo
      // (que es el de Stripchat).
      const fetcher = (PLATFORM && PLATFORM.fetchEarningsToday) ||
                      (window.BMEarn && window.BMEarn.fetchEarningsToday);
      if (!fetcher) return;
      const s = await fetcher(SELF_USER_ID, effectiveTz());
      if (!s) return;
      const ts = Date.now();
      _earn = Object.assign({}, s, { ts });
      _earnNextAt = ts + 120_000;
      try { chrome.storage.local.set({ bemodels_earn: _earn }); } catch (_) {}
      render();
    } catch (_) {}
  }
  function earnTick() {
    if (typeof document !== 'undefined' && document.hidden) return;
    if (!authedActive() || MODEL === DEMO_MODEL) return;
    if (!SELF_USER_ID) return;
    if (Date.now() < _earnNextAt) return;
    _earnNextAt = Date.now() + 120_000;
    pollEarnings();
  }

  // ── Histórico para COMPARATIVA + vista 7 días ──────────────────────
  // Carga los últimos 7 días del modelo desde la API REAL de Stripchat
  // (/api/front/users/<id>/transactions). El storage local del navegador
  // era poco confiable: las modelos trabajan en distintos perfiles Chrome
  // / distintas PC y el storage es por perfil → BeModels veía días vacíos
  // aunque la modelo SI hubiera trabajado. Ir a la fuente real arregla
  // eso y los datos cuadran con lo que ve en el dashboard de Stripchat.
  //
  // Estrategia: UNA sola llamada al endpoint con rango [hace 7 días, ahora].
  // Reusa la paginación existente. Agrupa transacciones por fecha LOCAL
  // (usa effectiveTz() para bucket correcto en cambios de día).
  //
  // Refresca cada 30 min — los días anteriores son casi inmutables, no
  // tiene sentido pollear más seguido. Pageable; podemos exponer un
  // forzado manual a futuro si hace falta.
  async function loadHistoric() {
    if (!MODEL || MODEL === DEMO_MODEL) return;
    if (PLATFORM && PLATFORM.name === 'stripchat' && !SELF_USER_ID) return;
    // Despacho al adapter activo (Stripchat / Chaturbate / etc).
    const ranger = (PLATFORM && PLATFORM.fetchEarningsRange) ||
                   (window.BMEarn && window.BMEarn.fetchEarningsRange);
    if (!ranger) return;
    // Rango: desde 00:00 (hora local) de hace 7 días hasta ahora.
    // todayMidnightUTC lo provee el helper común de BMEarn.
    let fromIso, untilIso;
    try {
      const tz = effectiveTz();
      const todayMid = window.BMEarn && window.BMEarn.todayMidnightUTC
        ? window.BMEarn.todayMidnightUTC(tz) : null;
      if (!todayMid) return;
      fromIso = new Date(new Date(todayMid).getTime() - 7 * 86400000).toISOString();
      untilIso = new Date().toISOString();
    } catch (_) { return; }
    try {
      const r = await ranger(SELF_USER_ID, fromIso, untilIso);
      if (!r || !Array.isArray(r.tx)) return;
      const tz = effectiveTz();
      const fmt = new Intl.DateTimeFormat('en-CA', { timeZone: tz,
        year: 'numeric', month: '2-digit', day: '2-digit' });
      // Bucket por fecha local: cada tx va al día calendario en TZ del perfil.
      // Trackeamos también firstTs/lastTs para poder estimar la
      // duración del show de cada día (proxy: span entre primer y
      // último tip — no es exactamente el broadcast time pero es una
      // aproximación útil para "ayer transmitió X horas").
      const byDate = {};   // 'YYYY-MM-DD' → { date, tokens, txCount, hours, firstTs, lastTs }
      for (const t of r.tx) {
        if (!t.ts || !(t.tokens > 0)) continue;
        const d = fmt.format(new Date(t.ts));
        if (!byDate[d]) {
          byDate[d] = { date: d, tokens: 0, txCount: 0, hours: {},
                        firstTs: t.ts, lastTs: t.ts };
        }
        byDate[d].tokens += t.tokens;
        byDate[d].txCount++;
        if (t.ts < byDate[d].firstTs) byDate[d].firstTs = t.ts;
        if (t.ts > byDate[d].lastTs)  byDate[d].lastTs  = t.ts;
        // Granularidad horaria local (para cumulativeByHour del COMPARATIVA).
        try {
          const h = Number(new Intl.DateTimeFormat('en-GB', {
            timeZone: tz, hour: '2-digit', hour12: false
          }).format(new Date(t.ts)));
          byDate[d].hours[h] = (byDate[d].hours[h] || 0) + t.tokens;
        } catch (_) {}
      }
      // Generar las 7 fechas previas (excluyendo HOY) ordenadas más reciente → más vieja.
      const today = localDateStr();
      const dates = [];
      for (let i = 1; i <= 7; i++) {
        const d = new Date(Date.now() - i * 86400000);
        dates.push(localDateStr(d.getTime()));
      }
      // Filas "vacías" para los días sin transacciones (para que la
      // vista 7 días los muestre como 0 tk, no los oculte).
      for (const d of dates) {
        if (!byDate[d]) byDate[d] = { date: d, tokens: 0, txCount: 0, hours: {} };
      }
      const last7 = dates.map(d => byDate[d]);
      const week7Avg = Math.round(
        last7.reduce((a, d) => a + (d.tokens || 0), 0) / last7.length);
      let best7 = null;
      for (const d of last7) {
        if (!best7 || (d.tokens || 0) > (best7.tokens || 0)) best7 = d;
      }
      _historic = {
        byDate,
        yesterday:    byDate[dates[0]] || null,
        last7,
        week7Avg,
        best7,
        dates,        // más reciente → más vieja (no incluye HOY)
        truncated:    !!r.truncated,  // si la paginación se cortó
        source:       'api'
      };
      _historicNextAt = Date.now() + 30 * 60 * 1000;  // 30 min
      console.debug('[BeModels] historic OK desde API:',
        '7d=' + week7Avg, 'best=' + (best7 && best7.date) + ' (' + (best7 && best7.tokens) + ' tk)',
        'tx total=' + r.tx.length, r.truncated ? 'TRUNCADO' : '');
      render();
      return _historic;
    } catch (e) {
      console.debug('[BeModels] historic err', e && e.message);
    }
  }
  function historicTick() {
    if (!MODEL || MODEL === DEMO_MODEL) return;
    if (Date.now() < _historicNextAt) return;
    loadHistoric();
  }

  // Suma los tokens del DAY desde hora 0 hasta currentHour inclusive.
  // Útil para comparar "ayer al MISMO horario del día" sin importar a
  // qué hora arrancó cada show. Si el día no tiene `hours`, devuelve 0.
  function cumulativeByHour(day, currentHour) {
    if (!day || !day.hours) return 0;
    let sum = 0;
    for (let h = 0; h <= currentHour; h++) sum += (day.hours[h] || 0);
    return sum;
  }

  // Detecta la TZ del perfil de Stripchat una sola vez por carga
  // (idempotente: si ya tenemos _detectedTz, no hace nada). Si
  // BMProfile no esta o el endpoint no devuelve TZ, queda en null
  // y el resto del codigo usa CFG.tz como fallback (effectiveTz).
  async function ensureProfileTz() {
    if (_detectedTz || _tzDetectTried) return;
    if (!window.BMProfile) return;
    // profileFetcher.js consulta endpoints específicos de Stripchat
    // (/api/front/users/me). En otras plataformas devuelve 404 ruido.
    // Skip — la TZ cae al CFG.tz default (America/Bogota) que sirve
    // para la mayoría del estudio.
    if (PLATFORM && PLATFORM.name !== 'stripchat') {
      _tzDetectTried = true;
      return;
    }
    _tzDetectTried = true;
    try {
      const r = await window.BMProfile.detectProfileTz(SELF_USER_ID);
      if (r && r.tz) {
        _detectedTz    = r.tz;
        _detectedTzSrc = r.source;
        console.debug('[BeModels] TZ del perfil detectada:',
          _detectedTz, '(' + _detectedTzSrc + ') · CFG.tz =', CFG.tz);
        // Si la TZ detectada no coincide con CFG.tz, lo flagueamos
        // a la usuaria en el panel — es probablemente la causa de
        // discrepancias entre los totales de BeModels y los del
        // dashboard de Stripchat.
        if (CFG.tz && _detectedTz !== CFG.tz) {
          console.warn('[BeModels] CFG.tz (' + CFG.tz + ') != TZ del perfil ('
            + _detectedTz + '). Se usara la del perfil para que coincida con Stripchat.');
        }
      }
    } catch (e) {
      console.debug('[BeModels] ensureProfileTz ERR', e && e.message);
    }
  }

  // (v0.1.37: pollRankStats/rkTick removidos junto con la franja RANK.)

  // Bridge Telegram: cada 60s consulta el server BeStudio.
  //  - isLive=true  + startedAt → guarda _tgStart, resetea offStreak.
  //  - isLive=false (modelo ya no esta en el set live = 🔴 procesado
  //    por el launcher) → incrementa offStreak. Tras TG_OFF_THRESHOLD
  //    polls consecutivos confirmamos el CIERRE: limpiamos _tgStart,
  //    cerramos la sesion del WS, y la HUD pasa a estado OFFLINE.
  //  - error (red caida, bridge offline) → NO toca offStreak. Un
  //    glitch no debe cerrar un show real en curso.
  async function pollTelegram() {
    if (!window.BMTelegram || !MODEL || MODEL === DEMO_MODEL) return;
    if (!isAuthorized(MODEL)) return;
    const url = (CFG.bridgeUrl || '').trim();
    if (!url) return;
    const r = await window.BMTelegram.getStart(MODEL, url, CFG.bridgeAuthToken);
    _tgLastPollAt = Date.now();
    _tgLastPollRes = r && r.error ? 'error'
                   : (r && r.isLive ? 'live' : 'offline');
    if (r && r.error) return;             // bridge no responde → no decidir
    if (r && r.isLive && r.startedAt) {
      _tgOffStreak = 0;
      // Si veniamos de un cierre y entra un 🟢 con startedAt DISTINTO
      // al que tenia el show cerrado, es un show NUEVO → destrabar
      // estado offline. Si es el mismo startedAt (race condition entre
      // launcher y bridge), no tocamos nada.
      if (_tgClosedAt && _frozenStart && r.startedAt !== _frozenStart) {
        console.debug('[BeModels] nuevo show detectado, descongelo estado');
        _tgClosedAt  = null;
        _frozenStart = null;
      }
      if (_tgStart !== r.startedAt) {
        _tgStart = r.startedAt;
        console.debug('[BeModels] tgStart =', new Date(r.startedAt).toISOString());
        render();
      }
      return;
    }
    // isLive=false sin error: la modelo ya no esta en el set del launcher.
    _tgOffStreak++;
    console.debug('[BeModels] tg off streak =', _tgOffStreak, '/', TG_OFF_THRESHOLD);
    if (_tgOffStreak >= TG_OFF_THRESHOLD && _tgStart) {
      handleShowClosed('telegram');
    }
  }
  // Cierre explicito del show: limpia _tgStart y la sesion local.
  // GANADO y EN VIVO quedan CONGELADOS en el ultimo valor (no se sigue
  // sumando tiempo ni esperando tips). La HUD muestra 🔴 OFFLINE.
  function handleShowClosed(reason) {
    if (_tgClosedAt) return;              // ya cerrado
    // CAPTURAR el inicio del show ANTES de limpiar las fuentes — sino
    // effStart() pierde su input y GANADO/RITMO se van a 0/raros.
    _frozenStart = effStart();
    _tgClosedAt  = Date.now();
    const wasStart = _tgStart || _frozenStart;
    _tgStart = null;
    // Persistir cierre de sesion para que el proximo 🟢 arranque limpio.
    if (MODEL && _session && _session.startedAt) {
      try {
        chrome.storage.local.remove('bemodels_session:' + MODEL);
      } catch (_) {}
      _session = null;
    }
    console.warn('[BeModels] show CERRADO (' + reason + ') — ' +
      (wasStart ? 'duracion ~' + Math.round((_tgClosedAt - wasStart) / 60000) + 'min' : ''));
    render();
    // Enviar resumen al canal Telegram (via bridge). Idempotente del
    // lado del server (dedupe por model+startedAt), asi que si la
    // modelo reabre la pagina post-cierre no spamea.
    sendShowSummary().catch(() => {});
  }

  // POST /api/summary al bridge: el server formatea y postea al canal
  // Telegram. Si bridgeUrl no esta seteado o el toggle del panel esta
  // off, no hace nada. Persistencia: antes de enviar guarda el payload
  // en chrome.storage.local como bemodels_pending_summary y solo lo
  // borra al confirmar el send → si el bridge esta caido o la red
  // falla, en el proximo arranque de BeModels se reintenta (ver
  // retryPendingSummary). Dedupe del server (model|startedAt) evita
  // doble envio si el retry corre cuando el original llego tarde.
  //
  // Calcula tambien tipsCount + topTipper de la SESION (no del dia)
  // sumando _earn.tx filtrado por ts >= _frozenStart para que el
  // mensaje del canal tenga mas contexto util.
  async function sendShowSummary() {
    if (CFG.summaryToTelegram === false) return;
    const base = (CFG.bridgeUrl || '').trim().replace(/\/+$/, '');
    if (!base || !/^https?:\/\//i.test(base)) return;
    if (!_frozenStart || !_tgClosedAt) return;
    const a = analytics();
    const durMin = Math.max(0, (_tgClosedAt - _frozenStart) / 60000);
    // GANADO del resumen con fallbacks robustos. Al momento del cierre
    // analytics() a veces da a.tot=0 (estado raro de _earn / sesión
    // congelada justo cuando se limpian fuentes). Respaldos en orden:
    //   1. a.tot (sesión, lo ideal)
    //   2. a.dayTot (total del día del API)
    //   3. _earn.tokens (total día crudo)
    //   4. _lastGoodTot (último GANADO bueno memorizado del HUD)
    let tot = Math.round(a.tot || 0);
    if (tot <= 0) {
      const fb = Math.max(
        Math.round(a.dayTot || 0),
        Math.round((_earn && _earn.tokens) || 0),
        Math.round(_lastGoodTot || 0)
      );
      if (fb > 0) {
        console.warn('[BeModels] summary: a.tot=0 al cierre, uso respaldo=' + fb);
        tot = fb;
      }
    }
    const ritmo  = durMin > 0 ? Math.round(tot / (durMin / 60)) : 0;
    // ── Tipper stats de la SESION ───────────────────────────────
    let tipsCount = 0, topTipperUser = null, topTipperTk = 0;
    if (_earn && Array.isArray(_earn.tx)) {
      const byUser = {};
      for (const t of _earn.tx) {
        if (!t || !t.ts || t.ts < _frozenStart || t.ts > _tgClosedAt) continue;
        if (!(t.tokens > 0)) continue;
        tipsCount++;
        const u = (t.user && t.user.trim()) || '(anon)';
        byUser[u] = (byUser[u] || 0) + t.tokens;
      }
      for (const u of Object.keys(byUser)) {
        if (byUser[u] > topTipperTk) { topTipperTk = byUser[u]; topTipperUser = u; }
      }
    }
    // ── COP (pesos): mismo cálculo que el HUD (USD bruto × share × tasa) ──
    const usdGross = PLATFORM && PLATFORM.tkToUsd ? PLATFORM.tkToUsd(tot) : (tot / 20);
    const copShare = (PLATFORM && Number.isFinite(PLATFORM.modelShare))
      ? PLATFORM.modelShare : (Number(CFG.copShareFactor) || 0.55);
    const copRate  = Number(CFG.copRate) || 3449;
    const cop = Math.round(usdGross * copShare * copRate);
    // ── Ranking + StripScore (Stripchat) ────────────────────────
    const rankPos = _rankingMine ? _rankingMine.position : null;
    const rankSP  = (_rankingMine && _rankingMine.stripPoints != null)
      ? _rankingMine.stripPoints : null;
    const stripScore = (_bcenter && _bcenter.stripScore != null)
      ? _bcenter.stripScore : null;
    const payload = {
      model:       MODEL,
      tokens:      tot,
      usd:         Number((tot / 20).toFixed(2)),
      cop:         cop,                 // pesos netos de la modelo
      durationMin: Math.round(durMin),
      ritmoTkH:    ritmo,
      goalTk:      a.goalTk || 0,
      goalPct:     a.pct    || 0,
      tipsCount,
      topTipper:    topTipperUser,
      topTipperTk: topTipperTk > 0 ? topTipperTk : null,
      rankPos,                          // puesto leaderboard (o null)
      rankStripPoints: rankSP,          // StripPoints (o null)
      stripScore,                       // StripScore 0-1000 (o null)
      platform:    (PLATFORM && PLATFORM.name) || 'stripchat',
      startedAt:   new Date(_frozenStart).toISOString(),
      closedAt:    new Date(_tgClosedAt).toISOString()
    };
    // Persistir antes de intentar — sobrevive cierre de pestana o
    // bridge caido. Incluye base y bridgeAuthToken usados para que
    // el retry no dependa de que CFG no haya cambiado.
    const pending = { payload, base, ts: Date.now(),
                      bridgeAuthToken: CFG.bridgeAuthToken || null };
    try { chrome.storage.local.set({ bemodels_pending_summary: pending }); } catch (_) {}
    const sent = await postSummaryAttempt(pending);
    if (sent) {
      try { chrome.storage.local.remove('bemodels_pending_summary'); } catch (_) {}
    }
  }

  // Hace el POST efectivo. Devuelve true SOLO si el server confirmo
  // (sent=true o skipped=dup). Cualquier otra cosa (red, 5xx, 401,
  // 400 con error real) → false → el caller mantiene el pending para
  // reintento.
  async function postSummaryAttempt(pending) {
    if (!pending || !pending.payload || !pending.base) return false;
    try {
      const headers = { 'content-type': 'application/json', accept: 'application/json' };
      if (pending.bridgeAuthToken) {
        headers['Authorization'] = 'Bearer ' + String(pending.bridgeAuthToken).trim();
      }
      const r = await fetch(pending.base + '/api/summary', {
        method: 'POST', credentials: 'omit', cache: 'no-store',
        headers, body: JSON.stringify(pending.payload)
      });
      const j = await r.json().catch(() => ({}));
      if (r.status === 401) {
        console.warn('[BeModels] summary 401 unauthorized — revisar bridgeAuthToken');
        return false;
      }
      if (!r.ok) {
        console.warn('[BeModels] summary POST !ok', r.status, j);
        return false;
      }
      // sent=true → posteado; skipped=dup → server ya lo tenia → ack ok.
      const ok = (j && (j.sent === true || j.skipped === 'dup'));
      console.debug('[BeModels] summary ack:', ok, '· resp:', j);
      return ok;
    } catch (e) {
      console.debug('[BeModels] summary POST err', e && e.message);
      return false;
    }
  }

  // Reintento del summary pendiente al arrancar BeModels. Lo dispara
  // el handler de SELF una vez que MODEL esta seteado. TTL 24h
  // (>24h descartamos, el dato ya no tiene mucho sentido reenviar).
  async function retryPendingSummary() {
    try {
      const o = await new Promise(res => chrome.storage.local.get(['bemodels_pending_summary'], res));
      const p = o && o.bemodels_pending_summary;
      if (!p || !p.payload) return;
      if (p.payload.model && MODEL && p.payload.model !== MODEL) return; // otra modelo
      const ageMs = Date.now() - (p.ts || 0);
      if (ageMs > 24 * 3600 * 1000) {
        console.warn('[BeModels] summary pendiente > 24h, descartado');
        try { chrome.storage.local.remove('bemodels_pending_summary'); } catch (_) {}
        return;
      }
      console.log('[BeModels] reintentando summary pendiente (edad ' +
        Math.round(ageMs / 60000) + ' min)');
      const sent = await postSummaryAttempt(p);
      if (sent) {
        try { chrome.storage.local.remove('bemodels_pending_summary'); } catch (_) {}
      }
    } catch (e) {
      console.debug('[BeModels] retryPendingSummary err', e && e.message);
    }
  }

  function tgTick() {
    if (typeof document !== 'undefined' && document.hidden) return;
    if (!authedActive() || MODEL === DEMO_MODEL) return;
    if (!CFG.bridgeUrl) return;
    if (Date.now() < _tgNextAt) return;
    _tgNextAt = Date.now() + 60_000;
    pollTelegram();
  }

  try {
    chrome.storage.local.get(['bemodels_earn'], o => {
      const e = o && o.bemodels_earn;
      if (e && e.tokens != null && e.from) {
        // No restaurar si es de un DIA anterior (en la TZ del perfil):
        // pollEarnings refrescara igual al primer tick, pero asi no se
        // muestra brevemente el total de ayer al cargar hoy.
        try {
          const fmt = new Intl.DateTimeFormat('en-CA', { timeZone: effectiveTz(),
            year:'numeric', month:'2-digit', day:'2-digit' });
          if (fmt.format(new Date(e.from)) === fmt.format(new Date())) _earn = e;
        } catch (_) { _earn = e; }
      }
      render();
    });
  } catch (_) {}

  loadCfg().then(() => {
    applyDemoState();
    pollBalance();
    if (CFG.manualModel) setTimeout(() => sendForce(CFG.manualModel), 800);
  });
})();
