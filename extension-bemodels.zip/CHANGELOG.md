# BeModels — CHANGELOG

Reglas de versionado (igual que BeStudio): CADA cambio sube
`version` en `manifest.json` + `BM_BUILD` en `bemodels/injected.js`
(+ `BM_SW_BUILD` en `background.js` si se toca el SW) + entrada
aqui, y se hace `git commit` + `git push origin master`.

## 0.1.85 — 2026-06-05 — Resumen de cierre enriquecido (COP + ranking + StripScore)
- Pedido de la operadora: agregar al resumen de Telegram los datos
  que el HUD ya muestra (pesos, puesto, StripScore).
- **Payload de `sendShowSummary()`** suma:
  - `cop`: pesos netos (USD bruto × share plataforma × tasa COP).
  - `rankPos` + `rankStripPoints`: del `_rankingMine` (si está en
    el leaderboard).
  - `stripScore`: del `_bcenter` (broadcast-center).
  - `platform`: nombre de la plataforma (stripchat/chaturbate).
- **Bridge 0.17.1 `Build-SummaryText`** renderiza las líneas nuevas
  (todas condicionales — solo si vienen datos):
  ```
  💰 Resumen sesion | thealejandrodolls · stripchat
  🕒 16:08 -> 20:42 (4h 33m)
  🪙 Ganado: 5089 tk (~$254.45 USD)
  💵 ~ $482.679 COP
  📈 Ritmo: 1108 tk/h
  💬 Tips: 87 · top: super_fan (850 tk)
  🎯 Meta diaria: 5089/1200 tk (424%)
  🏆 Puesto 196 · 482 StripPoints
  ⭐ StripScore: 696
  ```
- Las líneas de ranking/StripScore solo aparecen en Stripchat (las
  otras plataformas no envían esos campos).
- **Deploy**: restart del bridge en el server para cargar 0.17.1.

## 0.1.84 — 2026-06-05 — FIX resumen "0 tk" + cierre más rápido
- Reporte de la operadora: al cerrar el show, el resumen Telegram
  llegó con **"Ganado: 0 tk"** aunque el HUD mostraba 5089 tk.
- **Causa**: en `sendShowSummary()`, `analytics()` se recalcula al
  momento del cierre. Justo ahí `_earn`/sesión congelada puede dar
  `a.tot=0` (estado transitorio cuando se limpian las fuentes en
  `handleShowClosed`). El payload mandaba ese 0.
- **Fix — fallbacks robustos** del GANADO en el resumen:
  1. `a.tot` (sesión, ideal).
  2. `a.dayTot` (total del día del API).
  3. `_earn.tokens` (total día crudo).
  4. **`_lastGoodTot`**: nueva variable que memoriza el último GANADO
     bueno (>0) visto en cualquier render del HUD. Es el respaldo
     definitivo — si el HUD mostró 5089 alguna vez, el resumen usa
     5089 aunque al cierre dé 0.
  - El `ritmoTkH` se recalcula con el `tot` corregido.
- **Cierre más rápido**: `TG_OFF_THRESHOLD` baja de 2 a 1. Antes
  esperaba 2 polls offline consecutivos (~120s); ahora 1 poll
  offline limpio (~60s). El launcher es estable (TTL + dedup) así
  que el riesgo de falso cierre es bajo, y el dedup del bridge evita
  un segundo resumen si el show reabre.

## 0.1.83 — 2026-06-05 — fetchMyRanking prueba varios períodos
- Log de la operadora reveló: `ranking server OK · no en snapshot` +
  `API-directa: no encontrada en female/sa top 1000`. Pero el badge
  del perfil mostraba "Puesto 382 en el Top 1000".
- **Causa**: el badge corresponde al ranking **MENSUAL regional**
  (`current-month-south-america`, la URL que la modelo visitó), NO al
  ranking `current` (horario/en vivo) que usaban el server y el
  fetch directo. Son leaderboards distintos.
- **Fix**: `fetchMyRanking` ahora prueba una lista de períodos en
  orden: `['current-month', 'month', 'current', 'current-week', 'week']`.
  Para cada uno pagina el top 1000 buscando el username; devuelve el
  primero que la liste, incluyendo el `period` que funcionó. Si la
  primera página de un período viene vacía (período inválido para el
  scope), salta al siguiente sin desperdiciar requests.
- El log ahora muestra el período encontrado:
  `ranking API-directa OK · puesto=382 (female/sa/current-month)`.

## 0.1.82 — 2026-06-05 — Puesto del leaderboard via API directa (no depende del server)
- Reporte: el StripScore aparecía pero el PUESTO no. Causa: ni el
  server (probable falta de bypass CF Access para
  `/api/stripchat-ranking/latest`) ni el badge persistido tenían el
  dato → el segmento TOP caía al StripScore solo.
- **Fix — fetch directo del cliente**: `platforms/stripchat.js` suma
  `fetchMyRanking(username, gender, continent)` que pagina
  `/api/front/v5/models/top?gender=female&period=current&continent=sa`
  (mismo endpoint que el colector del server) DESDE EL CLIENTE con
  las cookies de la modelo. Busca su username en el top 1000 y
  devuelve `{ position, stripPoints, total }`.
- **`loadRanking()` ahora tiene 2 niveles**:
  1. Server (1 request al bridge — rápido si está accesible).
  2. Si el server no la encontró → API directa de Stripchat (10
     requests paginados, pero solo cada 15 min). Esto **elimina la
     dependencia** del bridge / CF Access / badge para el puesto.
- **Nuevas CFG** `rankGender` (`female`) y `rankContinent` (`sa`) —
  default para el estudio colombiano. Editables si hay parejas o
  modelos de otro continente.
- Resultado: el puesto aparece en la transmisión sin pasos manuales
  (siempre que la modelo esté en el top 1000 de su género/continente).
- El bypass de CF Access para `/api/stripchat-ranking/latest` sigue
  siendo útil (da los StripPoints del snapshot del server + ahorra
  los 10 requests del cliente), pero ya NO es bloqueante.

## 0.1.81 — 2026-06-05 — StripScore en el segmento TOP
- Pedido de la operadora: *"y el stripcore no lo muestra?"* (StripScore).
- El StripScore (0-1000, salud del perfil + actividad) NO está en el
  DOM de la sala — pero Stripchat lo expone autenticado en
  `/api/front/models/<uid>/broadcast-center` (mismo endpoint que
  captura BeCapture v1.8.7 para el dashboard).
- **`platforms/stripchat.js`**: nuevo método `fetchBroadcastCenter(uid)`
  → `{ stripScore, favoritedCount, tokensPerHour, privateShowRating, ts }`.
- **`content.js`**:
  - `loadBroadcastCenter()` fetchea cada 5 min (Stripchat only).
    Usa `SELF_USER_ID`. Cae silencioso si no hay uid.
  - El segmento TOP suma una línea `★ StripScore N` (verde ≥800,
    ámbar ≥500, rojo <500) en los branches que muestran puesto.
  - Si NO hay puesto (ni server ni badge) pero SÍ StripScore, el
    StripScore pasa a ser la métrica principal del segmento:
    `★ 674 · StripScore · N favoritos`.
- Refresca cada 5 min vía `bcenterTick`.
- Solo Stripchat. Chaturbate/otras no tienen StripScore.

## 0.1.80 — 2026-06-05 — Award del DOM persistido (funciona en la transmisión)
- Reporte de la operadora: el segmento TOP mostraba "Puesto 382" al
  abrir `/top/girls/current-month-south-america`, pero al volver a la
  página de transmisión (donde BeModels realmente vive) decía "Fuera
  del top".
- **Causa**: el badge `TopModelsAwardLabel` SOLO se renderiza en la
  página del leaderboard / creator portal — NO en la sala de
  transmisión. Y el colector del server (top global 1000) no incluye
  a TheAlejandroDolls (puesto 382 es de un leaderboard regional/mensual).
- **Fix — persistencia del award en storage**:
  - `_awardDOM` + `bemodels_award:<modelo>` en chrome.storage.
  - `captureAwardFromDOM()`: en cada render, si la página actual
    expone el badge, lo captura y persiste (con throttle de 5 min /
    cambio de puesto para no escribir storage de más).
  - `loadAwardStored()`: hidrata `_awardDOM` al detectar MODEL.
  - El render usa el award persistido aunque el badge no esté en el
    DOM actual → en la transmisión muestra el último puesto conocido
    con "hace X min/h/d".
- **Flujo para la modelo**: abre su ranking/creator portal una vez →
  BeModels captura el puesto → mientras transmite, el segmento TOP
  muestra ese puesto persistido. Si nunca lo visitó, muestra hint
  "abrí tu ranking para ver tu puesto exacto".
- Prioridad del segmento TOP:
  1. Server top 1000 (`_rankingMine`) → puesto + StripPoints.
  2. Award DOM persistido (`_awardDOM`) → puesto exacto + categoría + hace X.
  3. Nada cargado → "cargando…".
  4. Fuera del top sin award → hint para abrir el ranking.

## 0.1.79 — 2026-06-05 — TOP combina server + DOM (puesto exacto fuera del top 1000)
- Reporte de la operadora: la página de Stripchat mostraba
  **"Puesto 1057 en el Top 1000"** pero BeModels decía "Fuera del top".
  Causa: el colector del server (`/api/stripchat-ranking/latest`) solo
  captura el **top 1000** del leaderboard v5/top; una modelo en puesto
  1057 no aparece ahí.
- **Fix — dos fuentes combinadas**:
  1. **Server** (puesto + StripPoints, top 1000): si la modelo está
     ahí, se usa (fuente rica con StripPoints).
  2. **DOM** (`TopModelsAwardLabel`): badge del header de la sala
     propia que muestra el puesto EXACTO de cualquier rango (incluso
     >1000). Mismo selector que BeCapture v1.8.7.
- **`platforms/stripchat.js`**: nuevo método `readRankingDOM()` que
  parsea `[class*="TopModelsAwardLabel__strong"]` → `{ puesto, topSize,
  categoria, rawText }`. Categoría inferida del topSize (20=parejas,
  100=chicos/trans, 1000=chicas).
- **`content.js`**: el render del segmento TOP ahora:
  - Si `_rankingMine` (server top 1000) → `Puesto N · X StripPoints · top 1000`.
  - Sino, si DOM tiene puesto → `Puesto 1057 · en el Top 1000 · chicas · badge de tu sala`.
  - Sino, si nada cargó → `cargando…`.
  - Sino → `Fuera del top`.
- El label del segmento cambia de "TOP 1K" a "TOP" (porque ahora
  cubre puestos fuera del top 1000 también).
- Color del puesto (DOM): verde si ≤10% del top, ámbar ≤50%, rojo
  el resto — relativo al `topSize` del badge.

## 0.1.78 — 2026-06-02 — Segmento TOP 1K en HUD + traductor off por default
- Pedido de la operadora:
  - *"hay endpoint nuevos que estoy capturando en la extensiones y
    guardando en el servidor que nos puede servir para los tops esos
    e puede integrar?"* → integrado el ranking Top 1000 de Stripchat.
  - *"de momento desactiva el boton de traductor que no se esta usando"*
    → gateado por CFG.

### Segmento TOP 1K (Stripchat only)
- Endpoint en el bridge ya existe (v0.10.0): `GET /api/stripchat-ranking/latest`
  expone `{ collectedAt, count, models[{ username, position, stripPoints,
  country, ... }] }`. Lo escribe `stripchat-top-collect.ps1` cada hora.
- **`loadRanking()`** en BeModels lo fetchea cada 15 min. Cache en
  `chrome.storage.local::bemodels_ranking_cache` para mostrar al
  instante en cargas frescas. Cae silenciosamente si bridge 404 (el
  colector aún no corrió).
- **Nuevo segmento `#bm-top`** en el HUD entre RITMO y SUGERENCIAS:
  - Si la modelo está en el top 1000:
    `TOP 1K · Puesto N · X StripPoints · de 1000 · hace M min`
    Color del puesto: ✅ verde si ≤100, 🟡 ámbar si ≤500, 🔴 rojo
    si >500 (= aún en top pero zona baja).
  - Si está fuera: `TOP 1K · Fuera del top · de N modelos · hace M min`.
  - En cargas frescas sin caché: `cargando…`.
- **Solo en Stripchat**: si `PLATFORM.name !== 'stripchat'` (Chaturbate,
  futuras plataformas), el segmento se oculta con `display:none`.
  Cada plataforma tiene su propio ranking, sin integrar todavía.

### Botón Traductor desactivado
- Nueva CFG `translatorButtonEnabled` (default `false`). El botón
  `🌐 Traductor` solo se renderiza si está `true`. Reactivar cuando
  BeTranslate implemente el listener.

### Pendiente operadora
- Para que BeModels (en chaturbate / stripchat de la modelo) pueda
  llamar a `/api/stripchat-ranking/latest` vía `https://bestudio.bepraga.com`,
  agregar el path al **mismo bypass de CF Access** que ya tiene
  `/api/start`, `/api/summary`, `/api/goal-ideas`. Tu app "BeModels
  Bridge - Public Endpoints" → editar → sumar el path
  `api/stripchat-ranking/latest` a las Public hostnames.

## 0.1.77 — 2026-06-02 — Preview auto-detecta tipo (img/video/iframe)
- La usuaria preguntó qué hacer cuando un sitio (Redgifs, Gfycat,
  etc.) solo ofrece embed iframe en vez de URL directa al `.gif/.mp4`.
- **Fix**: el preview ahora **auto-detecta el tipo de URL** y usa el
  elemento HTML correcto:
  - URL termina en `.gif/.webp/.png/.jpg/.jpeg` → `<img>` (ligero, autoplay).
  - URL termina en `.mp4/.webm/.mov` → `<video autoplay loop muted playsinline>`.
  - Cualquier otra URL → `<iframe sandbox="allow-scripts allow-same-origin allow-presentation">`.
- **`detectGifMediaType(url)`** helper: parsea URL (sin querystring/hash)
  contra patrones conocidos. Default a iframe.
- **`buildGifInner(url)`**: arma el HTML del elemento correcto.
  Iframes traen `sandbox` para limitar daño en caso de embed malicioso
  (scripts permitidos para el player, sin top-navigation).
- **CSS**: `.bm-ideas-gif-pop iframe` con 400×400 fijo (los iframes
  internos manejan su propio aspect ratio del player). Cuando el
  popup es de tipo iframe, `pointer-events: auto` para permitir
  interacción con el player (play/pause); para img/video queda en
  `none` (autoplay, no necesita click).
- **`bestudio_goals.example.json`**: doc del campo `gif` actualizada
  con los 3 tipos explicados + ejemplos para cada uno. Agregada una
  variante en el nicho "Aceite" con URL de redgifs como placeholder.
- **Cómo conseguir URL de Redgifs**: en el page del GIF, click en
  botón **"Embed"** → opción **"Fixed frame"** → copiar SOLO la URL
  del `src` del iframe (no el HTML completo), pegarla en el campo
  `gif` del JSON.

## 0.1.76 — 2026-06-02 — Preview de GIF más grande + tip para editar catálogo
- Tras testear v0.1.75 con URL real `.webp`, la operadora pidió que el
  preview se vea más grande + dónde se edita la lista.
- **Preview agrandado**: `.bm-ideas-gif-pop` pasa de 280×280 → 400×400.
  La imagen mantiene `object-fit: contain` (no se estira si es chica).
- **Posicionamiento mejorado**: el JS ahora intenta poner el preview
  a la derecha del item; si no entra en el viewport, lo pone a la
  izquierda. Antes podía cortarse en pantallas chicas.
- **Tip de edición**: agregado al footer del popover de Ideas un texto
  chico explicando que para editar el catálogo hay que editar
  `C:\BePraga\bestudio_goals.json` en el server con Notepad++. Incluye
  referencia al archivo `bestudio_goals.example.json` del repo para
  ver el formato.

## 0.1.75 — 2026-06-02 — Default arriba + ideas con variantes + GIF preview
- Dos pedidos de la usuaria:
  - *"quiero que por defecto aparezca arriba"*.
  - *"hay forma de que una idea de show sea aceite y salgan no se
    10 ideas y al pasarle el raton por idea uno se cargue este gif"*.

### 1. Default barPos = 'top'
- `DEFAULT_CFG.barPos` cambia de `'bottom'` a `'top'`. Modelos nuevas
  ven la barra arriba sin tener que configurar. Modelos existentes
  mantienen su última config (no se pisa storage).

### 2. Ideas con variantes (sub-metas anidadas)
- **Schema extendido**: un item del catálogo puede tener `variantes[]`,
  cada una con `tk`, `txt` y opcional `gif`. Ejemplo:
  ```json
  {
    "tk": 200,
    "txt": "Aceite (ver variantes)",
    "variantes": [
      { "tk": 200, "txt": "Aceite en tetas · 1 min", "gif": "https://.../oil1.gif" },
      { "tk": 250, "txt": "Aceite en cola · 1 min",  "gif": "https://.../oil2.gif" },
      { "tk": 333, "txt": "Aceite + masaje · 2 min" }
    ]
  }
  ```
- **UI**: items con variantes muestran badge `▸ N` (N = cantidad).
  Click sobre el item → expande la lista de variantes inline. Click
  sobre una variante copia su texto al clipboard. El ▸ rota 90° al
  expandir.
- **CSS**: nuevas reglas `.bm-ideas-vmark`, `.bm-ideas-vlist`,
  `.bm-ideas-variant` (fondo lavanda sutil, hover destacado).

### 3. GIF preview on hover
- Cualquier item o variante con campo `gif` muestra un icono `🎬`.
- **Hover 300ms** sobre ese elemento → aparece un floating preview
  (280x280 max, borde lavanda, fondo dark) con la imagen del GIF.
  Mouseout cierra. Debounced para no abrir múltiples al pasar rápido.
- **Importante**: el campo `gif` debe ser **URL DIRECTA** al archivo
  `.gif` o `.mp4` — NO la URL del page donde se ve el GIF. Para
  obtener URL directa: abrir el page, click derecho sobre el GIF,
  "Copiar dirección de imagen".
- Si la URL no carga (404, formato inválido, etc.), el popup muestra
  *"no se pudo cargar el preview · verificá que la URL sea directa
  al .gif/.mp4"* en rojo.

### 4. Ejemplo en el catálogo
- `bestudio_goals.example.json` agrega un nicho *"Aceite (ejemplo con
  variantes + GIF)"* con 5 variantes y 2 placeholders de GIF.
  La operadora reemplaza los placeholders con URLs reales y agrega
  los nichos que quiera con la misma estructura.

## 0.1.74 — 2026-06-01 — Silenciar warn "username NO detectado" en home/listings
- Reporte de la operadora: el panel "Errores" de `chrome://extensions`
  acumulaba el warning `[BeModels.chat] username NO detectado` cuando
  estaba en `chaturbate.com/` (home). Es esperado (no hay modelo en
  home), pero el `console.warn` quedaba registrado como issue.
- Cada `platformSelfTick` (cada 4s) emitía el warn → en pocos minutos
  el panel de errores se llenaba de ruido.
- **Fix**:
  - Nueva constante `NO_MODEL_PREFIXES` con paths conocidos que
    nunca tienen modelo: `/female-cams`, `/male-cams`, `/tag/`,
    `/feed/`, `/login`, `/signup`, `/search/`, `/messages/`,
    `/token-purchase/`, `/edit_account/`, `/affiliates/`, etc.
  - `isNoModelPage()` chequea pathname contra esos prefijos + home (`/`).
  - `detectUsername()` retorna null silencioso (sólo `console.debug`)
    cuando estamos en uno de esos paths. Sin warn.
  - El warn final (cuando estamos en una página CON potencial modelo
    pero ninguna estrategia funcionó) se baja a `console.debug` también
    — no es realmente un error, es info de diagnóstico.

## 0.1.73 — 2026-06-01 — Log de versión visible en content.js
- Pequeña UX: la operadora pidió verificar qué versión de BeModels
  está cargada en cada PC, pero `chrome.runtime.getManifest()` no es
  accesible desde la consola de la pestaña (page context). El log
  de `BM_BUILD` de `injected.js` solo aparece en Stripchat porque
  injected.js no se inyecta en otras plataformas.
- **Nuevo banner** al inicio de `content.js`:
  ```
  [BeModels] v0.1.73 cargado en chaturbate.com
  ```
  Fondo morado BE PRAGA + bold. Visible en cualquier plataforma sin
  importar el filtro de log. Permite verificar de un vistazo qué
  versión está activa en cada PC modelo.

## 0.1.72 — 2026-06-01 — Fix saludo pegado en Chaturbate
- Reporte de la operadora: en Chaturbate (miafarrog) la HUD muestra
  "Hola miafarrog, soy BeModels. Tu meta de hoy: 2000 tk · 0 / 2000"
  aunque la modelo ya tenía 586 tk del día según el API. La consola
  confirmaba `[BeModels.chat] range OK tokens=586`.
- **Causa**: el saludo se mostraba si `a.tot <= 0`. `a.tot` es la
  sesión actual (filtrado por `ts >= effStart()`). Como BeModels
  recién registró el inicio del show a las 18:49 (cuando el Telegram
  bridge confirmó el 🟢), las transacciones anteriores quedaban
  fuera de la sesión → `tot = 0` → saludo permanente.
- Patrón típico en plataformas distintas a Stripchat: la modelo
  lleva horas en vivo cuando BeModels detecta su 🟢. La definición
  "GANADO = solo sesión actual" tiene sentido, pero el saludo no
  debe bloquear si HOY hubo earnings de cualquier fuente.
- **Fix**: el `greet` ahora considera `totalHoy = Math.max(a.tot,
  a.dayTot, DAY.tokens)`. Si CUALQUIERA es > 0, salimos del saludo
  y mostramos la HUD normal. La línea "+ N tk antes del show = M tk
  hoy" ya estaba implementada — ahora la modelo la ve.

## 0.1.71 — 2026-06-01 — Cleanups post-test Chaturbate
- Tras confirmar que BeModels funciona en chaturbate.com (detectó
  username via `/b/`, vista 7 días con datos reales, earnings via
  API), quedaron 3 ruidos en la consola:
- **Logo del HUD bloqueado**: `Denying load of .../logo-conejo.png.
  Resources must be listed in the web_accessible_resources`. El PNG
  estaba listado solo para `stripchat.com`. Agregado `chaturbate.com`
  al matches de `web_accessible_resources` en manifest.json.
- **profileFetcher 404 en Chaturbate**: el fetcher consultaba
  `/api/front/users/me` (endpoint Stripchat) y devolvía 404 en
  Chaturbate. `ensureProfileTz()` ahora hace early-return cuando
  `PLATFORM.name !== 'stripchat'`. La TZ cae al `CFG.tz` default
  (`America/Bogota`) — sirve para casi todo el estudio.
- **Pendiente operadora**: `/api/goal-ideas` también bloqueado por
  Cloudflare Access desde chaturbate.com. Hay que agregar
  `/api/goal-ideas` al mismo bypass policy que tiene `/api/start` y
  `/api/summary` (CF Zero Trust → Access → la app "BeModels Bridge -
  Public Endpoints" → agregar 3er path).

## 0.1.70 — 2026-06-01 — Chaturbate /b/ (broadcaster) reconocido
- Console log de miafarrog mostró que el pathname era
  `/b/miafarrog/` (panel del broadcaster), no `/p/miafarrog/`.
  El parser v0.1.69 conocía `/p/`, `/chat/` y `/X/` pero NO `/b/`.
- **`detectUsername`**: lista de URL patterns explícita, ahora
  acepta:
  - `/p/USERNAME/` (perfil público)
  - `/b/USERNAME/` (broadcaster dashboard) ← nuevo
  - `/chat/USERNAME/` (vista de chat)
  - `/USERNAME/` (sala pública directa)
  Cada pattern loguea cuál matcheó (`✓ username via URL /b/X/...`).
- **`detectOwnShow`**: agregado `/b/USERNAME/` como variante de
  "está operando su propia sala/panel".

## 0.1.69 — 2026-06-01 — Fix detección username en Chaturbate
- Bug detectado en testing de la operadora con miafarrog en
  chaturbate.com: el adapter loggeaba "username NO detectado".
  Causa: el regex de URL pedía que el pathname terminara
  exactamente en `/p/X/` o `/X/` — si la página tenía algo más
  después (ej. `/p/X/messages/`, `/X/cam-settings/`), no matcheaba.
- **`platforms/chaturbate.js`**:
  - `detectUsername`: separación de helpers
    `isValidUsername(u)` con set de RESERVED_PATHS (login,
    signup, dashboard, settings, broadcast, etc. — paths comunes
    que NO son usernames).
  - URL parser más permisivo: matchea `/p/X/<lo-que-sea>` o
    `/X/<lo-que-sea>` (no requiere final exacto). Dos regex:
    primero `/p/...` y después `/X/...` plano.
  - 5ta estrategia: `<title>` "MODELO - Chaturbate".
  - Selectores DOM ampliados: `#user_information a`,
    `.messageMenu a`, `a[href*="/edit_account/"]`.
  - Logs cambiados a `console.log` (visibles sin habilitar
    Verbose en DevTools) con prefijo ✓ cuando una estrategia
    funciona.
- **`content.js / platformSelfTick`**:
  - Si `PLATFORM.detectSelf` devuelve null AND `CFG.manualModel`
    está seteado (popup), usa el manualModel como fallback con
    `source='manual'` y `ownShow=true`.
  - Logs cambiados a `console.log` para visibilidad.
- Workflow para la operadora cuando la detección automática falla:
  abrir el popup de BeModels → escribir el username en
  "¿No aparece la barra? Actívala con tu usuario" → Activar.
  En el próximo tick (≤4s) BeModels usa ese username.

## 0.1.68 — 2026-05-31 — Adapter Chaturbate (Paso 2 de N)
- Datos pasados por la operadora 2026-05-31:
  - Endpoint earnings: `GET /api/ts/tipping/token-stats/?max_transaction_id=&cashpage=0`
  - Selector balance: `#header-token-wrapper` (suele estar en 0
    porque la modelo retira auto a su cuenta).
  - Detección de modelo: el bot de Telegram detecta el 🟢 igual
    que Stripchat (pendiente: actualizar regex del launcher para
    capturar Chaturbate además de Stripchat → bridge 0.7.4).
- **NUEVO** `bemodels/platforms/chaturbate.js`:
  - `hostMatches`: `chaturbate.com`
  - `detectSelf`: cascada de estrategias para encontrar el username
    de la cuenta logueada — cookie `username`, globals JS comunes
    (`UTL_USERNAME`, `cb_username`, etc.), anchors del header
    (`<a href="/p/X/">`), URL fallback. Todas logueadas.
  - `fetchEarningsRange`: paginado por `max_transaction_id`, parsea
    transacciones con varios shapes posibles (transactions/items/
    results), filtra por rango, dedup. Tope 30 páginas.
  - `tkToUsd`: $0.05/tk. `modelShare`: 0.50. Token: `tk`. USD.
  - `readBalanceDOM`: `#header-token-wrapper`.
  - `isPerMinute`: false (Chaturbate es tip+goal).
- **`manifest.json`**:
  - `host_permissions`: agrega `chaturbate.com/*`.
  - `content_scripts.matches`: agrega `chaturbate.com/*`.
  - `content_scripts.js`: agrega `platforms/chaturbate.js` después
    de `stripchat.js`.
- **`content.js`**:
  - `pollEarnings()` y `loadHistoric()` ahora usan
    `PLATFORM.fetchEarningsToday` / `fetchEarningsRange` cuando
    hay PLATFORM activo. Backward compat: si no, caen a `BMEarn`.
  - Stripchat sigue exigiendo `SELF_USER_ID` para pollear; otras
    plataformas (Chaturbate identifica por cookie) no.
  - Nuevo `platformSelfTick`: cada 4s prueba `PLATFORM.detectSelf()`
    en plataformas SIN injected.js (Chaturbate, futuros). Apenas
    encuentra username, lo asume como MODEL y arranca todo el flow
    (ensureProfileTz, loadHistoric, pollEarnings, pollTelegram).
  - `usd(tk)` ahora usa `PLATFORM.tkToUsd` y `PLATFORM.modelShare`
    para que el USD/COP cuadre por plataforma (Stripchat 55%,
    Chaturbate 50%, futuras según su share). Backward compat:
    fallback a `/20` + CFG.copShareFactor.
- **Pendiente para que funcione end-to-end en Chaturbate**:
  - **bridge 0.7.4 / launcher**: extender regex de "se conecto en X"
    para capturar Chaturbate. Sin esto, `/api/start?model=X`
    devuelve `startedAt:null` para modelos en Chaturbate y BeModels
    cae a heurísticas locales (primer evento que vio).

## 0.1.67 — 2026-05-31 — Scaffolding multi-plataforma (Paso 1 de N)
- Pedido de la usuaria: expandir BeModels a Chaturbate, Cam4,
  Streamate, XLoveCam además de Stripchat. Antes de tocar nada
  específico de cada plataforma, refactor de fundación.
- **Sistema de adapters por plataforma**:
  - **NUEVO** `bemodels/platforms/base.js`: registry global
    `window.BMPlatforms[]` y helper `window.BMPlatform.getActive()`
    que devuelve el adapter cuyo `hostMatches(location.hostname)`
    devuelve true.
  - **NUEVO** `bemodels/platforms/stripchat.js`: adapter que wrappea
    los módulos existentes (`BMEarn`, `BMProfile`). Stripchat sigue
    funcionando IGUAL — backward compat 100%.
  - **NUEVO** `bemodels/platforms/README.md`: doc completa de la
    interfaz + pasos para agregar una plataforma nueva (Chaturbate
    es el próximo).
- **Interfaz del adapter**:
  ```
  { name, hostMatches, detectSelf, fetchEarningsRange, tkToUsd,
    modelShare, tokenLabel, currencyLabel, isPerMinute, ... }
  ```
- `manifest.json`: agrega `platforms/base.js` y `platforms/stripchat.js`
  como content scripts (en ese orden, ANTES de telegramFetcher /
  profileFetcher / earningsFetcher / content.js).
- `content.js`: detecta `PLATFORM = window.BMPlatform.getActive()`
  al arrancar y loguea. **No cambia comportamiento** — sigue usando
  `BMEarn.fetchEarningsRange` directamente. La migración de
  llamadas al adapter será gradual en los próximos commits.
- **Próximos pasos** (commits separados):
  - v0.1.68 — Adapter Chaturbate (real, con API + DOM scraping).
  - Después — Cam4, Streamate (perMinute), XLoveCam (perMinute).
- **Tasas por plataforma** (snapshot 2026-05) documentadas en
  README. Cuando una plataforma actualice su share/tasa, tocar
  solo el adapter; content.js queda agnóstico.

## 0.1.66 — 2026-05-31 — Ideas de metas: catálogo del estudio + favoritos personales
- Implementación de la opción D (recomendada) del feedback: catálogo
  central editable por la operadora + favoritos personales por modelo.

### Server (bridge 0.7.3)
- Nueva variable de config `$GoalIdeasFile`
  (default `C:\BePraga\bestudio_goals.json`).
- Nuevo endpoint `GET /api/goal-ideas` (auth Bearer o LAN privada,
  mismo treatment que /api/start). Devuelve el JSON tal cual.
- Cache in-memory de 30s para no leer disco en cada request.
- Si el archivo no existe → default genérico embebido (con campo
  `source: 'default'` y nota explicativa).
- **NUEVO** `extension-bestudio/server/bestudio_goals.example.json`:
  template con 4 nichos + comentarios `_doc` que explican el formato.
  La operadora lo copia a `C:\BePraga\bestudio_goals.json` y edita
  con Notepad++. Cambios se ven en ≤30 min en todas las modelos.
- `config.example.ps1`: agrega `$GoalIdeasFile` documentado.

### Cliente (BeModels)
- `loadGoalsCatalog()` hace `GET <bridgeUrl>/api/goal-ideas`
  al evento SELF y cada 30 min. Cachea en
  `chrome.storage.local::bemodels_goals_cache` para que el popover
  abra al instante incluso si el bridge está caído.
- Fallback hardcoded mínimo si no hay catálogo ni caché.
- **Favoritos personales** por modelo:
  - Storage key: `bemodels_goal_favs:<modelo>`.
  - En el popover, bloque "⭐ Tus favoritos" arriba del catálogo.
  - Botón ☆ inline en cada item del catálogo → agrega a favoritos.
  - Botón × en cada favorito → quita.
  - Form inline al final (`tk` + `texto` + botón "+ agregar a favoritos")
    para agregar manualmente sin tener que estar en el catálogo.
- Footer del popover muestra `Catálogo: <version>` para que la modelo
  sepa qué versión está mirando (útil para troubleshooting cuando
  la operadora dice "ya lo edité").

### CSS
- `.bm-ideas-grp-favs` fondo lavanda sutil para distinguir favoritos
  del catálogo.
- `.bm-ideas-star` (gris → dorado on hover) y `.bm-ideas-rm`
  (gris → rojo on hover) inline en cada item.
- `.bm-ideas-add` grid 70px / 1fr con borde dashed superior.

### Migración para la operadora
1. En el server: `copy extension-bestudio/server/bestudio_goals.example.json C:\BePraga\bestudio_goals.json`.
2. Editar con Notepad++ (UTF-8 sin BOM).
3. Restartear bridge para cargar 0.7.3.

## 0.1.65 — 2026-05-31 — Botones de acción en SUGERENCIAS
- Pedido: aprovechar el espacio vacío del segmento SUGERENCIAS
  para botones rápidos a features futuras:
  - *"sugerencias de metas y tengamos nosotros una cantidad de
    metas almacenadas por nicho"*.
  - *"otro botón que tenga que ver con conectar con el traductor
    BeTranslate para que la modelo active el traductor desde ahí"*.

### 💡 Ideas de metas
- Constante `GOAL_IDEAS` con 4 nichos hardcoded (Calientes / suave,
  Toys / lovense, Hardcore, Pareja) y ~5 goals cada uno. Ej:
  `99 tk · Lush 10 sec wave`, `444 tk · Toy DP · 1 min`, etc.
- Click en el botón **💡 Ideas** del HUD abre un popover flotante
  centrado (gradient hero BE PRAGA en el head). Click sobre cualquier
  item → copia el texto completo (`99 tk · Lush 10 sec wave`) al
  clipboard con feedback visual (badge verde "✓ copiado").
- ESC o `✕` cierra. Footer aclara que Stripchat no permite setear
  el goal vía API → la modelo pega el texto en su editor de goal.
- A futuro: catálogo editable desde el panel + sync vía bridge
  para compartir entre modelos del estudio.

### 🌐 Activar BeTranslate
- Click → `window.postMessage({ source: 'BEMODELS_CMD',
  kind: 'TOGGLE_TRANSLATE' }, '*')`. Contrato esperado:
  BeTranslate escucha este mensaje, alterna su barra y responde
  con `{ source: 'BETRANSLATE', kind: 'TOGGLE_ACK', on: bool }`.
- Si el ACK no llega en 1.5s → toast con hint
  *"BeTranslate no respondió — ¿está instalado?"* (clase `whale`,
  rojo). Si llega → toast verde *"BeTranslate ACTIVO/desactivado"*.
- BeTranslate todavía no implementa el listener; cuando lo haga,
  la integración funciona sin tocar BeModels.

### CSS
- `.bm-sug-tools` flex con gap 6px, wrap. `.bm-sug-btn` con borde
  lavanda, bg morado translúcido, hover invierte intensidad.
- `.bm-ideas-pop` overlay centrado fijo. Layout vertical:
  header gradient → body scrolleable con grupos → footer info.
  `.bm-ideas-item` con feedback de "copiado".

## 0.1.64 — 2026-05-31 — Modo flotante (botón draggeable con logo)
- Pedido textual de la usuaria: *"que funcione fija y hacerla flotante
  de forma que quede como el logo por ahí y la modelo la consulte,
  incluso puede quedar flotando solo el tiempo y lo que lleva hecho
  nada más al lado del logo"*. Solución: nueva opción `'floating'`
  como 5ta posición de la barra.
- **Nuevas CFG**:
  - `barPos` ahora acepta `floating` además de top/bottom/left/right.
  - `floatX` / `floatY` — posición persistida del pill (px desde top-left).
  - `floatExpanded` — si arranca expandido o colapsado (default colapsado).
- **HUD flotante**:
  - Default colapsado: pill chiquito con **logo del conejito BE PRAGA**
    + texto `Xh Ym · N tk` (resumen del show actual).
  - **Click sobre el brand** → toggle expandido/colapsado. Expandido
    muestra TODAS las franjas (GANADO, COMPARATIVA, EN VIVO, RITMO,
    SUGERENCIAS) apiladas en una tarjeta vertical de 320px ancho.
  - **Drag**: mousedown + movimiento > 4px en el brand → mueve el
    pill. Posición persistida al soltar (CFG.floatX/floatY).
  - **ESC**: colapsa el flotante si estaba expandido.
  - Border-radius pill cuando colapsado, card cuando expandido.
- **Logo conejito** vuelve al HUD pero SOLO en modo flotante. En
  posiciones fijas (top/bottom/left/right) sigue oculto (la barra
  fija ya tiene el accent ::before morado como identidad). CSS
  `.bm-brand-logo { display: none }` por default, override en
  `bm-pos-floating .bm-brand-logo`.
- **Body padding**: `updateBodyPad()` solo aplica en `bm-pos-top`,
  el flotante no empuja la página (es overlay puro).
- Panel: opción `🐰 Flotante (botón draggeable)` agregada al primer
  lugar del select "Posición de la barra".

## 0.1.63 — 2026-05-31 — USD↔COP, meta% en GANADO, COMPARATIVA más corta, sugs cortas, HUD compacto
- Feedback múltiple de la usuaria (testers le pasaron sugerencias):

### Toggle USD ↔ Pesos (COP)
- Fórmula oficial: `COP = USD × 0.55 × tasa` (calculadora
  bepraga.com/webcam). 0.55 es el share que recibe la modelo, 0.45
  se queda Stripchat. Tasa default: 3449.
- Nuevas CFG: `currency` (`'USD'`/`'COP'`), `copShareFactor` (0.55),
  `copRate` (3449, editable en panel/Avanzado).
- `usd(tk)` ahora devuelve el monto formateado en la moneda activa
  (USD con 2 decimales, COP con separador de miles, sin centavos).
- Nuevo helper `curSym()` que devuelve el sufijo "USD" o "COP".
- **Toggle**: click en cualquier `.bm-usd` del HUD alterna la moneda
  y persiste en storage. Cursor pointer + hover opacity para UX.
- Panel: nuevo campo "Tasa COP/USD" en Avanzado + nota a la calculadora.

### Meta % en GANADO
- Pedido textual: *"agregar el porcentaje de su meta personal como
  estaba anteriormente"*. Pill chiquito al lado del big "N tk":
  `3323 tk · 26%` con color según pct (ok/mid/low).
- Nueva regla CSS `.bm-meta-pct`.

### COMPARATIVA simplificada
- Pedido: *"se puede dejar solamente el tiempo y los tokens de ayer
  sin mencionar el mismo horario"*. Antes: `ayer mismo horario: 1857
  tk ↓ -64%`. Ahora: `ayer 6h 30m · 1857 tk ↓ -7%` (total + duración
  aproximada del show de ayer, sin perder la tendencia).
- Duración de ayer = span entre primer y último tip del día (proxy
  útil, no exacto del broadcast time).
- "prom 7d mismo horario" → "prom 7d" (también total del día).
- Meta % ya no se duplica acá (vive solo en GANADO ahora).

### Sugerencias acortadas
- Pedido: la sugerencia "Goal estancado (12%). Quiza esta muy alto:
  baja la meta." era muy larga. Todas las sugerencias ahora ≤40 chars:
  - `Faltan X tk · ETA Yh`
  - `Ritmo frío · activá goal corto`
  - `Ritmo bajo · ¿bajar la meta?`
  - `Goal frío X% · ¿muy alto?`
  - `Pico 18-23h · seguí`

### HUD más compacto
- Pedido: la barra tapa mucho del UI de Stripchat (token counter
  arriba, chat input abajo). Reducción de altura ~20%:
  - `min-height`: 52 → 42 px
  - `padding`: 4 → 2 px vertical
  - `bm-big` font-size: 18 → 16 px
  - `bm-seg` padding vertical: 4 → 2 px
- **Pendiente**: modo flotante (botón draggeable) — commit aparte.

## 0.1.62 — 2026-05-31 — Líneas COMPARATIVA enteras coloreadas
- Pedido textual: *"me gustaría que las líneas que se manejan sean
  verde si está subiendo en números comparativos vs ayer y rojo si
  está bajando"*. Antes solo la flecha + porcentaje estaban
  coloreados (`↓ -64%` en rojo) — el resto del texto quedaba en
  lavanda neutral, lo que diluía el indicador.
- **`content.js`**: nuevo helper `lineCls(d)` que devuelve `bm-ok`
  (≥+5%), `bm-mid` (entre -5% y +5%) o `bm-low` (≤-5%). Se aplica
  como CLASE al `<small>` entero de cada línea (ayer / prom 7d).
  `deltaTag()` simplificado: el `<b>` interno ya no tiene clase
  propia → hereda el color del padre.
- **`hud.css`**: overrides `.bm-seg small.bm-{ok,mid,low}` para
  ganar specificity contra `.bm-seg small` (que tiene tag selector
  y por eso ganaba antes). El color del estado ahora se aplica a
  toda la línea — número + texto + flecha + %.
- Resultado: de un vistazo se ve si la sesión va arriba o abajo
  vs ayer / promedio 7d, sin tener que leer el porcentaje.

## 0.1.61 — 2026-05-31 — Vista 7 días desde la API REAL de Stripchat
- **Bug de diseño detectado por la usuaria**: la vista "Últimos 7 días"
  leía del storage local del navegador (`bemodels_day:<modelo>:<fecha>`),
  pero las modelos *"casi siempre trabajan en diferentes cuartos /
  ventanas / perfiles Chrome"* → cada perfil tiene su propio storage
  → BeModels veía días vacíos aunque la modelo SÍ hubiera trabajado.
  La usuaria comentó: *"pensé que lo sacabas de su historial de
  ganancias"* — y tenía razón, esa es la fuente confiable.
- **Refactor `earningsFetcher.js`**: `fetchEarningsToday()` ahora
  delega a una función genérica `fetchEarningsRange(userId, fromIso,
  untilIso)`. Misma paginación + dedupe + shape de respuesta. Expuesta
  en `window.BMEarn.fetchEarningsRange` para reuso.
- **Reescritura `loadHistoric()`** en `content.js`:
  - UNA llamada a `fetchEarningsRange(SELF_USER_ID, hace_7_días, ahora)`.
  - Agrupa cada transacción por su **fecha local** (usa `effectiveTz()`
    para que el bucket cuadre con el corte de día que usa Stripchat).
  - Reconstruye `hours{}` por día también desde los `ts` reales,
    para que el `cumulativeByHour` del COMPARATIVA siga funcionando.
  - Cap 30 páginas (3000 tx) — suficiente para 7 días de la mayoría
    de modelos. Si se trunca, marca `_historic.truncated`.
  - Refresh cada 30 min (los días previos son casi inmutables).
- **`buildWeekView()` simplificado**: con la API, `last7` siempre
  devuelve 7 días (los huecos vienen en 0). Removida la rama
  *"sin días anteriores aún"* — era artefacto del enfoque storage.
  HOY usa el total del API (`_earn.tokens`) en vez del WS si está,
  para que la fila HOY también cuadre con el dashboard de Stripchat.
- **Beneficios**:
  - Funciona desde el primer minuto, sin acumular historia local.
  - Cualquier PC / cualquier perfil → ve los mismos 7 días reales.
  - El COMPARATIVA del HUD (hoy vs ayer / 7d) ahora compara contra
    datos REALES de Stripchat, no contra registros parciales.
  - Datos cuadran con el dashboard de Stripchat (mismo endpoint).

## 0.1.60 — 2026-05-31 — Mejor mensaje vacío en vista "Últimos 7 días"
- Observación de la usuaria: la vista "Últimos 7 días" mostraba
  *"Cargando histórico…"* indefinidamente cuando en realidad ya
  había cargado y la lista estaba vacía (caso típico: primera vez
  que usa BeModels, sin días anteriores guardados en storage).
- `buildWeekView()` ahora distingue 3 estados:
  - `_historic === null` → *"Cargando histórico…"* (correcto, load
    en curso, dura <1 segundo).
  - `_historic.last7.length === 0` → mensaje explicativo:
    *"Sin días anteriores aún. Esta vista se va a poblar a medida
    que uses BeModels en próximos shows — un día por turno guardado."*
    + muestra la fila HOY con los tokens parciales actuales.
  - Con datos → mini-barras normales (sin cambio).

## 0.1.59 — 2026-05-31 — Conejito como icono de la extensión + cleanup HUD
- Pedido textual de la usuaria: *"el logo se puede colocar como
  icono pero al lado de bemodels se quita y que ese sea el icono
  de la extension"*. También: *"lo que quisiera quitar es como el
  degradado de color o la barra me dice que sin datos para mostrar
  la extensión en la comparativa"*.
- **Conejito como icono de la extensión**:
  - Script Python autocropea el bbox real del contenido del PNG
    (los 4500×4500 del original tenían fondo blanco, no transparente
    — `getbbox()` por alpha fallaba; se detectó por non-white +
    alpha > 5).
  - Genera `icon16.png`, `icon48.png`, `icon128.png` cuadrados con
    LANCZOS resize + padding sutil → reemplazan los icons existentes
    que ya estaban referenciados en `manifest.json`.
- **Logo removido del HUD brand**:
  - `ensureBar()`: el `<div class="bm-brand">` ya no monta el `<img>`.
  - CSS: `.bm-brand-logo` y los estilos asociados removidos (queda
    comentario por si se quiere reincorporar más adelante).
  - El conejito ahora vive SOLO como toolbar icon (popup del ícono).
- **Barra dual de COMPARATIVA removida**:
  - La franja COMPARATIVA mostraba una barra dual (progreso meta +
    ghost rayado de proyección). La usuaria reportó que parecía
    decir "sin datos para mostrar" — confundía con la sección
    comparativa (que sí dice "sin datos de ayer" mientras se acumula
    histórico).
  - La meta % sigue inline en texto (`meta del día: X / Y tk · Z%`).
  - La proyección sigue como texto (`proyección turno: ~N tk (M%)`).
  - CSS de `.bm-pbar-dual` / `.bm-pbar-ghost` también removido.
- `web_accessible_resources` se mantiene (el PNG sigue disponible
  por si se reincorpora al HUD). El logo grande `bemodels/logo-conejo.png`
  queda en su lugar para edits futuros.

## 0.1.58 — 2026-05-30 — Logo conejito BE PRAGA + fix "línea morada"
- **Logo**: la usuaria subió `EDITABLE LOGO BE PRAGA CONEJO-06.png`
  (silueta lavanda del conejito con luna creciente). Lo movemos a
  `bemodels/logo-conejo.png` (sin espacios, evita problemas de URL).
- **`manifest.json`**: declaramos `web_accessible_resources` con el
  PNG y matches `stripchat.com/*` para que el content script lo pueda
  cargar via `chrome.runtime.getURL` desde el origen HTTPS de Stripchat.
- **`content.js / ensureBar()`**: cambia la estructura del brand a
  `<div class="bm-brand"><img class="bm-brand-logo"><span class="bm-brand-txt">…</span></div>`.
  El `<img>` se monta UNA sola vez con `chrome.runtime.getURL`.
  El render() ya no pisa el HTML completo del brand — solo actualiza
  el `.bm-brand-txt` (sino se perdía el logo en cada re-render).
- **CSS**: `.bm-brand-logo { height: 30px; filter: drop-shadow(0 1px 2px rgba(0,0,0,.4)); }`
  para que se lea claro sobre cualquier color de fondo (incluido
  cuando se elige rojo Stripchat u otro custom). `gap: 8px` en el
  flex del brand para separar logo + texto.
- **Fix "línea morada"** (observación de la usuaria con custom red
  bg): el borde del HUD usaba `var(--bm-secundario)` (lavanda fijo),
  lo cual creaba una línea fuera de paleta cuando se cambiaba el
  bg a otro color.
  - **NUEVA `--bm-hud-border`** variable CSS, default `#DF84F9`.
  - Todos los `border-top/bottom/right/left` del HUD (inc. variantes
    de posición top/left/right) ahora usan esa var en vez de
    `--bm-secundario` directo.
  - **`applyHudColor()`**: cuando hay `hudBgColor`, calcula una
    versión 30% más oscura del color elegido y la usa como
    `--bm-hud-border` → el borde queda en la familia del color custom,
    armoniza visualmente. Cuando se resetea al default, también se
    `removeProperty('--bm-hud-border')` para que vuelva a lavanda.
- El brand color (`color: var(--bm-secundario)`) sigue en lavanda
  fijo → la identidad BE PRAGA del texto "BeModels" se mantiene
  aunque cambies el fondo.

## 0.1.57 — 2026-05-30 — COMPARATIVA reemplaza META DIA + vista 7 días
- Observación de la usuaria: la franja META DIA en el HUD se sentía
  redundante con el goal interactivo que Stripchat muestra abajo
  (aunque conceptualmente son distintos: meta diaria personal vs.
  goal transaccional del show). Pidió comparativa día/semana.
- **Histórico**: nueva infra `loadHistoric()` + `_historic` que lee
  los `bemodels_day:<modelo>:YYYY-MM-DD` de los últimos 14 días al
  evento SELF y refresca cada 30 min. Calcula `yesterday`, `last7`,
  `week7Avg`, `best7`.
- **`cumulativeByHour(day, currentHour)`** suma `hours[h]` para
  `h ≤ currentHour` → comparación "mismo horario del día" sin
  importar a qué hora arrancó cada show.
- **HUD `#bm-meta` → COMPARATIVA** (estilo A):
  ```
  COMPARATIVA
  1h 5m · 456 tk
  ayer mismo horario: 1230 tk · ↓ -63%
  prom 7d mismo horario: 890 tk · ↓ -49%
  proyección turno: ~3120 tk (156%)
  meta del día: 456 / 2000 tk · 23%
  ```
  Color de la tendencia (`↑↓`): verde si +5%, ámbar si entre -5..+5%,
  rojo si <-5%. Si no hay datos históricos aún (instalación nueva),
  muestra "sin datos de ayer".
- La meta % se mantiene como info chica inline (para no perderla;
  sigue alimentando las sugerencias y la barra dual ghost de la
  proyección).
- **Panel: vista 7 días** (estilo C) — bloque nuevo arriba del
  Diagnóstico de sesión. Mini-barras horizontales con:
  - Día actual destacado con fondo lavanda y etiqueta "HOY".
  - Mejor día de la semana marcado con "★ mejor" (dorado suave).
  - Promedio 7d en el header del bloque.
  - Etiquetas día de la semana en minúsculas (lun, mar, …).
- CSS: variantes `.bm-cmp-big` (BIG más chico para que entre tiempo
  + tk en una línea), `.bmp-w-*` (grid de la vista 7d).

## 0.1.56 — 2026-05-30 — Panel reorganizado: esenciales vs avanzado
- Tras confirmar que el bridge funciona end-to-end, varios campos del
  panel ya no se tocan en el día a día (bridge URL preconfigurado, TZ
  con autodetect, inicio manual solo si Telegram falla, etc.). Llenan
  el panel sin aportar valor visual.
- **Esenciales** (siempre visibles, en orden de uso real):
  - Meta de tokens del día
  - Duración objetivo del turno (horas)
  - Posición de la barra
  - Color del fondo de la barra
  - Enviar resumen al canal Telegram al cerrar el show
- **Sección "Avanzado"** (colapsable, cerrada por default usando
  `<details>`/`<summary>` nativo):
  - Inicio de turno manual (HH:MM) — fallback si Telegram no detecta.
  - Bridge BeStudio URL — preconfigurado al tunnel.
  - Zona horaria override — autodetect del perfil Stripchat.
  - Mostrar barra HUD (desactivar = ocultar entera).
  - Modo demo.
- **CSS**: nueva regla `.bmp-adv` con marker custom `▸` que rota 90°
  al expandir, fondo lavanda sutil, hover, etc. Look consistente con
  el resto del panel.
- Inputs ocultos de whale (no en UI desde v0.1.47) se mueven antes
  del `<details>` para que `savePanel` los siga leyendo.

## 0.1.55 — 2026-05-30 — Color picker del fondo del HUD
- Pedido de la usuaria, inspirado en la extensión BeTranslate
  (color picker para "Color de traducción" / "Fondo de traducción"):
  poder pintar la barra HUD del color que cada modelo prefiera, p.ej.
  el rojo de Stripchat para que armonice con la página.
- **`DEFAULT_CFG.hudBgColor`** (default `''` = gradiente morado BE PRAGA).
- **`darkenHex(hex, factor)`**: helper que oscurece un color HEX
  para generar el segundo stop del gradiente (mantiene la sensación
  de profundidad del default).
- **`applyHudColor(el)`**: si hay color custom, hace
  `el.style.setProperty('--bm-hud-bg-a', color)` + `-b` con el oscurecido;
  si no, hace `removeProperty` y herda el default del stylesheet.
- Se invoca desde `render()` en cada actualización para que el color
  se mantenga aunque el HUD se reconstruya.
- **Panel**: nueva fila *"Color del fondo de la barra"* con:
  - `<input type="color">` para color libre.
  - `<select>` con presets: Default morado · **Rojo Stripchat** ·
    Azul oscuro · Verde profundo · Morado oscuro · Casi negro.
  - Botón `↺` reset al default.
  - **Preview live**: al mover el picker o elegir un preset, el HUD
    se actualiza al instante (sin esperar al Guardar). El Guardar
    persiste lo que esté activo.
- **CSS**: nuevas reglas `.bmp-color-row` (layout flex del picker)
  y `.bmp-mini` (botoncito reset estilo outline morado).
- **Identidad BE PRAGA preservada**: el borde superior y el brand
  "BeModels" siguen en lavanda (`--bm-secundario`) aunque se cambie
  el fondo. Así no se pierde la identidad del estudio.

## 0.1.54 — 2026-05-30 — bridgeUrl default → Cloudflare Tunnel HTTPS
- **Bug crítico**: el default LAN `http://192.168.88.120:7878` (v0.1.48)
  nunca podía funcionar desde la PC de la modelo. Dos razones:
  1. **`ERR_CONNECTION_REFUSED`**: el bridge en el server escucha
     SOLO en `127.0.0.1` (memoria del proyecto: *"BridgeBind =
     '127.0.0.1' SIEMPRE porque 0.0.0.0/'+' requiere URL ACL"*).
     Desde otra PC en la LAN, el puerto 7878 del server rechaza
     conexión a nivel TCP — el bridge no está bindeado ahí.
  2. **Mixed-content**: Stripchat es HTTPS; un fetch a un URL HTTP
     dispara warnings/bloqueos de Chrome en non-loopback IPs.
  - Test desde la PC de la modelo confirmó ambos síntomas en la
    consola (ERR_CONNECTION_REFUSED + Mixed Content warnings).
- **Fix**: default cambia a `https://bestudio.bepraga.com` (Cloudflare
  Tunnel ya montado en el server, memoria: *"túnel UUID 3b4ee1ae-..."*).
  - HTTPS → no mixed-content desde Stripchat.
  - El tunnel forwardea a `localhost:7878` del server. El bridge ve
    `RemoteEndPoint.Address = 127.0.0.1` (loopback) → `Test-IsTrustedLAN`
    de bridge.ps1 v0.7.1 lo deja pasar SIN Bearer → BeModels funciona
    sin que la usuaria deba meter token alguno.
- **`manifest.json`**: agrega `https://bestudio.bepraga.com/*` a
  `host_permissions` para que el content script ISOLATED pueda
  hacer fetch al tunnel sin restricciones.
- **Migración automática** en `loadCfg()`: si una install pre-v0.1.54
  tiene `bridgeUrl` apuntando al LAN viejo
  (`http://192.168.88.120:7878`), lo reemplazamos por el default
  nuevo y lo persistimos en storage. Si la usuaria puso una URL
  custom DISTINTA al LAN viejo, la respetamos.
- **Tradeoff de seguridad aceptado**: con `Test-IsTrustedLAN` viendo
  loopback de las requests del tunnel, **`/api/start` y `/api/summary`
  son alcanzables desde internet sin auth** vía la URL pública.
  - `/api/start`: expone live status del modelo. Riesgo bajo.
  - `/api/summary`: spam del canal Telegram. Mitigado por dedupe
    `model|startedAt`.
  - El resto de endpoints sigue requiriendo Bearer estricto.
  - Si el riesgo aumenta, opciones futuras: (a) chequear headers
    `Cf-Ray`/`Cf-Connecting-Ip` y rechazar loopback tunneled, (b)
    token dedicado `$SummaryToken` bundleado en BeModels.

## 0.1.53 — 2026-05-30 — Popup limpio (solo diag + activar)
- Observación de la usuaria: el popup del ícono seguía duplicando
  TODOS los ajustes que ya viven en el panel in-page (meta, turno,
  bridge, TZ, etc.), incluyendo los whale fields que sacamos del
  panel. Resultado: dos formularios de configuración fuera de sync.
- Regla de la usuaria (memoria): *"usar paleta morada BE PRAGA +
  Poppins; **ajustes dentro de la página, no en el popup del icono**"*.
- **popup.html**: removidos todos los `<label>` de configuración
  (dailyGoalTk, whaleSingleTk, whaleCumTk, whaleBalanceTk,
  alertHidden, turnStart, shiftGoalH, bridgeUrl, bridgeAuthToken,
  tz, barEnabled, demo, botón Guardar). Queda **solo**:
  - Header con branding.
  - Estado de detección (read-only).
  - Diagnóstico (build + saldo).
  - Activación manual con `manualModel` (fallback útil).
  - **NUEVO** botón outline *"⚙ Ajustes en la página"* + hint.
  - Resumen del día (read-only).
- **popup.js**: refactor — `saveCfg(...)` reemplazado por
  `saveManualModel(...)` (único setting que sigue ahí). `load()`
  más simple. Nueva función `openInPagePanel()` que hace
  `chrome.tabs.sendMessage(tabId, { type:'BEMODELS_OPEN_PANEL' })`
  y cierra el popup.
- **popup.css**: limpieza paralela. Removidos selectores no usados,
  agregados `.bm-open-panel` (outline) y `.bm-open-hint`. Refresh
  de variables CSS para alinear con paleta canonical.
- **content.js**: nuevo listener `chrome.runtime.onMessage` que
  responde a `BEMODELS_OPEN_PANEL` abriendo el panel via
  `buildPanel()` + `fillPanel()` + clase `.bm-open`. Idempotente —
  si ya está abierto, no hace nada.
- Net: la usuaria edita CFG en UN solo lugar (el panel in-page), y
  el popup queda como dashboard rápido + escotilla de activación.

## 0.1.52 — 2026-05-30 — Diagnóstico de sesión + roster centralizado + proyección
- Tres mejoras pedidas tras estabilizar el feature de resumen Telegram:

### (1) Diagnóstico de sesión en el panel
- Pedido: *"necesito probar el inicio de la sesion"* — verificar
  qué está alimentando el contador del show sin esperar a producción.
- `effStartSource()` extendido: ahora distingue `manual | tg | sesion |
  streamStart | apiStreamStart | firstTs | frozen` (antes solo
  `manual/tg/sesion/local`).
- `_tgLastPollAt` + `_tgLastPollRes` registran cada poll al bridge
  (live / offline / error + cuándo).
- Panel: nueva sección **"Diagnóstico de sesión"** que muestra:
  - Inicio del show resuelto + duración acumulada.
  - Fuente activa con etiqueta legible (📡 Telegram · ✍ Manual · etc.).
  - Estado del bridge Telegram + edad del último poll.
  - Si el show cerró: hora de cierre + hace cuánto.

### (2) Roster centralizado
- Memoria: *"BM_AUTORIZADAS duplicada en 3 sitios; sincronizar a mano"*.
- **NUEVO** `bemodels/roster.js`: lista canónica única, expone
  `window.BM_AUTORIZADAS_SET`.
- `content.js` y `popup.js` ahora leen de ahí (en vez de hardcodear).
- `manifest.json`: `roster.js` registrado como content script ANTES
  que `content.js` para que esté disponible cuando carga.
- `popup.html`: `<script src="bemodels/roster.js">` ANTES de
  `popup.js`.
- BeStudio sigue con su `MODELOS_AUTORIZADAS_BG` paralelo (otra
  extensión, no comparte JS) — sincronizar a mano cuando entra una
  modelo. Reducción de 3→2 lugares por ahora. Eventualmente: endpoint
  `GET /api/roster` en el bridge.

### (3) Proyección al final del turno
- `analytics()` retorna `projHoursLeft`, `projAddTk`, `projEndTk`,
  `projEndPct` calculados como `tot + ritmoHora * (shiftH - horas)`.
- HUD `#bm-meta`: línea adicional *"proyección turno: ~N tk (X%) +
  N tk en Xh"* con color según `projEndPct` (ok/mid/low).
- **Barra dual**: pinta el ghost de proyección (gradient diagonal
  lavanda) detrás del progreso real, así ves a un vistazo cuánto
  queda por avanzar a ritmo actual.
- Si el show ya cerró o no hay ritmo, se omite la proyección.

## 0.1.51 — 2026-05-30 — Summary enriquecido + retry persistente
- **Summary más rico**: el payload de `POST /api/summary` ahora incluye
  `tipsCount`, `topTipper` y `topTipperTk` calculados de la SESIÓN
  (no del día), filtrando `_earn.tx` por `ts >= _frozenStart` y
  `ts <= _tgClosedAt`. El bridge (≥0.7.2) los renderiza como una
  línea extra del mensaje: `💬 Tips: N · top: <user> (X tk)`.
- **Retry persistente**: antes de hacer el POST, BeModels guarda el
  payload completo en `chrome.storage.local` como
  `bemodels_pending_summary` (`{ payload, base, bridgeAuthToken, ts }`)
  y solo lo borra al recibir confirmación del server
  (`sent=true` o `skipped='dup'`). Si el bridge estaba caído o hubo
  un fallo de red al momento del cierre, el próximo arranque de
  BeModels detecta el pending y reintenta:
  - Disparador: `retryPendingSummary()` llamado desde el handler de
    `SELF` apenas tenemos `MODEL`.
  - TTL: 24h (más viejo → se descarta).
  - Idempotente del lado del server por el dedupe `model|startedAt`.
- `sendShowSummary()` se refactoró en dos funciones:
  - `sendShowSummary()` arma payload + persiste + invoca attempt.
  - `postSummaryAttempt(pending)` hace el POST efectivo y devuelve
    `true` solo si el server confirmó. Reutilizada por el retry.

## 0.1.50 — 2026-05-28 — Roster +2 (karriewatson, sofiadollbe)
- **Changed:** `BM_AUTORIZADAS` en `bemodels/content.js` y `popup.js`
  sincronizada con el roster de BeStudio v0.9.4:
  - `karriewatson` (turno Mañana en el lado server)
  - `sofiadollbe`  (Siempre)
- Sin cambios funcionales — solo extiende el candado para que el HUD
  aparezca cuando un coach con BeModels mira la sala de estas 2.

## 0.1.49 — 2026-05-25 — Bearer token auth + endpoints REST del bridge expuestos
- **Soporte de auth** para el bridge BeStudio (requerido si se expone vía
  Cloudflare Tunnel a internet). Campo nuevo en popup: "Bridge — Bearer
  token (opcional)". Se guarda en `bemodels_cfg.bridgeAuthToken`.
- **telegramFetcher.js extendido** con 4 funciones nuevas que consumen
  los endpoints REST del bridge (v0.3.0):
  - `listModels(bridgeUrl, token)` → `/api/models`
  - `listFiles(modelo, bridgeUrl, token)` → `/api/files/<m>`
  - `getFile(modelo, fecha, bridgeUrl, token)` → `/api/file/<m>/<fecha>`
  - `getToday(modelo, bridgeUrl, token)` → `/api/today/<m>`
  Todas mandan `Authorization: Bearer <token>` si está configurado. Si
  el bridge responde 401, log warning y retornan error gracefully.
- **`getStart()` y `sendShowSummary()`** ahora también incluyen el header
  de auth si `bridgeAuthToken` está seteado (sin breaking change: si
  no hay token, sigue funcionando como antes).
- Sin cambios en HUD. La integración para mostrar datos remotos del
  server (ej. histórico de tips desde JSONs) queda para v0.1.50.

## 0.1.48 — 2026-05-24 — Bridge URL hardcoded (no hay que llenar el campo)
- Pedido de la usuaria: *"¿es necesario que se deba incluir el bridge?
  ¿No se puede incluir internamente de forma que no debamos llenar ese
  dato?"*. Como las PC de las modelos están **siempre** en la LAN del
  estudio (misma red que el server), no hay razón para hacer que la
  usuaria copie/pegue la URL en cada instalación.
- `DEFAULT_CFG.bridgeUrl` cambia de `''` a `'http://192.168.88.120:7878'`
  (IP estable del server BeStudio en la LAN del estudio).
- `loadCfg()`: rehidratación — si una install pre-v0.1.48 había
  guardado `bridgeUrl=''`, el `''` ganaba sobre el nuevo default por
  `Object.assign`. Si lo detecta vacío al cargar, lo resetea al default.
- Panel: label del campo cambia a *"Bridge BeStudio (preconfigurado ·
  solo cambiar si el server se movió)"*. Sigue editable como override
  por si el server cambia de IP o se monta un túnel.
- Decidido vs auto-discovery: la usuaria pidió hardcode una sola URL
  para minimizar requests al arrancar. Si en el futuro se necesita
  soporte multi-red (modelos desde casa), se puede agregar fallback.

## 0.1.47 — 2026-05-24 — Save sticky + alertas ballena off + branding HUD
- Tres feedback de la usuaria sobre la UX del panel y el HUD:
- **(1) Save oculto al hacer scroll**: el botón Guardar quedaba al
  final del cuerpo y con varios campos se iba abajo del viewport.
  - `content.js`: envuelve el cuerpo en `<div class="bmp-scroll">` y
    saca el Save a `<div class="bmp-actions">` (después del scroll).
  - `hud.css`: panel pasa a `display: flex; flex-direction: column`.
    `.bmp-scroll` toma `flex: 1; overflow-y: auto`; `.bmp-actions` es
    `flex: 0 0 auto` con borde superior y sombra → siempre visible
    aunque el scroll esté abajo. Scrollbar fina con tinte lavanda
    (WebKit + Firefox).
- **(2) Alertas ballena ocultas hasta tener herramienta real**:
  - Nueva CFG `whaleAlertsEnabled` (default `false`).
  - `checkWhale()` y `scanUserCards()` son no-op cuando la flag está
    apagada → ni notificación ni flash en HUD ni scrapeo de tarjetas.
  - Los campos `whaleSingleTk` / `whaleCumTk` del panel pasan a
    `<input type="hidden">` (preservados en el DOM para que savePanel
    no rompa, invisibles al usuario).
  - `DAY.byUser` se sigue acumulando para que el día tenga el dato
    listo cuando exista una vista real de ballenas.
- **(3) Branding HUD reforzado**:
  - `.bm-brand` (BeModels) ahora: 14px, tinte de fondo lavanda + barra
    izquierda con gradiente principal (`::before`). Más on-brand sin
    robarle atención a los segmentos.
  - Panel: labels en `#3A0668` (variante oscura del principal) con
    `letter-spacing: .2px` para diferenciar visualmente del cuerpo.

## 0.1.46 — 2026-05-24 — Resumen de cierre al canal Telegram
- Pedido de la usuaria: *"cuando se cierre sesión, ¿hay forma de que
  la extensión envíe la información a algún canal de Telegram? Un
  resumen de la jornada — cantidad de tokens, tiempo total en vivo,
  ritmo"*.
- Decisión de arquitectura: el bot token NO viaja al navegador (la
  extensión es inspectable). El envío se hace **server-side** vía el
  bridge, reutilizando el `$TelegramToken` + `$TelegramChatId` que ya
  configura el launcher en `config.ps1`. Mismo canal que recibe los
  🟢/🔴 (BE PRAGA Studio) para tenerlo todo agrupado.
- **`extension-bestudio/server/bridge.ps1`**:
  - Nuevo endpoint `POST /api/summary` (Content-Type: application/json).
  - Body: `{ model, tokens, usd, durationMin, ritmoTkH, goalTk, goalPct,
    startedAt, closedAt }`.
  - Dedupe in-memory por `model|startedAt` para evitar reenvíos si la
    modelo recarga la pestaña post-cierre (TTL 24h).
  - `Send-Telegram` y `Build-SummaryText` reutilizan formato HTML del
    canal (`<b>resumen sesion</b> · modelo · 🕒 inicio→cierre · 🪙
    ganado · 📈 ritmo · 🎯 meta diaria si aplica`).
  - Si `TelegramToken` no está configurado, devuelve `500 telegram_off`
    sin romper el resto del bridge.
  - CORS de preflight ahora incluye `POST`.
- **`extension-bemodels/bemodels/content.js`**:
  - Nueva CFG `summaryToTelegram` (default `true`).
  - `handleShowClosed()` ahora dispara `sendShowSummary()` al cerrar.
  - `sendShowSummary()` arma el payload con tokens del último
    `analytics()` y duración congelada (`_tgClosedAt - _frozenStart`),
    hace `POST` al bridge. Errores silenciosos (un fallo de envío no
    debe romper la HUD).
  - Toggle en el panel: *"Enviar resumen al canal Telegram al cerrar
    el show"* (checkbox), guarda en `bemodels_cfg.summaryToTelegram`.
- No requiere bump del launcher.

## 0.1.45 — 2026-05-24 — Cierre 🔴 detectado + CSS con variables BE PRAGA
- Observación de la usuaria: *"ocurrió el cierre [del show] y sigue
  corriendo"*. La HUD no reaccionaba al 🔴 de Telegram.
- También: aplicar paleta BE PRAGA (variables CSS) y cargar Poppins.
- **Cierre del show**:
  - `telegramFetcher.js`: `getStart()` ahora devuelve un objeto
    `{ startedAt, isLive, error }` para distinguir "modelo offline"
    (200 con `startedAt:null` del bridge) de "fallo de red".
  - `content.js`:
    - Nuevo contador `_tgOffStreak`. Tras `TG_OFF_THRESHOLD=2` polls
      consecutivos con `isLive=false` sin error → `handleShowClosed`.
    - `handleShowClosed()` captura `_frozenStart = effStart()` ANTES
      de limpiar fuentes (sino GANADO/RITMO se irían a 0), setea
      `_tgClosedAt`, limpia `_tgStart` y la sesión persistida.
    - `effStart()` respeta `_frozenStart` cuando hay cierre activo
      → la sesión queda congelada en su último valor real.
    - Render `#bm-live` cambia a *"🔴 OFFLINE · duracion XhYm · show
      cerro HH:MM"* cuando `a.offline`. Se aplica `.bm-offline` al
      root del HUD: borde y brand viran a rojo, fondo a granate.
    - Nuevo 🟢 con `startedAt` distinto al congelado → descongela y
      arranca show nuevo.
- **CSS / paleta**:
  - `hud.css` refactor: variables CSS `--bm-principal`, `--bm-secundario`,
    `--bm-gray`, `--bm-gray-light`, `--bm-border`, `--bm-grad-hero`,
    `--bm-grad-btn`, etc. Todo el styling apunta a las vars → cambiar
    paleta = editar 1 bloque.
  - Pesos Poppins explícitos (300/400/500/600) en cada componente.
  - Estado offline tipado en una sola regla `.bm-offline`.
  - Focus en inputs del panel: además del border, halo
    `box-shadow: 0 0 0 3px rgba(84,9,169,.12)`.
- **Poppins en el host**:
  - `ensurePoppins()` en `content.js` inyecta el `<link>` de Google
    Fonts en el `<head>` la primera vez que se construye la barra.
    Antes solo el popup tenía Poppins; el HUD caía a system-ui.
- Bridge sin cambios. Asume que `bestudio-launcher.ps1` ya remueve
  la modelo de `$state.live` al recibir 🔴.

## 0.1.44 — 2026-05-24 — Paginación de tx[] + breakdown sesión/día
- Observación de la usuaria: *"4.643 es el monto manual y la extensión
  solo 2.331"*. Diagnóstico: `tx[]` venía con `limit=100&offset=0`
  fijo. En un día con muchas transacciones, la suma "session" (que
  filtra `tx[]` por `ts >= effStart()`) **dejaba afuera los tips de
  páginas posteriores** aunque `inTokens` (total agregado) sí reflejara
  el real.
- `earningsFetcher.js`:
  - Loop de paginación: incrementa `offset` en `PAGE=100` hasta que
    la página vuelve incompleta o `allRaw.length >= numberOfTransactions`.
  - Cap de seguridad `MAX_PAGES=30` (= 3000 tx). Si se alcanza, se
    marca `truncated:true` en el output.
  - Dedup por `(ts|user|tokens)` por si dos páginas se traslapan
    durante el polling.
  - Si la primera página falla, se aborta (igual que antes). Si una
    intermedia falla, devuelve parcial y marca `truncated`.
  - Log de consola incluye `tx=N (paginado en X pag)` para diagnosticar.
- `content.js / analytics()`: retorna además `dayTot`, `preShow`,
  `txInWin`, `txTotal`, `txCountApi`, `truncated` para visualización
  y debug.
- `content.js / render #bm-dia`: si `session < día`, agrega una línea
  pequeña adicional: *"+ N tk antes del show = M tk hoy"* para que se
  vea claramente la diferencia con el dashboard de Stripchat (que
  siempre muestra el total del día) y se entienda que la diferencia
  es ganancia legítima previa al show actual. Si la paginación quedó
  truncada, agrega `⚠ paginacion truncada`.

## 0.1.43 — 2026-05-24 — Auto-detect de la TZ del perfil de Stripchat
- Pregunta de la usuaria: *"¿qué zona horaria se está tomando para
  los tokens? Porque creo que la página maneja otra zona horaria"*.
- Hasta v0.1.42 BeModels hardcodeaba `America/Bogota` (configurable
  en el panel). Stripchat NO usa esa TZ: agrega los totales del día
  según la TZ del **perfil de la modelo** (`/my/settings`). Si no
  coinciden, el corte de medianoche está desfasado y los tokens del
  día no cuadran con el dashboard.
- **NUEVO** `bemodels/profileFetcher.js`: módulo content-script
  ISOLATED que detecta la TZ real del perfil. Estrategia en cascada:
  1. `__NEXT_DATA__` (búsqueda recursiva acotada por campos comunes:
     `timezone`/`timeZone`/`tz`/`userTimezone`/`profileTimezone`).
  2. `GET /api/front/users/me`.
  3. `GET /api/front/users/<id>` (con `SELF_USER_ID`).
  4. null → fallback a `CFG.tz`.
  Valida con `Intl.DateTimeFormat` que sea una IANA real.
- `content.js`:
  - Nueva variable `_detectedTz` y helper `effectiveTz()` que devuelve
    `_detectedTz || CFG.tz || 'America/Bogota'`.
  - Todas las llamadas a `Intl` (localDateStr/localHour/localMinute +
    los HH:MM del render) y la llamada a
    `BMEarn.fetchEarningsToday()` usan ahora `effectiveTz()`.
  - `ensureProfileTz()` se dispara al recibir el evento `SELF` (lo más
    temprano posible) y antes del primer `pollEarnings()`.
  - Panel de ajustes muestra un pie chico debajo del campo TZ:
    `✓ TZ del perfil coincide` o `⚠ perfil usa X — se está usando ESA`.
- `manifest.json`: agrega `bemodels/profileFetcher.js` antes de
  `earningsFetcher.js` para que `window.BMProfile` esté disponible
  cuando `pollEarnings` corra.
- Si la detección falla (endpoint no expone TZ o cambia de schema),
  el sistema cae al CFG.tz manual sin romperse. Logs en consola con
  prefijo `[BeModels.profile]` para diagnosticar.

## 0.1.42 — 2026-05-24 — RITMO también relativo al inicio del turno
- Pedido de la usuaria, complemento a v0.1.41: *"si se abre un turno
  sea desde ese monto en adelante para que el ritmo sea también real
  — si es otro turno de los modelos pues eso no se toma en cuenta de
  momento"*.
- `content.js / ratePerMin()`: la ventana de los últimos 20 min ahora
  se recorta al `effStart()` (inicio del turno = manual > Telegram 📡
  > sesión). Si abrieron el turno hace 5 min, el RPM solo considera
  los tips de esos 5 min, no de los 15 min previos.
- Además, `span` arranca desde el inicio efectivo de la ventana (no
  desde el primer tip dentro de ella) → si hubo un rato largo de
  silencio tras abrir el turno, el ritmo refleja ese silencio en vez
  de ignorarlo.
- `tkHora` (promedio largo) ya estaba alineado: `tot / horas`, ambos
  desde `effStart()`. Sin cambios ahí.
- Handoff entre modelos (un turno tomado por otra modelo después):
  fuera de scope por ahora — se evaluará más adelante.
- `injected.js`: solo `BM_BUILD`. `background.js` sin tocar.

## 0.1.41 — 2026-05-24 — GANADO ES la sesión del show (no el día)
- Pedido textual de la usuaria: *"la idea es que sea al reves: HOY
  GANADO sea la sesion actual desde el inicio, no me interesa en
  realidad"* (el total del día). El número grande ahora representa
  **lo ganado en el show actual**, y el total del día desaparece de
  la franja como concepto independiente.
- `content.js / analytics()`: la cadena de prioridad del campo `tot`
  pasa a `session → api → saldo → ws`. Cuando hay `tx[]` del API y
  un `effStart()` válido (típicamente del bridge Telegram 📡), `tot`
  se calcula sumando solo las transacciones con `ts >= effStart()`.
  Si todavía no hay `tx[]` cargados, se cae al total del día como
  antes para no quedar en cero.
- `content.js / render #bm-dia`:
  - Label `HOY GANADO` → `GANADO` (ya no es del día).
  - Se elimina la línea redundante *"desde inicio show: N tk"* (el
    BIG number ya **es** eso); en su lugar se muestra
    `show inicio HH:MM · ✓ desde inicio del show` cuando la fuente
    es `session`, o un indicador equivalente cuando se cae a
    fallback (`✓ total del dia (Stripchat)` / `delta de saldo` /
    `WS (aprox)`).
  - Se quita también la línea de `saldo NN tk` del wallet — la
    usuaria explícitamente no la quería ver.
- `analytics()` ya no retorna `showTok` (estaba causando una
  referencia indefinida latente al renombrarse el flujo). Resto del
  payload sin cambios.
- `injected.js`: solo `BM_BUILD`. `background.js` sin tocar.

## 0.1.40 — 2026-05-24 — "desde inicio show" en vez de "saldo wallet"
- Pedido de la usuaria: en HOY GANADO la línea pequeña debe mostrar
  el acumulado **desde que inició la transmisión**, no el saldo
  total del wallet (que confundía — son dos conceptos distintos).
- `earningsFetcher.js`: ahora devuelve también la lista `tx[]` de
  transacciones del día (timestamp + tokens + tipo + user) — antes
  solo devolvía la suma agregada.
- `content.js`:
  - Nueva variable `showTok`: filtra `_earn.tx` por `ts >=
    effStart()` y suma → "ganado desde inicio del show actual".
  - Solo se computa si la hora de inicio es claramente después de
    medianoche (evita mostrar lo mismo que HOY GANADO).
  - Render `#bm-dia` cambia la línea: `desde inicio show: N tk (≈
    $X)` reemplaza a `saldo NN tk` cuando hay show identificado.
    Si no hay show conocido, cae al `saldo` original.
- `injected.js`: solo `BM_BUILD`. `background.js` sin tocar.

## 0.1.39 — 2026-05-23 — Bridge Telegram (inicio real del broadcast)
- Stripchat no expone hora confiable de "broadcast started"
  (`statusChangedAt` cambia con cualquier transición de modo).
  El canal Telegram **BE PRAGA ONLINE** sí publica el 🟢/📡 con
  timestamp exacto al inicio del show. Ahora BeModels lo consume
  vía un mini bridge HTTP en el server.
- **Server side** (extension-bestudio/server/):
  - **NUEVO** `bridge.ps1`: listener HTTP en
    `127.0.0.1:7878` (configurable). Endpoint
    `GET /api/start?model=<m>` que lee `bestudio_tg.json` y devuelve
    `{ startedAt: ISO, source: "telegram" }`. CORS abierto. Cache
    5s. Sin dependencias.
  - `config.example.ps1`: nuevas vars `$BridgePort` y `$BridgeBind`.
  - `bestudio-launcher.ps1`: tweak de 2 líneas (395 + 412) para que
    `$state.live[$name] = $ts` **solo se setee si NO existe ya**.
    Asi se conserva el PRIMER timestamp de la sesión (no se
    sobreescribe con eventos posteriores). El 🔴 sigue limpiando.
- **BeModels side**:
  - **NUEVO** `bemodels/telegramFetcher.js`: content script con
    `window.BMTelegram.getStart(model, bridgeUrl)`. Errores
    silenciosos (return null). Carga ANTES de `content.js`.
  - `manifest.json`: añadido al content_scripts.
  - `content.js`: nuevo estado `_tgStart`, función `pollTelegram`,
    tick cada 60s, llamada en `SELF`, fresh poll al cambiar
    `bridgeUrl`. `effStart()` ahora prioriza:
    **manual > tg > sesión > DAY.streamStart > _apiStreamStart >
    firstTs**. Nueva fn `effStartSource()` devuelve la fuente activa.
  - **Render EN VIVO** muestra `📡` (Telegram) o `✍` (manual)
    junto a la etiqueta cuando esas fuentes están activas.
  - `popup.html`/`popup.js` y panel ⚙ in-page: nuevo campo
    **"Bridge Telegram (URL)"** (default vacío = sin uso).
- **`README.md`** §6c: setup del bridge + opción Cloudflare Tunnel
  para acceso desde casa (sin abrir puertos).
- `injected.js`: solo `BM_BUILD`. `background.js` sin tocar.

## 0.1.38 — 2026-05-23 — Redistribución: números más grandes y más aire
- Tras quitar 2 franjas (TOP 1000 + RANK) sobraba espacio. La barra
  era legible pero los números clave quedaban chicos. Subimos las
  cifras y damos más aire vertical:
  - `min-height` barra: 42 → 52 px
  - `font-size` general: 9 → 11 px
  - `.bm-big` (números grandes): 14 → 18 px (+29%)
  - `.bm-seg small` (subtítulos): 8 → 10 px
  - `.bm-seg <b>` (etiquetas HOY GANADO etc.): 8 → 10 px
  - `.bm-tip` (sugerencias): 8 → 10 px
  - `.bm-alert` (ballena/goal): 10 → 12 px
  - Padding interno segmento: 3/10 → 4/14 px
  - `min-width` segmento: 90 → 130 px
  - `min-width` SUGERENCIAS: 165 → 220 px
  - Botones ⚙/_ : 22 → 26 px ancho, 11 → 13 px font
  - Barra progreso: 4 → 5 px alto
  - Saludo/Sala no autorizada: 11 → 13 px hi, 8 → 10 px estado
- `body.bm-pos-pushed` padding se ajusta solo (medimos
  `getBoundingClientRect().height` en cada render).
- `injected.js`: solo `BM_BUILD`. `background.js` sin tocar.

## 0.1.37 — 2026-05-23 — Removida franja RANK y rankFetcher (Stripchat no da rank en vivo útil)
- Diagnóstico definitivo: Stripchat NO expone un "rank en vivo" útil
  por API:
  - `topBestPlace` está esparcido en el listing (valores 0,1,2,3,8,63
    para los primeros 10 girls) → es histórico/otro cálculo, NO
    rank actual.
  - `/api/front/models?primaryTag=girls` devuelve el feed de
    recomendaciones (mix de popularidad + paid + freshness), NO una
    clasificación → la posición en el listing no es rank tampoco.
  - `ratingPosition`, `hallOfFamePosition` vacíos en sesión estudio.
  - Stripshours muestra "Rank 697 / G.Rank 201" porque ELLOS calculan
    su propio ranking; no es de la API.
- Decisión de la usuaria: quitar la franja por ahora; si se quiere
  rank en el futuro habrá que ir por (a) computar nuestro propio por
  viewers, o (b) scraping de stripshours.
- **Removido**: `bemodels/rankFetcher.js` (borrado del disco y del
  manifest); franja `#bm-rkstats` del HUD; `pollRankStats`/`rkTick`;
  variables `_rkStats/_rkTs/_rkNextAt`; load de `bemodels_rkstats`
  en storage; reglas CSS `.bm-rk-cols` y `#bm-rkstats`. Resultado:
  HUD más liviano (4 segmentos: HOY GANADO · META · EN VIVO · RITMO
  · SUGERENCIAS).
- `injected.js`: solo comentario y `BM_BUILD`. `background.js` sin
  tocar.

## 0.1.36 — 2026-05-21 — Inicio de turno + Duración del turno en el panel ⚙
- Reportado por la usuaria: los campos `Inicio de turno (HH:MM)` y
  `Duración objetivo del turno (horas)` solo estaban en el popup
  del icono de Chrome, no en el ⚙ in-page (que es donde se opera
  normalmente). Añadidos a `buildPanel()` con `fillPanel`+`savePanel`
  cableados. `bmp-turn` y `bmp-shift`.

## 0.1.35 — 2026-05-21 — Quitado TOP 24 legacy + sesión EN VIVO sobrevive medianoche
- **#1: Removida franja TOP 24/1000** (`#bm-rank`). Era legacy del
  v0.1.11 cuando no teníamos `cam.user.user.topBestPlace`
  funcionando; ahora con `Pos. General` (35) y `Pos. Género` (98)
  del rankFetcher es redundante y además mostraba "#N de 24"
  engañoso (era la posición en la PRIMERA PÁGINA del API, no top
  global). Limpieza: removidos en `content.js` `setRank`,
  `readRanking`, `_rank/_rankPrev/_rankSrc/_rankTs`, handler `RANK`
  del listener, carga de `bemodels_rank` del storage, y el segmento
  del markup. En `injected.js` removidos `RANK_URL`, `findRank`,
  `applyRankFromJson`, `pollRank`, `_rankEp`, ramas del interceptor
  fetch/XHR para ranking URL, y campos `rankEp/rankPos` del `_diag`.
- **#2: EN VIVO cruza medianoche** (pedido de la usuaria). Antes
  `effStart()` se basaba en `DAY.streamStart` que se reseteaba al
  cambiar de día → mostraba "desde 00:00" al cruzar la medianoche
  durante una sesión continua. Nuevo concepto: **sesión por modelo**
  persistida en `bemodels_session:<MODEL>` con `{startedAt,
  lastLiveAt}`, NO ligada al día. Si llegan dos STREAMs con un gap
  < 5 min (`SESSION_GAP_MS`) → sesión continua, mantiene
  `startedAt`. Si hay gap mayor → sesión nueva. `effStart()` ahora
  prioriza `_session.startedAt` por encima de DAY.streamStart.
- Render EN VIVO: si el inicio fue otro día agrega sufijo `(ayer)`
  o `(hace Nd)` para que sea claro que la sesión cruzó medianoche.
- `injected.js`: solo `BM_BUILD`. `background.js` sin tocar.

## 0.1.34 — 2026-05-20 — cache:'no-store' en rankFetcher (data fresca)
- **Bug detectado por la usuaria en Public mode:** página mostraba
  `ESTADO: Público, LIVE BUENA` pero `rankFetcher.cam OK` devolvía
  `{rank:0, gender:null, isLive:false, isOnline:false, viewers:0}`.
  Imposible que esos campos sean null/false si está broadcasting.
- Causa raíz: **caché del navegador**. Stripchat envía
  `Cache-Control` permisivo en `/cam`, y rankFetcher recibía la
  respuesta cacheada de cuando la modelo aún estaba offline. injected
  ya tenía su SELF detectado y no le importaban los nuevos valores.
- Fix: agregado `cache: 'no-store'` a las llamadas de `fetchModelCam`
  y `fetchOnePage` en `rankFetcher.js` → cada petición golpea
  servidor en vez de servir desde caché. injected y earningsFetcher
  no afectados (injected funciona; earnings usa URL con `until=now`
  que cambia por cada llamada).
- `injected.js`: solo `BM_BUILD`. `background.js` sin tocar.

## 0.1.33 — 2026-05-20 — Quitado Espectadores (redundante) + revert credentials
- **Pedido de la usuaria:** Espectadores eliminado de la franja
  RANK (es redundante: Stripchat ya lo muestra en el chat panel).
  Quedan 2 columnas: **Pos. General · Pos. Género**. CSS de 3-col
  a 2-col, ancho de segmento bajado de 195px a 145px.
  `readViewers()`/`_domViewers` removidos (código muerto).
- **Reverso del experimento `credentials:'omit'` de v0.1.32**: el
  console reveló que la respuesta anónima desde el navegador del
  estudio devolvía MENOS datos (`gender:null`, `isLive:false`) en
  vez de más. Stripchat aparentemente atenúa la respuesta cuando
  detecta origen+IP de una sesión logueada aunque omitas cookies.
  Striphours funciona porque corre server-side desde otra IP.
  `fetchModelCam` y `fetchOnePage` vuelven a `credentials:'include'`
  (baseline).
- **Estado del ranking durante ticket show / privado** (confirmado
  por consola): Stripchat baja `topBestPlace`, `ratingPosition`,
  `hallOfFamePosition` a `0` y pone `isDisplayedModel:false`. La
  modelo queda fuera del listing público. Pos. General y Pos.
  Género quedan en `—` hasta que vuelva a modo Public. NO es bug
  de BeModels — es comportamiento server-side de Stripchat.
- Log diag `rank-fields` removido (cumplió su propósito).
- `background.js` sin tocar.

## 0.1.32 — 2026-05-20 — rankFetcher anónimo como striphours (credentials:omit)
- **Insight de `reference_striphours_api.md`**: el endpoint /cam de
  Stripchat responde `Access-Control-Allow-Origin: *` sin cookies.
  Striphours lo consulta **anónimo** (`credentials:'omit'`) y eso es
  como obtiene los campos `viewersCount`, `topBestPlace`, etc.
  Hipótesis: en sesión estudio Stripchat oculta o atenúa esos
  valores (campos privados del modelo); por eso BeModels veía
  `viewersCount=undefined` y `topBestPlace=0` con `credentials:
  'include'`.
- `rankFetcher.js fetchModelCam`: cambiado a `credentials:'omit'`.
- `rankFetcher.js fetchOnePage` (listing): cambiado a
  `credentials:'omit'` también — el listing público con la misma
  filosofía. Posiblemente el listing anónimo incluya a la modelo
  (que con cookies estaba ausente del top 266).
- `injected.js` mantiene `credentials:'include'` en SU /cam — lo
  necesita para `isOwnShow` y `cam.user.user.id` (backfill de
  userId del earnings). Doble fetch (una con cookies para self,
  otra sin para datos públicos) es lo que hace striphours
  comparado con Stripchat. `background.js` sin tocar.

## 0.1.31 — 2026-05-20 — streamStart solo si isLive + readViewers permisivo + diag rank
- Comparación con tooltip de **stripshours** dejó claro que el
  endpoint `models?primaryTag=couples` NO incluye a la modelo
  (escaneamos 266 entradas vía paginación y no aparece), aunque
  stripshours muestra G.Rank=201. Hay otro ranking que Stripchat
  no expone en ese listing — toca buscar en otros campos de
  `cam.user.user`.
- `injected.js emitStreamStart`: **solo emite STREAM cuando
  `uu.isLive === true`**. Antes, si /cam se leía con la modelo
  offline, capturábamos su transición de "se fue offline" como
  inicio de show (earliest-wins lo bloqueaba para siempre). Ahora
  solo cuentan estados en vivo.
- `content.js readViewers`: regex más permisiva
  (`(usuarios?|users?)\s*[:=]?\s*N`), más selectores
  (`span,div,a,button,h1-h4,li,header`), excluye textos como
  "Usuarios invisibles", y loguea el elemento matched
  (`[BeModels] readViewers ✓ "Usuarios 87" → 87`) para confirmar
  qué texto reconoció.
- `content.js STREAM handler`: log cuando `DAY.streamStart` se
  actualiza, con la fuente (`cam`/`cam-backfill`/`nextdata`).
  Permite verificar si el valor que mostró EN VIVO se grabó por
  un STREAM legítimo.
- `rankFetcher.js`: log diagnóstico de campos candidatos para el
  rank real: `topBestPlace`, `ratingPosition`, `hallOfFamePosition`,
  `hallOfFame`, `isHiddenFromTopModels`, `isDisplayedModel`. Con
  esos valores comparamos contra stripshours (697 / 201) y
  encontramos cuál es el correcto.
- `background.js` sin tocar.

## 0.1.30 — 2026-05-20 — Paginación G.Rank + viewers DOM ("Usuarios N")
- **Diag de v0.1.29 confirmó dos cosas**:
  - `uu.statusChangedAt` SÍ está poblado (ej. `2026-05-20T16:11:34Z`)
    → EN VIVO debería usar ese valor. Si sigue sin tomarlo lo
    revisamos con la nueva captura.
  - **Ni `cam.viewersCount` ni `cam.membersCount` ni
    `uu.viewersCount` están poblados** en sesión estudio. Stripchat
    no expone viewers en vivo via /cam → necesita WS o DOM.
- `rankFetcher.js` — **paginación del listing**:
  - `fetchOnePage(gParam, offset)` (limit=24 fijo, único valor que
    Stripchat acepta).
  - `getGenderRank` ahora **pagina** hasta encontrar a la modelo,
    llegar al final del listing, o tope de 15 páginas (top ~360).
    Caché acumulativa por género (60s).
  - abrilandjulian está fuera del top 24 según diag; con 15
    páginas escaneamos hasta top 360 (de 270 couples live, debería
    encontrarla).
- `content.js` — **scrape DOM de viewers**:
  - `readViewers()` busca elemento con texto `"Usuarios N"` (panel
    de chat). Llamado desde `pollBalance` cada 5s.
  - El render de Espectadores prefiere API; si está en 0/null cae
    al DOM. Si DOM también nada → `—`.
- Reducidos los logs DIAG verbosos de v0.1.29 (ya cumplieron).
- `injected.js`: solo `BM_BUILD`. `background.js` sin tocar.

## 0.1.29 — 2026-05-20 — listing limit=24 + diag para localizar viewers/statusChangedAt
- ✅ **HOY GANADO confirmado oficial** con v0.1.28 (la usuaria validó
  consola: `today OK 243428852 tokens=2094 usd=104.7 count=85`).
- **listing seguía 400** con `limit=100`: el log nuevo del cuerpo
  reveló `{"error":"invalid 'limit' value"}`. Stripchat tiene tope
  más bajo. Bajado a `limit=24` (lo que usa la URL real capturada
  en `/categories/couples`). Solo top 24 → G.Rank puede quedar
  `null` para modelos más abajo.
- `viewers: 0` y `EN VIVO desde 06:46` persisten en sesión estudio.
  Sin ver el JSON crudo del cam no puedo arreglarlos a ciegas →
  agregados logs DIAG:
  - `rankFetcher.js cam-keys`: imprime las keys de `cam` y de
    `cam.user.user`, y los valores de `cam.viewersCount`,
    `cam.membersCount`, `uu.viewersCount`. Una vez sepamos cuál
    está poblado, se cablea ese campo.
  - `injected.js backfill cam`: imprime las keys de `cam.user.user`
    que matchean `at$|since|live|stream|status|broadcast|show|start`
    y los valores de `uu.statusChangedAt` y `cam.statusChangedAt`.
    Con eso identifico la hora real de inicio del show en la
    estructura de tu sesión.
- `background.js` sin tocar.

## 0.1.28 — 2026-05-20 — Fix 400 en /transactions y /models (ISO sin ms + limit=100)
- **transactions !ok 400** (visto en consola de la usuaria con
  v0.1.27): mi `from`/`until` salían con milisegundos
  (`2026-05-20T05:00:00.000Z` por `toISOString()`). La URL real
  capturada de Stripchat es sin ms (`2026-05-20T05:00:00Z`).
  Stripchat es estricto con el formato → 400. Fix: helper
  `isoNoMs(d)` que elimina los ms antes de meter en la URL.
- **transactions y listing rechazan limit=1000.** Las URLs reales
  capturadas usan `limit=100` (transactions) y `limit=24`
  (listing de couples). Stripchat tiene tope de página. Bajado a
  **`limit=100`** en ambos.
  - earnings: el agregado `inTokens` viene en la respuesta
    igual, no se ve afectado por la paginación.
  - rank: si la modelo está fuera del top 100 del listing,
    G.Rank quedará `null` por ahora (legítimo).
- Ambos fetchers ahora loguean el **cuerpo del error** cuando el
  status no es 2xx (`r.text()` truncado a 200 chars) para
  diagnóstico más rápido la próxima vez.
- `injected.js`: solo `BM_BUILD`. `background.js` sin tocar.

## 0.1.27 — 2026-05-20 — Backfill userId + statusChangedAt en sesión estudio; viewers correctos
- **Bug raíz observado por la usuaria:** en sesión de estudio
  ("Volver a Mis Modelos") la detección viene por DOM
  (`tryOwnPageSelf`) con un objeto dummy `{username: slug}` SIN `id`
  → `SELF_USERID` queda `null` → `pollEarnings` skipea (necesita
  userId) → HOY GANADO sigue por delta-de-saldo (mostraba "desde
  HH:MM" en vez de "✓ oficial Stripchat"). Y `emitStreamStart` solo
  se llama dentro del branch `isOwnShow===true`, que en estudio
  puede salir false → EN VIVO usa `firstTs` (= hora a la que llegó
  BeModels), no la hora real de inicio del show.
- Fix en `injected.js detectSelfFromCam`: rama de **backfill**.
  Cuando `cam.user.user.username === SELF_MODEL` (ya detectada),
  completar `SELF_USERID = cam.user.user.id` aunque `isOwnShow`
  sea `false`, y emitir `statusChangedAt`. Repostea `SELF` con
  el userId para que content.js lo capture.
- Fix en `rankFetcher.js fetchModelCam`: **viewers** se lee de
  `cam.viewersCount` (o `cam.membersCount`), no de
  `cam.user.user.viewersCount` (campo inexistente → siempre 0).
- `injected.js`: `BM_BUILD` actualizado. `background.js` sin tocar.

## 0.1.26 — 2026-05-20 — HOY GANADO autoritativo (API oficial de Stripchat)
- **Resuelve el problema del "ganado adulterado".** Confirmado por
  la usuaria con captura del response de
  `/api/front/v3/config/initial-dynamic?requestPath=%2Fearnings%2Ftokens-history`
  y de la URL de la API directa
  `/api/front/users/<USER_ID>/transactions?from=<ISO>&until=<ISO>&limit=...`
  que devuelve `{ inTokens, inUsd, numberOfTransactions, transactions[] }`.
  Stripchat respeta la TZ del perfil (Bogotá UTC-5 → `from=...T05:00Z`).
- Nuevo módulo `bemodels/earningsFetcher.js` (content script
  ISOLATED, antes de `content.js`, expone `window.BMEarn`):
  - `todayMidnightUTC(tz)` → ISO UTC de las 00:00 locales de hoy
    (iterativo, soporta DST).
  - `fetchEarningsToday(userId, tz)` → llama al endpoint y devuelve
    `{tokens, usd, count, outTokens, outUsd, from, until}`.
  - Errores silenciosos. Logs por `console.debug('[BeModels.earn]', …)`.
- `content.js`:
  - Guarda `SELF_USER_ID` del mensaje SELF (lo manda injected).
  - `pollEarnings` + `earnTick`: poll cada ~2 min, skip si
    `document.hidden`. Dispara al detectar la modelo.
  - **Prioridad para "HOY GANADO"**: 1) API `/transactions`
    autoritativo, 2) delta de saldo (fallback), 3) WS (legado).
  - La franja HOY GANADO muestra **"✓ oficial Stripchat"** cuando
    el número viene del API; "desde HH:MM" cuando es delta de
    saldo.
  - Persiste `bemodels_earn` y al cargar descarta si es de un día
    anterior (en la TZ del perfil) para no mostrar el total de ayer.
- `manifest.json`: agrega `earningsFetcher.js` antes de `content.js`.
  `host_permissions` ya cubría `stripchat.com`.
- `injected.js`: solo `BM_BUILD`. `background.js` sin tocar.

## 0.1.25 — 2026-05-19 — "desde HH:MM" en HOY GANADO + log de G.Rank
- **Transparencia en "HOY GANADO":** la usuaria reportó que el
  valor se ve "adulterado". La aritmética es correcta
  (`ganado = saldo_actual − saldo_inicial`), pero si BeModels arrancó
  a media transmisión, el "inicial" es el saldo en ese instante, no
  el de medianoche → se pierde lo ganado antes. Ahora el segmento
  HOY GANADO muestra **"desde HH:MM"** (hora a la que BeModels
  empezó a contar hoy, basado en `DAY.firstTs`) → claro qué cubre.
- **Diagnóstico de G.Rank**: si la franja sigue mostrando `—`,
  `rankFetcher.js` ahora loguea por consola la búsqueda exacta:
  username buscado, gender, tag traducido, tamaño del listing, e
  índice — o "NO está en el top N" con los 3 primeros y los 3
  últimos usernames del listado, para confirmar si es problema de
  formato del username, de paginación, o de que la modelo está
  fuera del top 1000.
- `injected.js`: solo `BM_BUILD`. `background.js` sin tocar.

## 0.1.24 — 2026-05-19 — Padding-top dinámico (no se sobrepone con Stripchat)
- **Fix de superposición** (pedido de la usuaria): en modo "Arriba",
  el body tenía `padding-top: 46px` fijo. Con la barra en estado
  "no autorizada" (1 línea) sobraba — se veía perfecto. Pero al
  estar autorizada con todas las franjas la barra crece a ~70 px y
  la barra roja de Stripchat quedaba **tapada**.
- `content.js`: nueva función `updateBodyPad()` que mide el alto
  REAL de la barra (`getBoundingClientRect().height`) tras el
  layout (`requestAnimationFrame`) y aplica el padding-top exacto
  inline en el body. En cualquier otra posición / barra oculta,
  quita el padding. Se reaplica en cada `render()` → la barra
  siempre encaja sin tapar.
- `hud.css`: se quitó la regla estática `body.bm-pos-pushed
  { padding-top: 46px !important }` (la calcula content.js).
- `injected.js`: solo `BM_BUILD`. `background.js` sin tocar.

## 0.1.23 — 2026-05-19 — Listing por primaryTag (no gender)
- **Fix definitivo de G.Rank.** La usuaria capturó en Network que
  la página `stripchat.com/categories/couples` llama
  `/api/front/models?primaryTag=couples&limit=24&...` (200) y
  `/api/front/liveTags?primaryTag=couples&withMixedTags=false` (200),
  mientras que `?gender=couples` siempre devuelve **400**: ese
  parámetro no existe en `models`. El filtro real es `primaryTag`.
- `rankFetcher.js`:
  - URL del listing: `/api/front/models?primaryTag=<TAG>&limit=1000`
    (sin `gender=`).
  - `GENDER_MAP` ahora mapea `broadcastGender → primaryTag slug`:
    `female→girls`, `male→men`, `couples/couple/group/maleFemale→couples`,
    `trans/transgender→trans`.
- `injected.js`: solo `BM_BUILD`. `background.js` sin tocar.

## 0.1.22 — 2026-05-18 — RANK en 3 columnas estilo tarjeta
- Franja RANK rediseñada según referencia visual de la usuaria: 3
  columnas centradas con número grande arriba y etiqueta abajo —
  **Espectadores · Pos. General · Pos. Género**. Sin íconos
  (`🌐`/`💑`) — solo los números y etiquetas en español. Tooltips
  en las dos etiquetas de rank. `_rkStats.viewers` se usa para
  Espectadores. Si un valor es 0/null → `—`.
- `injected.js`: solo `BM_BUILD`. `background.js` sin tocar.
- **Pendiente para mañana:** la consola muestra
  `listing !ok couples 400` incluso con `?gender=couples&limit=1000`
  (sin `primaryTag=girls`). El parámetro `couples` no es aceptado
  tal cual por ese endpoint — hay que probar otros valores
  (`couple`, `couplesAndMore`, `male+female`…) o el endpoint
  correcto para parejas. G.Rank seguirá en `—` hasta que se
  resuelva.

## 0.1.21 — 2026-05-18 — primaryTag=girls solo para female
- `rankFetcher.js`: la query del listing solo incluye
  `&primaryTag=girls` cuando el género es `female`. Para
  `couples`/`male`/`trans` se omite (esa categoría es sub-tag de
  "girls" en Stripchat y sobrefiltraba dejando el listing casi
  vacío → G.Rank `null` aunque la modelo sí estuviera en el top).
  Cubre el caso de EmilyAndAndrew (broadcastGender='group').
- `injected.js`: solo `BM_BUILD`. `background.js` sin tocar.

## 0.1.20 — 2026-05-18 — Fix broadcastGender 'group' (G.Rank devolvía 400)
- Confirmado en tráfico real: Stripchat reporta
  `broadcastGender: 'group'` para cuentas de pareja/grupo (caso real:
  EmilyAndAndrew). El `GENDER_MAP` de `rankFetcher.js` no lo tenía,
  así que pasaba `?gender=group` al listing y Stripchat respondía
  **400 Bad Request** → G.Rank quedaba en `null`. Añadido
  `group → 'couples'`. Mismo trato a `couple` en el icono.
- `injected.js`: solo `BM_BUILD`. `background.js` sin tocar.

## 0.1.19 — 2026-05-18 — Mostrar RANK durante el saludo
- `#bm-rank` (TOP 1000 mensual) y `#bm-rkstats` (RANK global +
  G.Rank) ya NO se ocultan cuando la barra está en modo saludo. Esos
  números no dependen del "ganado hoy", así que se ven desde el
  primer momento aunque la modelo aún no haya recibido tokens. El
  saludo en sí no se toca (instrucción previa de la usuaria).
- `injected.js`: solo `BM_BUILD`. `background.js` sin tocar.

## 0.1.18 — 2026-05-18 — Fix CORS rankFetcher + barra 25% menor + push body
- **Fix bug crítico (CORS):** `rankFetcher.js` usaba URL absoluta
  `https://stripchat.com/...`, pero la modelo está en
  `https://es.stripchat.com/...` → cross-origin → bloqueado por CORS
  ("No 'Access-Control-Allow-Origin' header"). Cambiado a **URL
  relativa** (`/api/front/v2/models/...` y `/api/front/models?...`),
  igual que hace `injected.js`. Ahora la petición es same-origin y
  funciona en cualquier subdominio.
- **Tamaño de la barra: ~25% más pequeña** en todas las dimensiones
  (alturas, paddings, fuentes, anchos de segmentos y del modo
  vertical). `hud.css` ajustado en `.bm-wrap`, `.bm-brand`,
  `.bm-seg`, `.bm-big`, `.bm-tip`, `.bm-alert`, `.bm-cfg/.bm-min`,
  `.bm-pos-left/right .bm-wrap`, `.bm-greet-*`. Mismo look, menos
  espacio en pantalla.
- **Push del body cuando la barra está ARRIBA:** al elegir
  posición "Arriba" en el ⚙, el body recibe la clase
  `bm-pos-pushed` (`padding-top: 46px !important`) para que la
  barra roja de Stripchat **no quede tapada** sino que aparezca
  debajo de BeModels — exactamente "entre el browser y el rojo".
- `injected.js`: solo `BM_BUILD`. `background.js` sin tocar.

## 0.1.17 — 2026-05-18 — Rank global + G.Rank (rankFetcher.js)
- Nuevo módulo `bemodels/rankFetcher.js` (content script ISOLATED,
  cargado ANTES de `content.js`, expone `window.BMRank`):
  - `fetchModelCam(u)` → lee `/api/front/v2/models/username/<u>/cam`
    y devuelve `{rank, gender, isLive, isOnline, viewers, followers,
    showType}` (campos: `user.user.topBestPlace`,
    `broadcastGender`, etc.).
  - `fetchGenderListing(g)` → `/api/front/models?gender=<g>`
    `&primaryTag=girls&limit=1000`, **cacheado 60 s por género** para
    no spamear ese endpoint.
  - `getGenderRank(u, g)` → index + 1 en el listing, o `null` si
    fuera del top 1000.
  - `getModelStats(u)` → combina ambos.
  - Errores silenciosos (null en vez de throw). Logs por
    `console.debug('[BeModels.rank]', …)`.
  - Mapeo de género: `female→female`, `male→male`,
    `maleFemale→couples` (verificar empíricamente), `trans→trans`.
- `content.js`: nueva franja **RANK** en la barra (después de
  TOP 1000), con badge `🌐 #N` (rank global) y `♀/♂/💑/⚧ #N`
  (G.Rank con icono según género). Si rank=0/null → `—`; offline
  → opacidad atenuada; tooltips. Cadencia de poll: 60 s live /
  300 s offline; skip si `document.hidden`. Último valor persistido
  en `bemodels_rkstats` para reaparecer tras recarga.
- `manifest.json`: añade `rankFetcher.js` antes de `content.js` en
  content_scripts. `host_permissions` ya cubría `stripchat.com`.
- `injected.js`: solo `BM_BUILD`. `background.js` sin tocar.

## 0.1.16 — 2026-05-18 — Candado de modelos autorizadas
- BeModels ya NO funciona con cualquier modelo. Nueva lista
  `BM_AUTORIZADAS` (las MISMAS 19 de BeStudio
  `MODELOS_AUTORIZADAS_BG`) en `content.js` y `popup.js`.
- Fuera de la lista (incl. activación manual): no se dibuja la
  barra, no se cuenta, no se leen saldo/ranking ni se escanean
  tarjetas; la barra muestra "⛔ Sala no autorizada" y el popup
  "⛔ NO autorizada". Modo demo (`(demo)`) exento.
- Sincronización a mano entre los 3 sitios (BeStudio = fuente de
  verdad). Protección = lista en JS plano (frena robo casual, no es
  DRM; mismo nivel que BeStudio, aceptado por el usuario).
- `injected.js`: solo `BM_BUILD`. `background.js` sin tocar.

## 0.1.15 — 2026-05-18 — Prueba independiente en PC del estudio
- Nuevo `server/test-bemodels.ps1`: lanza Chrome for Testing con un
  perfil de prueba aparte (`_bemodels_test`) cargando SOLO BeModels
  (`--load-extension`/`--disable-extensions-except` solo a esta
  extensión). No toca el launcher de BeStudio ni los perfiles de las
  modelos. Para probar BeModels sola en una PC del estudio.
- `README.md` §6 dividido: 6a PC de casa ("Cargar descomprimida"),
  6b PC del estudio (script independiente + `git pull`). Aclara que
  no hay "instalar desde el servidor": se carga por `--load-extension`.
- `injected.js`: solo `BM_BUILD`. `background.js` sin tocar.

## 0.1.14 — 2026-05-18 — Posición de barra configurable
- En el panel ⚙ nuevo selector **Posición de la barra**: Abajo
  (default), Arriba, Izquierda, Derecha. `barPos` en config;
  `render()` aplica clase `bm-pos-*`; CSS añade variantes (arriba =
  borde abajo; lados = columna vertical 244px, scroll).
- **Fix:** `savePanel()` (panel in-page) hacía `Object.assign` solo
  con sus campos y persistía ese subconjunto → borraba ajustes que
  solo viven en el popup (manualModel, turnStart, shiftGoalH,
  whaleBalanceTk, alertHidden). Ahora hace **merge** con lo ya
  guardado antes de persistir.
- `injected.js`: solo `BM_BUILD`. `background.js` sin tocar.

## 0.1.13 — 2026-05-18 — RITMO en USD
- La franja RITMO ahora muestra también el equivalente en dólares
  por hora (`tk/h ÷ 20` → `≈ $/h`), en verde como las demás cifras
  USD. `injected.js`: solo `BM_BUILD`. `background.js` sin tocar.

## 0.1.12 — 2026-05-18 — Ranking por API (auto-endpoint) + ▲/▼
- El puesto del Top N ahora viene del **API**, no solo del DOM.
  `injected.js`: sin adivinar URLs — cuando la modelo pasa por la
  página de Top Models, el interceptor (fetch+XHR) detecta la
  respuesta JSON que contiene SU entrada (`username == self`) y su
  posición (`findRank` recursivo), **aprende ese endpoint** y lo
  **re-consulta cada ~3 min** (`pollRank`) aunque esté transmitiendo
  → el puesto se mueve solo. Mensaje `RANK` injected→content.
- `content.js`: `setRank()` unifica API (autoritativo) y DOM
  (siembra). Muestra **▲/▼** vs la posición anterior y "hace Xm".
  Persistido en `bemodels_rank` (pos/total/prev/src/ts).
- El endpoint y la posición aprendidos se añaden al diagnóstico
  (`rankEp`, `rankPos`) para verificar.
- `background.js` sin tocar.

## 0.1.11 — 2026-05-18 — Ranking Top 1000 en la barra
- Nueva franja **TOP 1000** con el puesto de la modelo. Lee
  `[class*="TopModelsAwardLabel__strong"]` ("Puesto 875") + el total
  del texto "en el Top N". Confirmado por el usuario con el DOM.
- Se recuerda el último valor visto (`bemodels_rank` en storage) y
  se recarga al iniciar, porque el badge solo aparece en la página
  de Top Models, no en la sala en vivo → así sigue visible mientras
  transmite. La franja se oculta si nunca se ha visto.
- `injected.js`: solo `BM_BUILD`. `background.js` sin tocar.

## 0.1.10 — 2026-05-18 — USD (÷20) + quita GOAL SC + whale por balance
- **Conversión a USD:** bajo HOY GANADO y en META DÍA se muestra el
  equivalente en dólares (1 USD = 20 tk → `tk/20`), en verde y
  pequeño. También en la línea del saludo. Helper `usd()`.
- **GOAL SC eliminado** de la barra (Stripchat ya lo muestra en su
  propia barra de objetivo). Las sugerencias internas de goal se
  mantienen.
- **Whale por balance (campana):** nuevo `scanUserCards()` (método
  probado de BeCapture) — cuando se abre la tarjeta de perfil de un
  espectador, si su balance ≥ umbral (`whaleBalanceTk`, default
  1000) → alerta en barra + notificación del sistema. También avisa
  de los que **ocultan** su balance (`alertHidden`, posible whale).
  Dedupe por usuario. Nota: Stripchat solo expone el balance al
  abrir la tarjeta del usuario, no en la conexión.
- Popup: campos "Whale en sala — balance ≥ (tk)" y checkbox
  "Avisar también de los que ocultan su balance".
- `injected.js`: solo `BM_BUILD`. `background.js` sin tocar.

## 0.1.9 — 2026-05-18 — Salir del saludo con ganado>0 + EN VIVO en saludo
- **Fix:** la barra se quedaba pegada en el saludo aunque ya
  estuviera ganando (174 tk). La condición de salir miraba
  `DAY.tipsCount` (WS), pero el total viene del SALDO → nunca
  cambiaba. Ahora `render()` calcula la analítica primero y sale del
  saludo cuando **ganado > 0** (por saldo o WS) → pasa a la barra
  completa con HOY GANADO / META DÍA / **EN VIVO** / RITMO / GOAL SC
  / SUGERENCIAS.
- El propio saludo ahora muestra el tiempo **EN VIVO** y la hora de
  inicio en la línea de estado (visible aun con 0 ganado).
- `injected.js`: solo `BM_BUILD`. `background.js` sin tocar.

## 0.1.8 — 2026-05-18 — Inicio tx por campo CONFIRMADO statusChangedAt
- Dato confirmado en tráfico real por el usuario: el inicio de
  transmisión está en `/cam` → `user.user.statusChangedAt` (ISO
  UTC). `injected.js` `extractStreamStart()` ahora lee ese campo
  primero (y `cam.statusChangedAt`), con el escaneo genérico solo
  como respaldo. Antes el escaneo no lo cogía (la clave no contiene
  "start/since").
- Matiz documentado: `statusChangedAt` también cambia al alternar
  público↔privado a mitad de show. content.js ya fija el **primer
  valor visto** y nunca lo pisa con uno posterior → el "tiempo
  transmitiendo" total es correcto. No depende de BeStudio.
- `README.md` §3: documentado el campo + el del saldo del header
  (para el handoff). `background.js` sin tocar.

## 0.1.7 — 2026-05-18 — Inicio de transmision + barra de tiempo en vivo
- **Tiempo transmitiendo (pedido):** nueva franja "EN VIVO" en la
  barra con la duración del turno + barra de progreso hacia la
  duración objetivo (default 6 h) + hora de inicio.
- **Inicio real del turno (no cuando cargó BeModels):**
  - `injected.js`: escanea `/cam` y `__NEXT_DATA__` por una marca de
    tiempo de inicio (`*startedAt`/`*Since`/`stream|broadcast*start`)
    plausible (pasada, < 36 h) → mensaje `STREAM`. Se añade al
    diagnóstico.
  - `content.js`: inicio efectivo = **turno manual > detectado API >
    primer evento**. El ritmo/ETA y la franja EN VIVO usan ese
    inicio (antes usaban cuando arrancó la extensión → turno corto
    si cargó tarde, justo el problema reportado).
  - Popup: campos **"Inicio de turno (HH:MM)"** y **"Duración
    objetivo del turno (horas)"**; el diagnóstico muestra el inicio
    de tx detectado o avisa que no está expuesto.
- `background.js` sin tocar.

## 0.1.6 — 2026-05-18 — Lector de saldo por la clase REAL
- La modelo inspeccionó el header: el saldo es
  `<span class="TokensAmount__amount#sq tokens-amount">1225</span>`
  → el texto es SOLO dígitos ("1225"), el "tk" es un hermano. El
  lector v0.1.5 exigía "N tk" en el mismo elemento → nunca cuadraba.
- `content.js` `readBalance()`: ahora busca primero por clase
  (`[class*="TokensAmount__amount"]`, `[class~="tokens-amount"]`,
  `[class*="tokens-amount"]`) y parsea solo dígitos (helper
  `digits`, tolera separadores de miles). Conserva el respaldo de
  texto "N tk" en la barra superior si la clase cambiara.
- `injected.js`: solo `BM_BUILD`. `background.js` sin tocar.

## 0.1.5 — 2026-05-18 — Progreso por SALDO del header (no por WS)
- **Cambio de fuente de datos (pedido de la modelo):** el header de
  Stripchat ya muestra el saldo/ingresos ("1225 tk"). En vez de
  interceptar el WebSocket (fragil, dependia de isOwnShow), BeModels
  ahora LEE ese numero del DOM:
  - `content.js` `readBalance()`: localiza el saldo en la barra
    superior (texto tipo "N tk", arriba, el mas a la derecha) con
    cache del elemento.
  - Por dia se guarda `startBalance` (1a lectura del dia) y
    `balance` (actual). **Ganado hoy = max(0, balance −
    startBalance)**; si baja (retiro/payout) se re-basa el inicio.
  - La barra de progreso, el saludo y META usan ese "ganado" hacia
    la meta (2000). Polling cada 5 s.
  - El WS sigue como respaldo (si no se puede leer el saldo) y para
    ballenas/top usuarios.
- Popup: muestra "saldo leído: N tk" (para verificar la lectura) y
  "GANADO HOY: X (saldo …, inicio …)".
- `injected.js`: solo `BM_BUILD`. `background.js` sin tocar.

## 0.1.4 — 2026-05-18 — Deteccion por pagina propia + manual + diagnostico
- **Seguia sin detectar** (estudio + show privado). Añadido:
  - `injected.js` `isOwnBroadcastPage()`: detecta la PROPIA pagina
    de transmision por texto/DOM ("estás EN DIRECTO", "estoy en un
    Show", controles de broadcaster, "Volver a Mis modelos"). Sirve
    aunque `/cam` no devuelva `isOwnShow` (show privado/estudio).
  - **Activacion MANUAL:** en el popup, campo "tu usuario" + botón
    Activar. Guarda `cfg.manualModel`; content.js avisa a injected
    (`BEMODELS_CMD/FORCE`) → fija self + ownShow y la barra cuenta
    tus tips ya, sin depender del auto-detect.
  - **Diagnostico legible en el popup** (antes "Sin datos aun"):
    muestra si detectó y por qué fuente, o el detalle del fallo
    (/cam HTTP, isOwnShow, estado de NEXT_DATA, página propia) +
    el build. Se refresca cada 4 s. Mensajes `DIAG` injected→popup.
- **Meta diaria por defecto = 2000 tk** (antes 5000), segun pedido.
- **Barra de progreso visible desde 0:** el saludo ahora muestra la
  barra de progreso hacia la meta (`tot / meta · faltan X · %`) en
  vez de la lista; al primer tip pasa a metricas completas.
- `content.js`/`hud.css`/`popup.*`: render + estilos + manual.
  `background.js` sin tocar.

## 0.1.3 — 2026-05-18 — Deteccion robusta + saludo a la modelo
- **Fix deteccion (no detectaba a la modelo):** antes solo se hacia
  polling por slug del `/cam` SIN el header `accept: application/json`
  y SIN interceptar XHR ni `__NEXT_DATA__`. En contexto de estudio
  ("Volver a Mis Modelos") y con la SPA usando XHR, la deteccion
  nunca disparaba. `bemodels/injected.js` portado de BeCapture:
  - `looksLikeAuthSelf` + `scanSelf`: detecta la CUENTA logueada
    (isModel/isStudioModel/role) en cualquier payload, no solo en
    `cam.user.user`.
  - Lee `window.__NEXT_DATA__.props.pageProps` al arrancar y en
    reintentos (NEXT_DATA puede poblarse tarde).
  - Intercepta **XHR** ademas de `fetch`; `/cam` con
    `accept: application/json`; tambien escanea `/users/me`.
  - Re-bootstrap en navegacion SPA.
  - `OWNSHOW`: tips/goal SOLO se cuentan si la sala abierta es la
    propia (`cam.isOwnShow`), nunca los de otra sala.
- **Saludo a la modelo:** al detectarla y mientras no haya tips del
  dia, la barra muestra "👋 Hola {nombre}, soy BeModels, tu
  extensión de modelo" + la lista de lo que se captura (total del
  día, meta + ETA, ritmo, goal SC, ballenas, sugerencias) y el
  estado (en tu sala / abre tu sala). Al primer tip pasa a metricas.
- `bemodels/content.js`/`hud.css`: render del saludo + estilos.
  `background.js` sin tocar.

## 0.1.2 — 2026-05-18 — Marca BE PRAGA + ajustes in-page
- Identidad visual unificada con BeStudio/BeGoals: paleta morada
  (`#5409A9` / `#DF84F9`, gradiente `135deg,#5409A9,#7B1FA2,#9C27B0`)
  y fuente Poppins. Antes BeModels iba en verde, ajeno al
  ecosistema. Aplica a la barra HUD, badges y el popup del icono.
- `bemodels/content.js`: NUEVO panel de ajustes IN-PAGE. La barra
  HUD lleva un boton ⚙ que despliega, DENTRO de la propia pagina de
  Stripchat, una tarjeta con la misma config que el popup (meta
  diaria, umbrales de ballena, zona horaria, on/off de la barra,
  modo demo) + resumen del dia. Persiste en la misma clave
  `bemodels_cfg` → queda en sync con el popup del icono. La modelo
  ya NO necesita abrir el icono de la extension.
- `bemodels/hud.css`: reescrito con la paleta BE PRAGA + estilos del
  panel in-page (tarjeta clara, cabecera morada). El modo demo
  conserva el borde ambar para no confundirse con datos reales.
- `popup.html`/`popup.css`: cabecera con marca `Be<span>Models</span>`,
  tema claro morado, Poppins.
- `bemodels/injected.js`: sin cambios funcionales; solo `BM_BUILD`.
  `background.js` sin tocar.

## 0.1.1 — 2026-05-18 — Modo demo + fix tiempo de sesion
- `bemodels/content.js`: NUEVO modo demo (`cfg.demo`). Con el demo
  activo y SIN sala propia detectada, fija el modelo `(demo)`,
  inyecta un goal de Stripchat sintetico y tips aleatorios cada 4 s
  por la MISMA ruta `addTip()` para ver/afinar META DIA %, RITMO
  tk/min, ETA y GOAL SC sin transmitir. Datos demo aislados bajo la
  clave `bemodels_day:(demo):<fecha>`. Un show real (`SELF`) SIEMPRE
  manda: apaga el demo y nunca mezcla datos.
- Fix de calculo de tiempo: el tiempo de sesion usaba
  `lastTs - firstTs`, que se CONGELA entre tips (`lastTs` solo cambia
  al recibir un tip) → inflaba tk/h y daba un ETA irreal. Ahora usa
  `now - firstTs` (tiempo real transcurrido) → ritmo y ETA correctos
  aunque no lleguen tips.
- `bemodels/hud.css`: barra en modo demo con borde ambar + marca
  "BeModels · DEMO" para que NUNCA se confunda con datos reales.
- `popup.html`/`popup.js`: checkbox "Modo demo (prueba sin
  transmitir)".
- `bemodels/injected.js`: sin cambios funcionales; solo `BM_BUILD`.
  `background.js` sin tocar.

## 0.1.0 — 2026-05-18 — Base inicial
- Extension nueva, EXCLUSIVA para la modelo (separada de BeStudio).
- `bemodels/injected.js` (MAIN): detecta sala PROPIA por
  `/api/front/v2/models/username/{m}/cam` → `cam.isOwnShow===true`
  (mismo metodo probado en BeCapture). Poll de `cam.goal` cada 25 s.
  Intercepta WebSocket Centrifugo y suma tips en vivo
  (canales `tip`/`freeTip`/`goalContribution`) con usuario.
- `bemodels/content.js` (ISOLATED): barra HUD inferior fija;
  acumula el dia en `chrome.storage.local`
  (`bemodels_day:<model>:<YYYY-MM-DD>`); calcula total del dia,
  promedio tk/hora, ritmo tk/min (ventana 20 min), progreso de la
  meta diaria + ETA, progreso/ETA del goal de Stripchat, alerta de
  usuarios ballena y sugerencias por reglas.
- `bemodels/hud.css`: barra fija inferior (z-index alto),
  colapsable, segmentos HOY / META DIA / RITMO / GOAL SC /
  SUGERENCIAS + zona de alerta.
- `background.js`: relé de notificaciones (ballenas) + poda de
  dias > 45.
- `popup.html/js/css`: ajustes (meta diaria, umbrales de ballena,
  zona horaria, on/off de la barra) + resumen del dia.
- La barra SOLO aparece en la sala propia de la modelo; en otras
  salas / navegacion normal no se muestra.
