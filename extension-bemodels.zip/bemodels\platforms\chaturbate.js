// ============================================================
//  BeModels — platforms/chaturbate.js  (content script, ISOLATED)
//
//  Adapter de Chaturbate. Implementa la interfaz definida en
//  platforms/base.js para que content.js pueda mostrar el HUD en
//  chaturbate.com igual que en stripchat.com.
//
//  Tasas (snapshot 2026-05):
//    1 token Chaturbate = $0.05 USD bruto
//    Share modelo: 50% (Chaturbate se queda 50%)
//    → 1 tk = $0.025 USD neto
//
//  Endpoints / selectores que usa este adapter (datos pasados por
//  la operadora del estudio 2026-05-31):
//
//   - Earnings:
//       GET /api/ts/tipping/token-stats/?max_transaction_id=&cashpage=0
//       Devuelve transacciones (tips, etc.) — paginado por
//       max_transaction_id.
//
//   - Balance:
//       #header-token-wrapper (suele estar en 0 porque la modelo
//       retira los tokens automáticamente a su cuenta — el campo
//       sigue existiendo pero no es buena fuente de "ganado").
//
//   - Identidad de la modelo:
//       El bot Telegram BE PRAGA ONLINE detecta el 🟢 cuando la
//       modelo se conecta (mismo flujo que Stripchat). El launcher
//       captura ese evento y el bridge expone startedAt en
//       /api/start?model=<username>.
//       Para que BeModels SEPA el username de la modelo logueada
//       intenta varias estrategias DOM/cookies. Si fallan, cae al
//       CFG.manualModel del panel.
//
//  TODO bridge 0.7.4: actualizar el launcher (bestudio-launcher.ps1)
//  para que el regex de "se conecto en X" capture Chaturbate además
//  de Stripchat. Hoy lo ignora → el bridge devuelve startedAt=null
//  para modelos en Chaturbate y BeModels cae a heurísticas locales.
// ============================================================
(function () {
  'use strict';
  const TAG = '[BeModels.chat]';

  // ── Identidad de la modelo logueada ───────────────────────────
  // Múltiples estrategias en cascada porque Chaturbate no expone un
  // global limpio. Devolvemos la primera que funcione. Logueamos
  // todas para diagnóstico desde DevTools console.
  // Paths reservados de Chaturbate que NO son usernames (filter
  // común para las estrategias por URL / anchor).
  const RESERVED_PATHS = new Set([
    'login', 'signup', 'about', 'help', 'tags', 'support', 'search',
    'static', 'affiliates', 'apps', 'dashboard', 'broadcast',
    'settings', 'token-purchase', 'pm', 'tip', 'token-stats',
    'verify', 'tags', 'female-cams', 'male-cams', 'couple-cams',
    'trans-cams', 'new-cams', 'tag', 'feed', 'roomlist'
  ]);
  function isValidUsername(u) {
    if (!u) return false;
    u = String(u).toLowerCase().trim();
    if (!/^[a-z0-9_]{3,30}$/i.test(u)) return false;
    if (RESERVED_PATHS.has(u)) return false;
    return true;
  }

  // Paths de Chaturbate que NUNCA tienen una modelo (home, listings,
  // tags, settings de cuenta, etc.). Si estamos en uno de estos,
  // saltamos detección silenciosamente — no warn, no error. La
  // modelo va a navegar a su /b/X/ o /p/X/ eventualmente y ahí
  // BeModels arranca correctamente.
  const NO_MODEL_PREFIXES = [
    '/female-cams', '/male-cams', '/couple-cams', '/trans-cams',
    '/new-cams', '/tag/', '/feed/', '/about/', '/help/', '/login',
    '/signup', '/search/', '/affiliates/', '/apps/', '/static/',
    '/api/', '/edit_account/', '/messages/', '/token-purchase/'
  ];
  function isNoModelPage() {
    const p = (location.pathname || '/').toLowerCase();
    if (p === '/' || p === '') return true;
    for (const pre of NO_MODEL_PREFIXES) {
      if (p === pre || p.startsWith(pre)) return true;
    }
    return false;
  }

  function detectUsername() {
    // Skip silencioso en páginas donde no hay modelo (home, listings).
    if (isNoModelPage()) {
      console.debug(TAG, 'pathname=' + location.pathname + ' es página sin modelo — skip');
      return null;
    }
    console.log(TAG, 'detectUsername start · pathname=' + location.pathname);

    // 1. Cookies — Chaturbate suele dejar username en cookie 'username'.
    try {
      const m = document.cookie.match(/(?:^|;\s*)username=([^;]+)/i);
      if (m && m[1]) {
        const u = decodeURIComponent(m[1]).toLowerCase().trim();
        if (isValidUsername(u)) {
          console.log(TAG, '✓ username via cookie:', u);
          return u;
        }
      }
    } catch (_) {}

    // 2. Globals JS comunes.
    const GLOBALS = ['UTL_USERNAME', 'username', 'currentUser',
                     'CURRENT_USER', 'cb_username', 'BROADCASTER_USERNAME'];
    for (const k of GLOBALS) {
      try {
        const v = window[k];
        if (typeof v === 'string' && isValidUsername(v)) {
          console.log(TAG, '✓ username via window.' + k + ':', v);
          return v.toLowerCase();
        }
        if (v && typeof v === 'object' && v.username && isValidUsername(v.username)) {
          console.log(TAG, '✓ username via window.' + k + '.username:', v.username);
          return String(v.username).toLowerCase();
        }
      } catch (_) {}
    }

    // 3. Header DOM — link al perfil. Probamos varios selectores.
    try {
      const anchors = document.querySelectorAll(
        'header a[href^="/p/"], header a[href^="/"], ' +
        '.user-menu a, #user_dropdown a, ' +
        '#user_information a, .messageMenu a, ' +
        'a[href*="/p/"][href*="/edit_account/"], ' +
        'a[href*="/edit_account/"]');
      for (const a of anchors) {
        const href = a.getAttribute('href') || '';
        const m = href.match(/\/p\/([a-z0-9_]{3,30})(?:\/|$)/i) ||
                  href.match(/^\/([a-z0-9_]{3,30})\/?$/i);
        if (m && isValidUsername(m[1])) {
          console.log(TAG, '✓ username via anchor href=' + href + ':', m[1]);
          return m[1].toLowerCase();
        }
      }
    } catch (_) {}

    // 4. URL — Chaturbate usa varios prefijos para páginas de modelo:
    //      /p/USERNAME/         → perfil público (?tab=tokens, etc.)
    //      /b/USERNAME/         → broadcaster dashboard
    //      /chat/USERNAME/      → vista de chat (raro)
    //      /USERNAME/           → sala pública directa
    //    Aceptamos cualquiera siempre que el username sea valido.
    try {
      const p = location.pathname;
      const URL_PATTERNS = [
        { re: /^\/p\/([a-z0-9_]{3,30})(?:\/|$)/i,    src: '/p/X/' },
        { re: /^\/b\/([a-z0-9_]{3,30})(?:\/|$)/i,    src: '/b/X/ (broadcaster)' },
        { re: /^\/chat\/([a-z0-9_]{3,30})(?:\/|$)/i, src: '/chat/X/' },
        { re: /^\/([a-z0-9_]{3,30})(?:\/|$)/i,       src: '/X/' }
      ];
      for (const pat of URL_PATTERNS) {
        const m = p.match(pat.re);
        if (m && isValidUsername(m[1])) {
          console.log(TAG, '✓ username via URL ' + pat.src + ':', m[1]);
          return m[1].toLowerCase();
        }
      }
    } catch (_) {}

    // 5. <title>: a veces "MODELO - Chaturbate" o similar.
    try {
      const t = document.title || '';
      const m = t.match(/^([a-z0-9_]{3,30})\s*[-|·]\s*Chaturbate/i);
      if (m && isValidUsername(m[1])) {
        console.log(TAG, '✓ username via title:', m[1]);
        return m[1].toLowerCase();
      }
    } catch (_) {}

    // 6. CFG.manualModel — último fallback: lo lee content.js, NO el
    //    adapter. Acá solo devolvemos null para que content.js intente
    //    el manualModel. console.debug (no warn) para no llenar el
    //    panel de errores de la extensión con falsos positivos.
    console.debug(TAG, 'username NO detectado en página con potencial modelo — content.js usará CFG.manualModel');
    return null;
  }

  // En Chaturbate la cuenta logueada y la sala vista coinciden
  // cuando la URL incluye el username de la modelo. Si está en
  // dashboard o config, igual la consideramos "en su show" porque
  // está operando su cuenta.
  function detectOwnShow(username) {
    if (!username) return false;
    try {
      const p = location.pathname.toLowerCase();
      const u = username.toLowerCase();
      // Variantes de URL donde la modelo opera su propia sala/panel.
      if (p === '/' + u || p.indexOf('/' + u + '/') === 0)        return true;
      if (p.indexOf('/p/' + u) === 0)                              return true;
      if (p.indexOf('/b/' + u) === 0)                              return true;   // broadcaster
      if (p.indexOf('/chat/' + u) === 0)                           return true;
      if (p.indexOf('/dashboard') === 0)                           return true;
      if (p.indexOf('/broadcast') >= 0)                            return true;
    } catch (_) {}
    return false;
  }

  // ── Earnings via /api/ts/tipping/token-stats/ ──────────────────
  // Paginado por max_transaction_id. Devolvemos el mismo shape que
  // BMEarn.fetchEarningsRange de Stripchat para que content.js no
  // distinga: { tokens, usd, count, tx[], txTotal, pages, truncated,
  // from, until }.
  //
  // El parámetro userId no se usa (Chaturbate identifica via cookie
  // de sesión). Lo aceptamos para mantener la firma común.
  async function fetchEarningsRange(_userId, fromIso, untilIso) {
    const fromMs  = Date.parse(fromIso);
    const untilMs = Date.parse(untilIso);
    if (!Number.isFinite(fromMs) || !Number.isFinite(untilMs)) {
      console.debug(TAG, 'rango inválido', fromIso, untilIso);
      return null;
    }
    const PAGE_MAX = 30;   // cap de paginación (similar a Stripchat)
    let maxTxId = '';
    const allTx = [];
    let pages = 0;
    let truncated = false;
    while (pages < PAGE_MAX) {
      const url = '/api/ts/tipping/token-stats/' +
        '?max_transaction_id=' + encodeURIComponent(maxTxId) +
        '&cashpage=0';
      let r;
      try {
        r = await fetch(url, {
          credentials: 'include',
          headers: { accept: 'application/json',
                     'x-requested-with': 'XMLHttpRequest' }
        });
      } catch (e) {
        console.debug(TAG, 'fetch err', e && e.message);
        if (pages === 0) return null;
        truncated = true;
        break;
      }
      if (!r.ok) {
        let body = '';
        try { body = (await r.text()).slice(0, 200); } catch (_) {}
        console.debug(TAG, 'http', r.status, body);
        if (pages === 0) return null;
        truncated = true;
        break;
      }
      let j = null;
      try { j = await r.json(); } catch (_) { break; }
      // El shape exacto de la respuesta hay que confirmarlo con un
      // test real. Aceptamos varias estructuras conocidas:
      //   { transactions: [...], next_max_transaction_id: 'X' }
      //   { items: [...], next: 'X' }
      //   { results: [...] }
      const txs = (j && (j.transactions || j.items || j.results)) || [];
      if (!Array.isArray(txs) || txs.length === 0) break;
      let oldest = null;
      let pastWindow = false;
      for (const t of txs) {
        // Posibles campos de fecha: 'date', 'created', 'timestamp', 'ts'.
        const dateStr = t.date || t.created || t.timestamp || t.ts || null;
        const ts = dateStr ? Date.parse(dateStr) : null;
        if (!Number.isFinite(ts)) continue;
        if (ts < fromMs) { pastWindow = true; continue; }
        if (ts > untilMs) continue;
        // Posibles campos de tokens: 'tokens', 'amount', 'amount_tokens'.
        const tk = Number(t.tokens || t.amount || t.amount_tokens || 0);
        if (!(tk > 0)) continue;
        allTx.push({
          ts: ts,
          tokens: tk,
          type:   t.type || t.transaction_type || null,
          user:   t.username || t.from_user || t.from || null
        });
        if (!oldest || ts < oldest) oldest = ts;
      }
      pages++;
      // Si ya pasamos el límite inferior del rango, no hace falta
      // pedir más páginas.
      if (pastWindow) break;
      // Cursor para la próxima página. Si no hay, terminamos.
      const next = (j.next_max_transaction_id || j.next ||
                    (txs[txs.length - 1] && (txs[txs.length - 1].id ||
                                              txs[txs.length - 1].transaction_id)));
      if (!next) break;
      maxTxId = String(next);
    }
    if (pages >= PAGE_MAX) {
      console.warn(TAG, 'cap de paginación alcanzado (' + PAGE_MAX +
        ' pags, ' + allTx.length + ' tx); rango puede estar incompleto.');
      truncated = true;
    }
    // Dedup defensivo por (ts, user, tokens).
    const seen = new Set();
    const txDedup = [];
    for (const t of allTx) {
      const k = t.ts + '|' + (t.user || '') + '|' + t.tokens;
      if (seen.has(k)) continue;
      seen.add(k);
      txDedup.push(t);
    }
    const totalTk = txDedup.reduce((a, t) => a + t.tokens, 0);
    const out = {
      tokens:   totalTk,
      usd:      Number((totalTk * 0.05).toFixed(2)),   // 1 tk = $0.05 bruto
      outTokens: 0, outUsd: 0,
      count:    txDedup.length,
      tx:       txDedup,
      txTotal:  txDedup.length,
      pages, truncated,
      from: fromIso, until: untilIso
    };
    console.debug(TAG, 'range OK', 'tokens=' + out.tokens,
      'count=' + out.count, 'pages=' + pages,
      truncated ? 'TRUNCADO' : '');
    return out;
  }

  // ── Saldo del DOM (suele ser 0 porque hay auto-payout) ─────────
  function readBalanceDOM() {
    try {
      const el = document.querySelector('#header-token-wrapper');
      if (!el) return null;
      const txt = (el.textContent || '').replace(/[^\d]/g, '');
      if (!txt) return null;
      return Number(txt);
    } catch (_) { return null; }
  }

  const adapter = {
    name: 'chaturbate',
    hostMatches: function (host) {
      return /(^|\.)chaturbate\.com$/.test(host);
    },

    // detectSelf usado por content.js cuando la plataforma no
    // tiene injected.js (Stripchat sí; Chaturbate NO).
    detectSelf: async function () {
      const username = detectUsername();
      if (!username) return null;
      return {
        username,
        userId: null,                         // Chaturbate identifica por cookie, no userId
        isOwnShow: detectOwnShow(username),
        source: 'chaturbate-dom'
      };
    },

    fetchEarningsRange,
    // Atajo "hoy": el midnight local lo calcula BMEarn.todayMidnightUTC.
    fetchEarningsToday: function (userId, tz) {
      try {
        const fromIso = window.BMEarn && window.BMEarn.todayMidnightUTC
          ? window.BMEarn.todayMidnightUTC(tz || 'America/Bogota') : null;
        if (!fromIso) return Promise.resolve(null);
        return fetchEarningsRange(userId, fromIso, new Date().toISOString());
      } catch (_) { return Promise.resolve(null); }
    },

    // TZ del perfil: Chaturbate no la expone fácil. Cae a CFG.tz.
    profileTz: function () { return Promise.resolve(null); },

    // Conversión Chaturbate.
    tkToUsd: function (tk) { return (Number(tk) || 0) * 0.05; },
    modelShare: 0.50,
    tokenLabel: 'tk',
    currencyLabel: 'USD',

    isPerMinute: false,

    readBalanceDOM,
    subscribeWS: null
  };

  if (!window.BMPlatforms) window.BMPlatforms = [];
  window.BMPlatforms.push(adapter);
  console.debug(TAG, 'adapter registrado · host=' + location.hostname);
})();
