# BeModels

Extensión Chrome **MV3 exclusiva para la modelo**. Cuando la modelo
está transmitiendo en SU sala, muestra una **barra (HUD) fija en la
parte inferior** ("debajo de Chrome") con sus métricas en vivo y
sugerencias. Vive en el mismo repo que BeStudio y comparte las bases
de detección/analítica, pero es una extensión **independiente** (se
instala y carga por separado).

> **Este README es el documento de contexto/handoff.** El desarrollo
> de BeModels continúa en **otro chat**; ese chat debe leer este
> archivo + `CHANGELOG.md` para tener todo el panorama.

---

## 1. Qué hace (requerimiento del usuario)

- Detecta automáticamente cuándo la modelo está transmitiendo (sala
  propia).
- Se ve como un **popup/barra en la franja inferior del navegador**.
- La barra muestra:
  - **Total del día** (tk) y nº de tips / horas activas.
  - **Promedio de la meta diaria**: progreso vs. meta de tokens del
    día (configurable) + cuánto falta.
  - **Meta en horas**: ritmo (tk/hora y tk/min de los últimos 20
    min) y **ETA** para alcanzar la meta a ese ritmo.
  - **Goal de Stripchat**: % y ETA del objetivo activo.
  - **Alertas y sugerencias de metas** (reglas: ritmo frío, goal
    estancado/casi cerrado, franja pico, meta cumplida…).
  - **Alerta de usuarios ballena** (1 tip grande o acumulado alto
    del día) en la barra + notificación del sistema.
- Ajustes en el popup: meta diaria, umbrales de ballena, zona
  horaria, on/off de la barra.

## 2. Arquitectura

```
extension-bemodels/
  manifest.json            MV3, model-only, content (MAIN+ISOLATED), popup, SW
  background.js            SW: notificaciones (ballenas) + poda 45 días
  popup.html/js/css        Ajustes + resumen del día
  icon16/48/128.png        (copiados de BeStudio)
  bemodels/
    injected.js  (MAIN)    self-detect (cam.isOwnShow) + poll cam.goal + WS tips
    content.js   (ISOLATED) HUD + analítica + chrome.storage por día
    hud.css                barra fija inferior
  CHANGELOG.md
  README.md  (este archivo / handoff)
```

**Flujo:** `injected.js` (MAIN) intercepta `fetch(/cam)` y el
WebSocket Centrifugo → `window.postMessage({source:'BEMODELS',...})`
→ `content.js` (ISOLATED) acumula en `chrome.storage.local`
(`bemodels_day:<model>:<YYYY-MM-DD>`) y dibuja la barra. La barra
**solo** se muestra si se detectó sala propia.

## 3. Hechos confirmados de Stripchat (reusados de BeStudio/BeCapture)

- `GET /api/front/v2/models/username/{m}/cam` → `{ cam, user }`.
  - `cam.isOwnShow === true` ⇒ la sala abierta es la de la cuenta
    logueada. En sala de otra modelo es `false` → NO fijar self.
  - `cam.user.user` = perfil de la cuenta logueada
    (`username`, `id`, `isModel`).
  - `cam.goal = { description, goal, spent, left, isEnabled }`.
  - **Inicio de transmisión** = `cam.user.user.statusChangedAt`
    (ISO UTC). Duración = `now − statusChangedAt`. CONFIRMADO en
    tráfico real (2026-05-18): p.ej. `kellyolsenbe` →
    `2026-05-18T21:22:48Z`. Matiz: ese valor **también cambia** al
    alternar público↔privado a mitad de show, así que para el
    "tiempo transmitiendo" total BeModels fija el **primer valor
    visto** al detectar la sala y cuenta desde ahí (si solo se
    quisiera "tiempo en el modo actual", usar el campo tal cual).
    No depende de BeStudio.
  - **Saldo/ingresos** en el DOM del header:
    `<span class="TokensAmount__amount#sq tokens-amount">N</span>`
    (texto solo dígitos; el "tk" es un hermano).
- WebSocket = **Centrifugo**. Frames server→client:
  `{ push: { channel, pub: { data } } }`.
  - Tips en vivo: canales `tip` / `freeTip` / `goalContribution`
    con `tokens|amount|tip` y `userId|username`.
  - Goal en caliente: canales que matchean
    `goalChanged|goalUpdated|newGoal|goalReached|goalCompleted`.
- (No usado aquí pero conocido) sesión = cookie httpOnly
  `stripchat_com_sessionId`; Stripcash online =
  `go.mavrtracktor.com/api/models`.

## 4. Relación con el resto del ecosistema BE PRAGA

- **BeStudio** (`extension-bestudio/`): captura completa
  (privados/grupales/PM/menú) → JSON al share → **dashboard**
  (`dashboard/index.html`) para análisis profundo
  con IA. Esa es la fuente de la analítica histórica y del Análisis
  del Menú (activaciones REALES, `tip.menuItem`).
- **BeExtractor**: export de transacciones (sin `menuItem`).
- **BeModels** es **solo HUD en vivo para la modelo**; NO sustituye
  a BeStudio ni descarga históricos. Comparte las bases de
  detección/analítica. Si más adelante se quiere histórico, leer de
  los JSON de BeStudio o exponer un export propio (pendiente).
- Convención de archivos del share y sufijos `_servidor`/`_casa`,
  versionado y push: igual disciplina que BeStudio (ver CHANGELOG).

## 5. Estado y pendientes (para el otro chat)

**Hecho (v0.1.0, base):** detección sala propia, barra HUD inferior,
meta diaria + ritmo + ETA, goal Stripchat, alerta ballenas,
sugerencias por reglas, ajustes en popup, persistencia diaria.

**Pendiente / ideas a confirmar con el usuario:**
- Validar nombres exactos de canales WS de goal en tráfico real
  (los regex de `GOAL_EVT` son tentativos).
- ¿Sugerencias con IA (como el dashboard) o seguir por reglas?
- ¿Exportar el día al share para cruzar con el dashboard?
- Histórico/tendencia semanal en el popup.
- Detección de tipos de show (privado/grupal) para metas por show.
- Empaque/instalación en el servidor (¿perfil de la modelo en casa
  o también en el server CfT?).

## 6. Cómo probar

### 6a. PC normal de la modelo (en casa)
1. `chrome://extensions` → Modo desarrollador → "Cargar
   descomprimida" → carpeta `extension-bemodels`.
   (En Chrome 148 normal `--load-extension` está bloqueado para
   automatización; "Cargar descomprimida" sí funciona manualmente.)
2. Abrir la sala propia y entrar a transmitir.
3. La barra aparece sola al detectar la modelo.
4. Ajustar en el icono (popup) o en el ⚙ de la barra.

### 6b. PC del estudio (prueba INDEPENDIENTE, sin tocar BeStudio)
En el estudio Chrome normal 148+ bloquea `--load-extension`; se usa
**Chrome for Testing**. Para probar BeModels **sola** (no se mezcla
con el watchdog ni con los perfiles de las modelos):

1. Traer el código: en `C:\BePraga\bepraga-studio` → `git pull`
   (crea/actualiza `extension-bemodels\`; `config.ps1` es gitignored,
   no se pisa).
2. Correr el script de prueba propio de BeModels:
   ```
   powershell -ExecutionPolicy Bypass -File ^
     C:\BePraga\bepraga-studio\extension-bemodels\server\test-bemodels.ps1
   ```
   Lanza Chrome for Testing con un **perfil de prueba aparte**
   (`_bemodels_test`) cargando solo BeModels.
3. En esa ventana, iniciar sesión como la modelo y abrir su sala.
4. Para terminar: cerrar esa ventana de Chrome.

No requiere "instalar desde el servidor": la extensión se carga por
`--load-extension` al lanzar Chrome (igual que BeStudio, pero
independiente). El despliegue masivo a todos los perfiles (añadir su
ruta al `--load-extension` del launcher) es un paso aparte y
opcional, pendiente de decidir (ver §5).

## 6c. Bridge Telegram (inicio real del broadcast)

Stripchat **no expone** una hora confiable de "broadcast started":
`statusChangedAt` cambia con cualquier transición de modo
(público↔privado), por eso BeModels caía a heurísticas (sesión
interna, primer evento visto). El canal Telegram **BE PRAGA ONLINE**
sí tiene el timestamp exacto del 🟢 / 📡 de cada modelo.

Setup:

1. **En el server del estudio** (mismo donde corre el watchdog de
   BeStudio), editar `extension-bestudio/server/config.ps1` para
   poner el puerto si no está:
   ```
   $BridgePort = 7878
   $BridgeBind = '127.0.0.1'   # o '0.0.0.0' para LAN del estudio
   ```
2. Lanzar el bridge en una ventana PowerShell aparte:
   ```
   powershell -ExecutionPolicy Bypass -File `
     C:\BePraga\bepraga-studio\extension-bestudio\server\bridge.ps1
   ```
   Lee `bestudio_tg.json` (que ya escribe el launcher).
3. **En BeModels** (popup del icono o panel ⚙ de la barra):
   campo **"Bridge Telegram (URL)"** → `http://localhost:7878`
   (mismo PC) o `http://192.168.x.y:7878` (otra PC en la LAN).
4. Verificar: en la consola del navegador debe salir
   `[BeModels.tg] startedAt 2026-05-23T16:01:00Z · source=telegram`.
5. La franja **EN VIVO** ahora muestra `EN VIVO 📡 5h 51m`
   (el 📡 indica que viene del bridge Telegram).

### Acceso desde fuera del estudio (tu PC en casa)

El bridge corre en LAN del estudio. Para acceder desde Internet sin
abrir puertos públicos, monta un **Cloudflare Tunnel** gratis:

1. Bajar `cloudflared` (binario único, sin instalación) desde
   https://github.com/cloudflare/cloudflared/releases.
2. En el server del estudio, correr:
   ```
   cloudflared tunnel --url http://localhost:7878
   ```
   Devuelve una URL pública tipo
   `https://random-name.trycloudflare.com`.
3. Pegar esa URL en el campo "Bridge Telegram" de BeModels en casa.

El túnel está activo mientras `cloudflared` corra; cada vez genera
una URL nueva, así que para uso permanente conviene usar un túnel
con nombre (requiere cuenta Cloudflare, también gratis).

## 7. Versionado (obligatorio en cada cambio)

Subir `version` en `manifest.json` + `BM_BUILD` en
`bemodels/injected.js` (+ `BM_SW_BUILD` si se toca `background.js`) +
entrada en `CHANGELOG.md`; validar llaves JS; `git commit` +
`git push origin master` con
`Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>`.
