// ============================================================
//  BeModels — background.js  (service worker, type:module)
//  - Relé de notificaciones del sistema (alerta de ballenas).
//  - Poda de dias viejos en chrome.storage (>45 dias).
//  NO descarga ni sube nada: BeModels es solo HUD en vivo. El
//  historico/analitica profunda sigue en BeStudio + dashboard.
// ============================================================
const BM_SW_BUILD = '2026-05-18a';
console.log('[BeModels] SW build ' + BM_SW_BUILD);

chrome.runtime.onMessage.addListener((m, _s, _r) => {
  if (m && m.type === 'BEMODELS_NOTIFY') {
    try {
      chrome.notifications.create('bm_' + Date.now(), {
        type: 'basic',
        iconUrl: 'icon128.png',
        title: m.title || 'BeModels',
        message: m.msg || '',
        priority: 2
      });
    } catch (e) { console.warn('[BeModels] notify err', e); }
  }
  return false;
});

// Poda diaria: borrar dias con clave bemodels_day:* de hace > 45 dias.
chrome.runtime.onInstalled.addListener(() => {
  try { chrome.alarms.create('bm_prune', { periodInMinutes: 720 }); } catch (_) {}
});
chrome.alarms.onAlarm.addListener(a => {
  if (!a || a.name !== 'bm_prune') return;
  try {
    chrome.storage.local.get(null, all => {
      const cut = Date.now() - 45 * 864e5;
      const del = [];
      for (const k of Object.keys(all || {})) {
        const mm = /^bemodels_day:.+:(\d{4}-\d{2}-\d{2})$/.exec(k);
        if (mm && new Date(mm[1] + 'T00:00:00Z').getTime() < cut) del.push(k);
      }
      if (del.length) chrome.storage.local.remove(del);
    });
  } catch (_) {}
});
