// ============================================================
//  BeModels — roster.js
//  Lista CANÓNICA de modelos autorizadas a usar la extensión.
//  Cargada por TODOS los entrypoints de BeModels (content script +
//  popup) → cuando entra/sale una modelo, se edita acá UN SOLO
//  archivo en vez de tres lugares distintos.
//
//  Sigue habiendo una copia paralela en BeStudio
//  (extension-bestudio/begoals/background.js · MODELOS_AUTORIZADAS_BG)
//  porque es otra extensión Chrome aislada. Si se agrega una modelo
//  acá, sincronizar también allá a mano. Eventualmente este roster
//  podría servirse desde el bridge (GET /api/roster) para que las
//  dos extensiones compartan fuente real.
//
//  Carga: la lista queda expuesta como window.BM_AUTORIZADAS_SET
//  (Set<string> de usernames en lowercase, sin spaces).
// ============================================================
(function () {
  'use strict';

  const BM_AUTORIZADAS = [
    'abbytheran',
    'sophieroyals',
    'kellyolsenbe',
    'jamilaross',
    'thealejandrodolls',
    'theladymonserrateshow',
    'aurora19',
    'valery_paola',
    'denightjones',
    'iamevagate',
    'emilyandandrew',
    'abrilandjulian',
    'willturneer',
    'lunabaxter_',
    'secretloversvip',
    'camila_noer',
    'startwerk',
    'bigtiti01',
    'latinos_2001',
    'karriewatson',
    'sofiadollbe',
    'miafarrog'        // Chaturbate (test multi-plataforma, 2026-05-31)
  ];

  // Set para lookup O(1). Normalizamos a lowercase aunque la lista
  // ya viene así, para defender contra futuros typos.
  window.BM_AUTORIZADAS_SET = new Set(
    BM_AUTORIZADAS.map(s => String(s).toLowerCase().trim())
  );
})();
