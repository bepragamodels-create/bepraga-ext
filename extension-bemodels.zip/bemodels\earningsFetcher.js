// ============================================================
//  BeModels — earningsFetcher.js  (content script, ISOLATED world)
//  Lee el GANADO REAL del dia desde el endpoint oficial de
//  Stripchat (mismo origen, con cookies de la sesion). Se carga
//  ANTES de content.js (ver manifest) y expone window.BMEarn.
//
//  Endpoint confirmado por la usuaria 2026-05-20 (capturado en
//  /earnings/tokens-history → initial-dynamic response):
//
//    GET /api/front/users/<USER_ID>/transactions
//        ?from=<ISO_UTC>&until=<ISO_UTC>
//        &limit=1000&offset=0
//
//  Respuesta (campos relevantes):
//    {
//      transactions: [ { type, tokens, amount, date, ... } ],
//      inTokens:  Number   // tk ganados (lo que pagaron al modelo)
//      inUsd:     Number   // USD ganados
//      outTokens: Number   // reembolsos/retiros (descuentos)
//      outUsd:    Number
//      numberOfTransactions: Number
//      users:     { <id>: { ... } }   // perfiles de los tippers
//    }
//
//  Stripchat respeta la TZ del perfil: para "hoy" el `from` es
//  00:00 local en UTC. BeModels calcula esto correctamente.
//
//  Errores silenciosos (null en vez de throw) para no romper UI.
// ============================================================
(function () {
  'use strict';
  const TAG = '[BeModels.earn]';

  // Calcula el instante UTC del 00:00 de "hoy" en la zona tz.
  // Iterativo: converge en 1-2 pasos incluso en cambios de DST.
  function todayMidnightUTC(tz) {
    try {
      const ymd = new Intl.DateTimeFormat('en-CA', { timeZone: tz,
        year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
      const [Y, M, D] = ymd.split('-').map(Number);
      const target = Date.UTC(Y, M - 1, D, 0, 0, 0);
      let guess = target;
      for (let i = 0; i < 3; i++) {
        const parts = new Intl.DateTimeFormat('en-CA', {
          timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit',
          hour: '2-digit', minute: '2-digit', hour12: false
        }).formatToParts(new Date(guess));
        const g = t => Number(parts.find(p => p.type === t).value);
        const local = Date.UTC(g('year'), g('month') - 1, g('day'),
                               g('hour'), g('minute'), 0);
        if (local === target) break;
        guess += target - local;
      }
      return new Date(guess).toISOString();
    } catch (_) { return null; }
  }

  // Stripchat es estricto con el formato ISO: 2026-05-20T05:00:00Z
  // (SIN milisegundos). .toISOString() devuelve "...000Z" → 400.
  function isoNoMs(d) {
    return new Date(d).toISOString().replace(/\.\d{3}Z$/, 'Z');
  }
  async function fetchEarningsToday(userId, tz) {
    if (!userId) { console.debug(TAG, 'sin userId, skip'); return null; }
    const fromIso = todayMidnightUTC(tz || 'America/Bogota');
    if (!fromIso) return null;
    return fetchEarningsRange(userId, fromIso, new Date().toISOString());
  }

  // Fetcher genérico por rango. Devuelve el mismo shape que
  // fetchEarningsToday: { tokens (inTokens agregado), usd, outTokens,
  // outUsd, count, tx[], txTotal, pages, truncated, from, until }.
  // Usado por loadHistoricRange() en content.js para reconstruir la
  // vista de 7 días desde la fuente real (Stripchat), independiente
  // del storage local del navegador.
  //
  // CAP de seguridad: 30 páginas * 100 tx = 3000 transacciones. Para
  // 7 días eso son ~430 tx/día → suficiente para casi cualquier modelo.
  // Si truncated=true, el total inTokens sigue siendo correcto pero
  // tx[] está incompleto y los agregados por día pueden tener faltas.
  async function fetchEarningsRange(userId, fromIso, untilIso) {
    if (!userId || !fromIso || !untilIso) {
      console.debug(TAG, 'range: faltan params'); return null;
    }
    try {
      const from  = isoNoMs(fromIso);
      const until = isoNoMs(untilIso);
      // limit=100 (capturado de la URL real de Stripchat). Stripchat
      // rechazaba limit=1000 con 400. El total agregado (inTokens) viene
      // igual en la respuesta sin importar la pagina; PERO tx[] solo
      // contiene la pagina actual → si hay >100 transacciones en el rango,
      // las viejas se quedan fuera y los agregados por dia darian menos.
      // Paginamos hasta agotar (cap de seguridad: 30 pags = 3000 tx).
      const PAGE = 100;
      const MAX_PAGES = 30;
      const baseUrl = '/api/front/users/' + encodeURIComponent(userId) +
        '/transactions?from=' + encodeURIComponent(from) +
        '&until=' + encodeURIComponent(until) +
        '&limit=' + PAGE + '&offset=';

      let firstJson = null;
      const allRaw = [];
      let pages = 0;
      let truncated = false;
      for (let off = 0; pages < MAX_PAGES; off += PAGE) {
        const r = await fetch(baseUrl + off, {
          credentials: 'include',
          headers: { accept: 'application/json' }
        });
        if (!r.ok) {
          let errBody = '';
          try { errBody = (await r.text()).slice(0, 200); } catch (_) {}
          console.debug(TAG, 'transactions !ok', userId, 'off=' + off,
            r.status, errBody);
          // Si la primera pagina falla, fallamos completo. Si una pagina
          // intermedia falla, devolvemos lo que tengamos (mejor parcial
          // que nada) pero marcamos truncated.
          if (off === 0) return null;
          truncated = true;
          break;
        }
        const j = await r.json();
        if (off === 0) firstJson = j;
        const page = Array.isArray(j && j.transactions) ? j.transactions : [];
        allRaw.push(...page);
        pages++;
        // Cortar si la pagina vino incompleta (ultima) o si ya cubrimos
        // el numero total que reporto el agregado.
        const total = Number(j && j.numberOfTransactions) || 0;
        if (page.length < PAGE) break;
        if (total > 0 && allRaw.length >= total) break;
      }
      if (pages >= MAX_PAGES) {
        truncated = true;
        console.warn(TAG, 'cap de paginacion alcanzado (' + MAX_PAGES +
          ' pags, ' + allRaw.length + ' tx); el dia tiene mas tx.');
      }

      // tx[] = lista normalizada para que content.js pueda re-sumar por
      // ventana arbitraria (ej. "desde inicio del show"). Solo tipos
      // que suman INGRESOS (excluimos refunds/payouts si los hubiera).
      const tx = allRaw
        .filter(t => Number(t.tokens) > 0)
        .map(t => ({
          ts:     Date.parse(t.date),
          tokens: Number(t.tokens) || 0,
          type:   t.type || null,
          user:   t.username || null
        }))
        .filter(t => Number.isFinite(t.ts));
      // dedupe por (ts, user, tokens) por si dos paginas se traslapan.
      const seen = new Set();
      const txDedup = [];
      for (const t of tx) {
        const k = t.ts + '|' + (t.user || '') + '|' + t.tokens;
        if (seen.has(k)) continue;
        seen.add(k);
        txDedup.push(t);
      }
      const j = firstJson;
      const out = {
        tokens:    Number(j && j.inTokens)             || 0,
        usd:       Number(j && j.inUsd)                || 0,
        outTokens: Number(j && j.outTokens)            || 0,
        outUsd:    Number(j && j.outUsd)               || 0,
        count:     Number(j && j.numberOfTransactions) || 0,
        tx: txDedup,
        txTotal: txDedup.length,
        pages, truncated,
        from, until
      };
      console.debug(TAG, 'range OK', userId, 'tokens=' + out.tokens,
        'usd=' + out.usd, 'count=' + out.count,
        'tx=' + txDedup.length + ' (paginado en ' + pages + ' pag' +
        (truncated ? ', TRUNCADO' : '') + ')',
        'window=' + from + '→' + until);
      return out;
    } catch (e) {
      console.debug(TAG, 'range ERR', userId, e && e.message);
      return null;
    }
  }

  window.BMEarn = { fetchEarningsToday, fetchEarningsRange, todayMidnightUTC };
  console.debug(TAG, 'modulo cargado');
})();
